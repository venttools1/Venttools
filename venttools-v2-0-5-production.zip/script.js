const $=id=>document.getElementById(id);function showPage(id){
 const page=$(id)||$("home")||document.querySelector(".page");
 if(!page)return;
 document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
 page.classList.add("active");
 if(id==="offset")calculateOffset();
 if(id==="ductulator")calculateDuct();
 if(id==="fireDamper")calcFD();
 if(history.replaceState)history.replaceState(null,"",id==="home"?"#home":`#${id}`);
 if(window.venttoolsConsent&&window.venttoolsConsent.analytics)sendVentToolsPageView();
 window.scrollTo({top:0,behavior:"smooth"});
}function rad(d){return d*Math.PI/180}function deg(r){return r*180/Math.PI}function fmt(x){return Number.isFinite(x)?(Math.round(x*10)/10).toFixed(1):'—'}function fmt0(x){return Number.isFinite(x)?String(Math.round(x)):'—'}function getAngle(){return $('angle').value==='custom'?(parseFloat($('angleCustom').value)||45):(parseFloat($('angle').value)||45)}function setMsg(type,txt){let m=$('msg');m.className='msg '+type;m.textContent=txt}
function ductPath(x1,y1,x2,y2,w){let vx=x2-x1,vy=y2-y1,L=Math.hypot(vx,vy)||1,nx=-vy/L*w/2,ny=vx/L*w/2;return`M ${x1+nx} ${y1+ny} L ${x2+nx} ${y2+ny} L ${x2-nx} ${y2-ny} L ${x1-nx} ${y1-ny} Z`}function spiralLines(x1,y1,x2,y2,w,count){let vx=x2-x1,vy=y2-y1,L=Math.hypot(vx,vy)||1,ux=vx/L,uy=vy/L,nx=-uy,ny=ux,s='';for(let i=1;i<count;i++){let t=i/count*L,cx=x1+ux*t,cy=y1+uy*t,a=18;s+=`<line x1="${cx+nx*w*.42-ux*a}" y1="${cy+ny*w*.42-uy*a}" x2="${cx-nx*w*.42+ux*a}" y2="${cy-ny*w*.42+uy*a}" stroke="#9aa4b2" stroke-width="1.4"/>`}return s}
function annularSectorPath(cx,cy,rO,rI,a1,a2){const p=(r,a)=>[cx+r*Math.cos(a),cy+r*Math.sin(a)],A=p(rO,a1),B=p(rO,a2),C=p(rI,a2),D=p(rI,a1),sw=a2>a1?1:0;return `M ${A[0]} ${A[1]} A ${rO} ${rO} 0 0 ${sw} ${B[0]} ${B[1]} L ${C[0]} ${C[1]} A ${rI} ${rI} 0 0 ${1-sw} ${D[0]} ${D[1]} Z`}

// Manufacturer bend take-off l (mm), transcribed from the supplied data sheets.
// BU pressed 45° covers the smaller sizes. BFU lockseamed tables cover 250–1250 mm.
const BEND_TAKEOFF_DATA = {
  BU: {
    45: {
      63:41, 80:41, 100:41, 112:81, 125:52, 140:56,
      150:62, 160:66, 180:76, 200:83, 224:93, 250:103
    }
  },
  BFU: {
    15: {
      250:33, 280:37, 300:39, 315:41, 355:47, 400:53, 450:59,
      500:66, 560:74, 600:79, 630:83, 710:93, 800:105, 900:118,
      1000:132, 1120:147, 1250:165
    },
    30: {
      250:67, 280:75, 300:80, 315:84, 355:95, 400:107, 450:121,
      500:134, 560:150, 600:161, 630:169, 710:190, 800:214, 900:241,
      1000:268, 1120:300, 1250:335
    },
    45: {
      250:104, 280:116, 300:124, 315:130, 355:147, 400:166, 450:186,
      500:207, 560:232, 600:249, 630:261, 710:294, 800:331, 900:373,
      1000:414, 1120:464, 1250:518
    },
    60: {
      250:144, 280:162, 300:173, 315:182, 355:205, 400:231, 450:260,
      500:289, 560:323, 600:346, 630:364, 710:410, 800:462, 900:520,
      1000:577, 1120:647, 1250:722
    },
    90: {
      250:250, 280:280, 300:300, 315:315, 355:355, 400:400, 450:450,
      500:500, 560:560, 600:600, 630:630, 710:710, 800:800, 900:900,
      1000:1000, 1120:1120, 1250:1250
    }
  }
};

function getBendTakeoff(angle, diameter, rmFactor){
  const roundedAngle = Math.round(angle * 10) / 10;
  const roundedDiameter = Math.round(diameter);

  // For 45° at 250 mm, use the pressed BU value because the current fitting style
  // treats 250 mm and below as pressed.
  if(roundedAngle === 45 && roundedDiameter <= 250){
    const exact = BEND_TAKEOFF_DATA.BU[45][roundedDiameter];
    if(Number.isFinite(exact)){
      return {l:exact, exact:true, family:'BU pressed', source:'Manufacturer table'};
    }
  }

  const angleTable = BEND_TAKEOFF_DATA.BFU[roundedAngle];
  if(angleTable){
    const exact = angleTable[roundedDiameter];
    if(Number.isFinite(exact)){
      return {l:exact, exact:true, family:'BFU lockseamed', source:'Manufacturer table'};
    }
  }

  const estimated = (rmFactor * diameter) * Math.tan(rad(angle) / 2);
  return {
    l:estimated,
    exact:false,
    family:diameter <= 250 ? 'Pressed-style estimate' : 'Lockseamed-style estimate',
    source:'Geometric estimate: rm × tan(θ/2)'
  };
}

function drawOffset(d){
  /*
    Original Vent Tools schematic:
    - The visible fitting angle follows the selected bend angle.
    - The cut-length maths is unchanged.
    - Rise/offset/roll remain calculated values shown as dimensions.
  */
  const svgW=760, svgH=360;
  const A=Math.max(5,Math.min(80,d.A));
  const a=-rad(A);
  const h={x:1,y:0};
  const diag={x:Math.cos(a),y:Math.sin(a)};
  const w=44;
  const radius=72;
  const tangent=radius*Math.tan(rad(A)/2);

  // Keep the technical sketch legible while allowing the middle piece to grow/shrink.
  const visualStraight=Math.max(150,Math.min(360,150+(Math.max(0,d.straight)/700)*210));
  const lowerY=260;
  const v1={x:170,y:lowerY};
  const b1={x:v1.x+diag.x*tangent,y:v1.y+diag.y*tangent};
  const a1={x:v1.x-tangent,y:v1.y};

  const a2={x:b1.x+diag.x*visualStraight,y:b1.y+diag.y*visualStraight};
  const v2={x:a2.x+diag.x*tangent,y:a2.y+diag.y*tangent};
  const b2={x:v2.x+tangent,y:v2.y};

  const p0={x:55,y:lowerY};
  const p3={x:Math.min(700,b2.x+115),y:b2.y};

  const pressed=d.D<=250;
  const fittingType=pressed?'Pressed bend':'Segmented / lockseamed bend';

  function unit(a,b){
    const vx=b.x-a.x,vy=b.y-a.y,L=Math.hypot(vx,vy)||1;
    return{x:vx/L,y:vy/L};
  }
  function normal(u){return{x:-u.y,y:u.x}}
  function point(p,u,t){return{x:p.x+u.x*t,y:p.y+u.y*t}}
  function crossLine(p,u,length=w*.98,colour='#4b5563',width=2){
    const n=normal(u),half=length/2;
    return `<line x1="${p.x+n.x*half}" y1="${p.y+n.y*half}" x2="${p.x-n.x*half}" y2="${p.y-n.y*half}" stroke="${colour}" stroke-width="${width}"/>`;
  }
  function collar(p,u){
    return [
      crossLine(point(p,u,-4),u,w*1.06,'#374151',2.6),
      crossLine(p,u,w*1.12,'#111827',3.2),
      crossLine(point(p,u,5),u,w*1.06,'#6b7280',2)
    ].join('');
  }
  function spiralSeams(a,b,count){
    const u=unit(a,b),n=normal(u),L=Math.hypot(b.x-a.x,b.y-a.y);
    let out='';
    for(let i=1;i<count;i++){
      const c=point(a,u,L*i/count);
      const skew=14;
      out+=`<line x1="${c.x+n.x*w*.42-u.x*skew}" y1="${c.y+n.y*w*.42-u.y*skew}" x2="${c.x-n.x*w*.42+u.x*skew}" y2="${c.y-n.y*w*.42+u.y*skew}" stroke="#9ca3af" stroke-width="1.25"/>`;
    }
    return out;
  }
  function quadPoint(s,c,e,t){
    return{
      x:(1-t)*(1-t)*s.x+2*(1-t)*t*c.x+t*t*e.x,
      y:(1-t)*(1-t)*s.y+2*(1-t)*t*c.y+t*t*e.y
    };
  }
  function quadTangent(s,c,e,t){
    const x=2*(1-t)*(c.x-s.x)+2*t*(e.x-c.x);
    const y=2*(1-t)*(c.y-s.y)+2*t*(e.y-c.y);
    const L=Math.hypot(x,y)||1;
    return{x:x/L,y:y/L};
  }
  function bendBands(s,c,e,count,heavy){
    let out='';
    for(let i=1;i<=count;i++){
      const t=i/(count+1);
      const q=quadPoint(s,c,e,t);
      const u=quadTangent(s,c,e,t);
      out+=crossLine(q,u,w*.96,heavy?'#6b7280':'#a1a8b2',heavy?2.1:1.35);
    }
    return out;
  }

  const centrePath=`M ${p0.x} ${p0.y} L ${a1.x} ${a1.y} Q ${v1.x} ${v1.y} ${b1.x} ${b1.y} L ${a2.x} ${a2.y} Q ${v2.x} ${v2.y} ${b2.x} ${b2.y} L ${p3.x} ${p3.y}`;

  const diagU=unit(b1,a2);
  const lowerU=h,upperU=h;

  // Dimension positions.
  const dimBottomY=326;
  const riseX=Math.min(705,p3.x+24);
  const cutDimOffset=34;
  const nDiag=normal(diagU);
  const cutA={x:b1.x+nDiag.x*cutDimOffset,y:b1.y+nDiag.y*cutDimOffset};
  const cutB={x:a2.x+nDiag.x*cutDimOffset,y:a2.y+nDiag.y*cutDimOffset};

  $('diagramLayer').innerHTML=`
    <style>
      #diagramLayer .body-outline{fill:none;stroke:#374151;stroke-width:${w+5};stroke-linecap:butt;stroke-linejoin:round}
      #diagramLayer .body-metal{fill:none;stroke:url(#ductGrad);stroke-width:${w};stroke-linecap:butt;stroke-linejoin:round}
      #diagramLayer .centreline{fill:none;stroke:#111827;stroke-width:1.6;stroke-dasharray:7 7}
      #diagramLayer .extension{stroke:#94a3b8;stroke-width:1.2;stroke-dasharray:5 5}
      #diagramLayer .dimension{stroke:#064b82;stroke-width:2;marker-start:url(#arrow);marker-end:url(#arrow)}
      #diagramLayer .label{font-family:system-ui,Arial;font-weight:800;fill:#111827}
      #diagramLayer .blue{fill:#064b82}
    </style>

    <path d="${centrePath}" class="body-outline"/>
    <path d="${centrePath}" class="body-metal"/>

    ${spiralSeams(p0,a1,4)}
    ${spiralSeams(b1,a2,7)}
    ${spiralSeams(b2,p3,4)}

    ${collar(a1,lowerU)}
    ${collar(b1,diagU)}
    ${collar(a2,diagU)}
    ${collar(b2,upperU)}

    ${bendBands(a1,v1,b1,pressed?1:4,!pressed)}
    ${bendBands(a2,v2,b2,pressed?1:4,!pressed)}

    <path d="${centrePath}" class="centreline"/>

    <line x1="${v1.x}" y1="${v1.y}" x2="${v1.x}" y2="${dimBottomY}" class="extension"/>
    <line x1="${v2.x}" y1="${v2.y}" x2="${v2.x}" y2="${dimBottomY}" class="extension"/>
    <line x1="${v1.x}" y1="${dimBottomY}" x2="${v2.x}" y2="${dimBottomY}" class="dimension"/>
    <text x="${(v1.x+v2.x)/2}" y="${dimBottomY+24}" text-anchor="middle" font-size="15" class="label blue">Offset ${fmt(d.H)} mm</text>

    <line x1="${v2.x}" y1="${v1.y}" x2="${riseX-8}" y2="${v1.y}" class="extension"/>
    <line x1="${v2.x}" y1="${v2.y}" x2="${riseX-8}" y2="${v2.y}" class="extension"/>
    <line x1="${riseX}" y1="${v1.y}" x2="${riseX}" y2="${v2.y}" class="dimension"/>
    <text x="${riseX-8}" y="${(v1.y+v2.y)/2-8}" text-anchor="end" font-size="15" class="label blue">Rise</text>
    <text x="${riseX-8}" y="${(v1.y+v2.y)/2+12}" text-anchor="end" font-size="14" class="label">${fmt(d.V)} mm</text>

    <line x1="${cutA.x}" y1="${cutA.y}" x2="${cutB.x}" y2="${cutB.y}" class="dimension"/>
    <text x="${(cutA.x+cutB.x)/2+nDiag.x*18}" y="${(cutA.y+cutB.y)/2+nDiag.y*18}" text-anchor="middle" font-size="15" class="label blue">L ${fmt(d.straight)} mm</text>

    <text x="${v1.x+10}" y="${v1.y-62}" font-size="14" class="label">${fmt(A)}°</text>
    <text x="${v2.x-20}" y="${v2.y+62}" font-size="14" class="label">${fmt(A)}°</text>
    <text x="380" y="30" text-anchor="middle" font-size="18" class="label">Roll ${fmt(d.roll)}°</text>
  `;
}
function calculateOffset(){
  const V=parseFloat($('up').value)||0;
  const H=parseFloat($('over').value)||0;
  const A=getAngle();
  const D=parseFloat($('dia').value)||0;
  const minS=parseFloat($('minStraight').value)||0;
  const rmF=parseFloat($('rmFactor').value)||1;

  const th=rad(A);
  const sinA=Math.sin(th);
  const R=Math.hypot(V,H);
  const T=sinA>0 ? R/sinA : NaN;
  const roll=(V===0&&H===0) ? 0 : deg(Math.atan2(V,H));

  const bend=getBendTakeoff(A,D,rmF);
  const l=bend.l;
  const straight=T-(2*l);

  // Work backwards from the selected minimum straight.
  // Required resultant offset R = sin(angle) × (minimum straight + two bend take-offs).
  const requiredR=sinA>0 ? sinA*(minS+(2*l)) : NaN;
  const minRise=Number.isFinite(requiredR) ? Math.sqrt(Math.max(0,(requiredR*requiredR)-(H*H))) : NaN;
  const riseChange=Number.isFinite(minRise) ? Math.max(0,minRise-V) : NaN;

  $('straightBig').textContent=fmt(straight)+' mm';
  $('rollBig').textContent=fmt(roll)+'°';
  if($('minRiseBig')) $('minRiseBig').textContent=fmt(minRise)+' mm';
  if($('riseChangeBig')) $('riseChangeBig').textContent=riseChange>0 ? '+'+fmt(riseChange)+' mm' : 'No increase';
  if($('minRiseSub')){
    $('minRiseSub').textContent=H>=requiredR
      ? `Your ${fmt(H)} mm offset already provides enough resultant distance, even with zero rise.`
      : `Minimum rise needed with ${fmt(H)} mm offset / over.`;
  }
  if($('riseChangeSub')){
    $('riseChangeSub').textContent=riseChange>0
      ? `Increase the rise from ${fmt(V)} mm to at least ${fmt(minRise)} mm.`
      : `Current rise of ${fmt(V)} mm already achieves at least ${fmt(minS)} mm straight.`;
  }

  const result=`Vent Tools - Offset Calculator

Inputs:
  Rise / Up (V)          = ${fmt(V)} mm
  Offset / Over (H)      = ${fmt(H)} mm
  Bend angle (θ)         = ${fmt(A)}°
  Duct diameter (D)      = ${fmt(D)} mm
  Minimum straight       = ${fmt(minS)} mm

Results:
  Cut straight L         = ${fmt(straight)} mm
  Roll angle             = ${fmt(roll)}°
  Resultant offset R     = ${fmt(R)} mm
  Travel T               = ${fmt(T)} mm
  Bend take-off l        = ${fmt(l)} mm
  Minimum rise required  = ${fmt(minRise)} mm
  Rise increase required = ${fmt(riseChange)} mm
  Bend family            = ${bend.family}
  Dimension source       = ${bend.source}`;

  $('out').textContent=result;
  drawOffset({V,H,A,D,straight,roll});

  const chip=$('fittingChip');
  if(chip){
    chip.textContent=`${bend.family} • Ø${fmt0(D)} mm • ${bend.exact?'Exact table dimension':'Estimated dimension'}`;
  }

  if(!Number.isFinite(straight)){
    setMsg('bad','⚠ Check your angle input.');
  }else if(straight<0){
    setMsg('bad',`❌ Impossible fit. Increase the rise to at least ${fmt(minRise)} mm for a ${fmt(minS)} mm straight, or reduce the offset / bend angle.`);
  }else if(straight<minS){
    setMsg('warn',`⚠ Straight is ${fmt(straight)} mm. Increase rise by ${fmt(riseChange)} mm to at least ${fmt(minRise)} mm for a ${fmt(minS)} mm straight.`);
  }else if(!bend.exact){
    setMsg('warn','⚠ Cut length uses an estimated bend take-off because this exact angle/diameter is not in the current manufacturer table.');
  }else{
    setMsg('ok',`✅ Straight is ${fmt(straight)} mm, which meets the selected ${fmt(minS)} mm minimum.`);
  }
  return result;
}
function angleUI(){let c=$('angle').value==='custom';$('angleCustom').style.display=c?'block':'none';if(!c)$('angleCustom').value=$('angle').value}function resetOffset(){$('up').value=300;$('over').value=250;$('angle').value='45';$('angleCustom').value=45;$('dia').value=315;$('minStraight').value=120;$('rmFactor').value=1;angleUI();calculateOffset()}async function copyOffset(){let r=calculateOffset();try{await navigator.clipboard.writeText(r);setMsg('ok','✅ Result copied.')}catch(e){setMsg('warn','Could not copy automatically. Long-press working text and copy manually.')}}function toggleWorking(){let o=$('out'),show=o.style.display==='block';o.style.display=show?'none':'block';$('workingBtn').textContent=show?'Show working':'Hide working'}
function initOffsetCalculator(){
 if(!$('up'))return;
 ['up','over','dia','minStraight','rmFactor','angle','angleCustom'].forEach(id=>{
  const el=$(id);if(!el)return;
  el.addEventListener('input',()=>{angleUI();calculateOffset()});
  el.addEventListener('change',()=>{angleUI();calculateOffset()});
 });
 $('resetBtn')?.addEventListener('click',resetOffset);
 $('copyBtn')?.addEventListener('click',copyOffset);
 $('workingBtn')?.addEventListener('click',toggleWorking);
 angleUI();calculateOffset();
}
const standardSpiral=[80,100,125,150,160,180,200,224,250,280,300,315,355,400,450,500,560,600,630,710,800,900,1000,1120,1250,1400,1500,1600];
function nearestStandard(d){let best=standardSpiral[0];for(const size of standardSpiral){if(Math.abs(size-d)<Math.abs(best-d))best=size}return best}
function nextStandardAtOrAbove(d){for(const size of standardSpiral){if(size>=d)return size}return Math.ceil(d/100)*100}
function ductArea(w,h){return w*h}
function roundArea(d){return Math.PI*d*d/4}
function equalAreaDiameter(w,h){return Math.sqrt((4*w*h)/Math.PI)}
function equivalentDiameter(w,h){return 1.30*Math.pow(w*h,0.625)/Math.pow(w+h,0.25)}
function aspectRatio(w,h){return Math.max(w,h)/Math.min(w,h)}
function roundTo(value,step){return Math.round(value/step)*step}
function floorTo(value,step){return Math.floor(value/step)*step}
function ceilTo(value,step){return Math.ceil(value/step)*step}
let dcMode='width',dcSource='rect';
function sourceArea(){if(dcSource==='round'){const d=parseFloat($('roundD')?.value)||0;return d>0?roundArea(d):0}const w=parseFloat($('rectW')?.value)||0,h=parseFloat($('rectH')?.value)||0;return w>0&&h>0?w*h:0}
function sourceReferenceDimension(){if(dcSource==='round')return parseFloat($('roundD')?.value)||900;return dcMode==='width'?(parseFloat($('rectW')?.value)||1200):(parseFloat($('rectH')?.value)||330)}
function activeAlternativeInput(){return dcMode==='width'?$('dcNewWidth'):$('dcNewHeight')}
function setDuctSource(source){
 dcSource=source==='round'?'round':'rect';
 $('dcSourceRect')?.classList.toggle('active',dcSource==='rect');$('dcSourceRound')?.classList.toggle('active',dcSource==='round');
 if($('dcRectInputs'))$('dcRectInputs').style.display=dcSource==='rect'?'grid':'none';
 if($('dcRoundInputs'))$('dcRoundInputs').style.display=dcSource==='round'?'block':'none';
 seedDuctAlternative();
}
function setDuctMode(mode){
 dcMode=mode==='height'?'height':'width';
 $('dcFixWidth')?.classList.toggle('active',dcMode==='width');$('dcFixHeight')?.classList.toggle('active',dcMode==='height');
 $('dcWidthField')?.classList.toggle('active',dcMode==='width');$('dcHeightField')?.classList.toggle('active',dcMode==='height');
 if($('dcSliderLabel'))$('dcSliderLabel').textContent=dcMode==='width'?'Slide the new width':'Slide the new height';
 syncDuctSliderBounds();calculateDuct(false);
}
function seedDuctAlternative(){
 const area=sourceArea();if(!(area>0))return;
 const reference=sourceReferenceDimension();
 const fixed=Math.max(25,floorTo(reference,25));
 if(dcMode==='width'){$('dcNewWidth').value=fixed;$('dcNewHeight').value=Math.max(25,ceilTo(area/fixed,25))}
 else{$('dcNewHeight').value=fixed;$('dcNewWidth').value=Math.max(25,ceilTo(area/fixed,25))}
 syncDuctSliderBounds();calculateDuct(true);
}
function syncDuctSliderBounds(){
 const slider=$('dcSizeSlider'),input=activeAlternativeInput();if(!slider||!input)return;
 const base=Math.max(sourceReferenceDimension(),parseFloat(input.value)||0);
 slider.min=50;slider.max=Math.max(3000,ceilTo(base*2,25));slider.value=Math.max(50,Math.min(Number(slider.max),parseFloat(input.value)||sourceReferenceDimension()));
}
function drawDuctConversion(w,h,nw,nh){const o=$('dcOriginalShape'),n=$('dcNewShape');if(!o||!n)return;const max=180;let oa=w,ob=h;if(dcSource==='round'){const d=parseFloat($('roundD')?.value)||900;oa=d;ob=d;o.classList.add('dc-round-source')}else{o.classList.remove('dc-round-source')}const scale=Math.min(max/Math.max(oa,ob),max/Math.max(nw,nh));const set=(el,a,b)=>{el.style.width=Math.max(48,a*scale)+'px';el.style.height=Math.max(36,b*scale)+'px'};set(o,oa,ob);set(n,nw,nh);$('dcOriginalShapeText').textContent=dcSource==='round'?`Ø ${fmt0(parseFloat($('roundD')?.value)||0)}`:`${fmt0(w)} × ${fmt0(h)}`;$('dcNewShapeText').textContent=`${fmt0(nw)} × ${fmt0(nh)}`}
function calculateDuct(commitActive=true){
 const w=parseFloat($('rectW')?.value)||0,h=parseFloat($('rectH')?.value)||0,d=parseFloat($('roundD')?.value)||0;
 const area=sourceArea();if(!(area>0))return '';
 const active=activeAlternativeInput();const rawTarget=parseFloat(active?.value)||sourceReferenceDimension();const target=Math.max(25,floorTo(rawTarget,25));
 let exactW,exactH,rw,rh;
 if(dcMode==='width'){rw=target;exactW=rw;exactH=area/rw;rh=Math.max(25,ceilTo(exactH,25))}
 else{rh=target;exactH=rh;exactW=area/rh;rw=Math.max(25,ceilTo(exactW,25))}
 let roundedArea=rw*rh;if(roundedArea<area){if(dcMode==='width')rh+=25;else rw+=25;roundedArea=rw*rh}
 if(commitActive&&active)active.value=target;
 if(dcMode==='width')$('dcNewHeight').value=rh;else $('dcNewWidth').value=rw;
 if($('dcSizeSlider'))$('dcSizeSlider').value=target;
 const areaDiff=(roundedArea-area)/area*100,newRatio=aspectRatio(rw,rh),sourceDia=dcSource==='round'?d:equalAreaDiameter(w,h),suggestedEqualDia=equalAreaDiameter(rw,rh),suggestedRound=nextStandardAtOrAbove(sourceDia),origEq=dcSource==='round'?d:equivalentDiameter(w,h),newEq=equivalentDiameter(rw,rh),frictionDiff=(newEq-origEq)/origEq*100;
 $('dcOriginalArea').textContent=`${(area/1e6).toFixed(3)} m²`;$('dcOriginalRatio').textContent=dcSource==='round'?'1.00 : 1 (round)':`${aspectRatio(w,h).toFixed(2)} : 1`;$('eqRound').textContent=`Ø ${fmt0(sourceDia)} mm`;
 $('dcExactSize').textContent=`${fmt0(exactW)} × ${fmt0(exactH)} mm`;$('dcExactNote').textContent='The paired dimension rounds up so free area never falls below the issued duct';$('dcRoundedSize').textContent=`${fmt0(rw)} × ${fmt0(rh)} mm`;$('dcAreaDiff').textContent=`${areaDiff>=0?'+':''}${areaDiff.toFixed(2)}%`;$('dcRatio').textContent=`${newRatio.toFixed(2)} : 1`;$('dcEqualAreaRound').textContent=`Ø ${fmt0(suggestedEqualDia)} mm`;
 $('dcSuggestedRound').textContent=`Ø ${fmt0(suggestedRound)} mm`;$('dcOriginalFrictionRound').textContent=`Ø ${fmt0(origEq)} mm`;$('dcNewFrictionRound').textContent=`Ø ${fmt0(newEq)} mm`;$('dcFrictionDiff').textContent=`${frictionDiff>=0?'+':''}${frictionDiff.toFixed(2)}%`;$('nearestRound').textContent=`Ø ${fmt0(suggestedRound)} mm`;
 const ratioOverLimit=newRatio>4;
 const ratioMsg=$('dcRatioWarning');ratioMsg.className='dc-ratio-message '+(ratioOverLimit?'warn':'ok');ratioMsg.textContent=ratioOverLimit?'⚠ Aspect ratio exceeds 4:1. Review pressure loss, noise, stiffening and project requirements.':'✓ Aspect ratio is within the 4:1 VentTools advisory limit.';
 const liveRatio=$('dcLiveRatioStatus');if(liveRatio){liveRatio.className='dc-live-ratio '+(ratioOverLimit?'warn':'ok');liveRatio.textContent=ratioOverLimit?`⚠ ${newRatio.toFixed(2)} : 1 — exceeds the 4:1 advisory limit`:`✓ ${newRatio.toFixed(2)} : 1 — within the 4:1 advisory limit`}
 $('dcResultMain')?.classList.toggle('ratio-over-limit',ratioOverLimit);$('dcRatioTile')?.classList.toggle('ratio-over-limit',ratioOverLimit);
 const safeMsg=$('dcSafeAreaMessage');if(safeMsg){safeMsg.className='dc-ratio-message '+(roundedArea>=area?'ok':'warn');safeMsg.textContent=roundedArea>=area?'✓ Suggested free area is equal to or greater than the issued duct.':'⚠ Suggested size is below the issued free area — do not use.'}
 drawDuctConversion(w,h,rw,rh);
 const sourceText=dcSource==='round'?`Ø ${fmt0(d)} mm spiral`:`${fmt0(w)} × ${fmt0(h)} mm rectangular`;
 const details=`VENTTOOLS ROUND / RECTANGULAR DUCT CONVERTER\n\nIssued drawing: ${sourceText}\nOriginal area: ${fmt0(area)} mm² (${(area/1e6).toFixed(3)} m²)\n\nExact equal-area rectangular size: ${fmt0(exactW)} × ${fmt0(exactH)} mm\nSuggested safe 25 mm size: ${fmt0(rw)} × ${fmt0(rh)} mm\nPractical area: ${fmt0(roundedArea)} mm²\nArea difference: ${areaDiff>=0?'+':''}${areaDiff.toFixed(2)}%\nAspect ratio: ${newRatio.toFixed(2)}:1\n\nIssued duct equal-area round reference: Ø ${fmt0(sourceDia)} mm\nSuggested rectangular exact equal-area round: Ø ${fmt0(suggestedEqualDia)} mm\nIssued duct friction-equivalent round: Ø ${fmt0(origEq)} mm\nAlternative friction-equivalent round: Ø ${fmt0(newEq)} mm\nFriction-equivalent diameter difference: ${frictionDiff>=0?'+':''}${frictionDiff.toFixed(2)}%\n\nMethod: Equal area is the default site comparison. The paired dimension rounds upward in 25 mm steps so the suggested free area is not smaller than the issued duct.\nDrawing remains controlling; obtain approval before changing size.`;
 $('dcCalculationDetails').textContent=details;return details
}
async function copyDuct(){const text=calculateDuct(true);try{await navigator.clipboard.writeText(text)}catch(e){}}
function resetDuct(){$('rectW').value=1200;$('rectH').value=330;if($('roundD'))$('roundD').value=355;dcMode='width';setDuctSource('rect');setDuctMode('width')}
function nudgeDuctDimension(target,delta){setDuctMode(target);const input=activeAlternativeInput();input.value=Math.max(25,(parseFloat(input.value)||25)+delta);calculateDuct(true);syncDuctSliderBounds()}
function swapDuctAlternative(){const w=parseFloat($('dcNewWidth').value)||0,h=parseFloat($('dcNewHeight').value)||0;$('dcNewWidth').value=h;$('dcNewHeight').value=w;setDuctMode('width');calculateDuct(true)}
function initDuctConverter(){
 if(!$('dcNewWidth'))return;
 ['rectW','rectH','roundD'].forEach(id=>$(id)?.addEventListener('input',seedDuctAlternative));
 $('dcNewWidth').addEventListener('focus',()=>setDuctMode('width'));$('dcNewHeight').addEventListener('focus',()=>setDuctMode('height'));
 $('dcNewWidth').addEventListener('input',()=>setDuctMode('width'));$('dcNewHeight').addEventListener('input',()=>setDuctMode('height'));
 ['dcNewWidth','dcNewHeight'].forEach(id=>{$(id).addEventListener('change',()=>calculateDuct(true));$(id).addEventListener('blur',()=>calculateDuct(true))});
 $('dcSizeSlider')?.addEventListener('input',e=>{activeAlternativeInput().value=e.target.value;calculateDuct(true)});
 $('dcFixWidth')?.addEventListener('click',()=>setDuctMode('width'));$('dcFixHeight')?.addEventListener('click',()=>setDuctMode('height'));
 $('dcSourceRect')?.addEventListener('click',()=>setDuctSource('rect'));$('dcSourceRound')?.addEventListener('click',()=>setDuctSource('round'));
 document.querySelectorAll('[data-duct-nudge]').forEach(button=>button.addEventListener('click',()=>nudgeDuctDimension(button.dataset.target,Number(button.dataset.ductNudge))));
 $('dcSwap')?.addEventListener('click',swapDuctAlternative);$('copyDuctBtn')?.addEventListener('click',copyDuct);$('resetDuctBtn')?.addEventListener('click',resetDuct);
 seedDuctAlternative();
}

initDuctConverter();

initOffsetCalculator();


const VT_ENGINEERING_DB_VERSION="1.4.0-bsb-fd-c-af";
const VT_ENGINEERING_MODE_KEY="venttoolsEngineeringMode";
function isVTEngineeringMode(){
  try{
    const params=new URLSearchParams(location.search);
    if(params.get("engineering")==="1") return true;
    return localStorage.getItem(VT_ENGINEERING_MODE_KEY)==="1";
  }catch(_){return false}
}
function setVTEngineeringMode(enabled){
  try{localStorage.setItem(VT_ENGINEERING_MODE_KEY,enabled?"1":"0")}catch(_){}
  document.documentElement.classList.toggle("vt-engineering-mode",!!enabled);
  const note=document.querySelector(".footer-live-note");
  if(note) note.title=enabled?"Engineering mode enabled":"";
  if(window.__lastFDResult) renderFDVerification(window.__lastFDResult);
}
function initVTEngineeringMode(){
  document.documentElement.classList.toggle("vt-engineering-mode",isVTEngineeringMode());
  const trigger=document.querySelector(".footer-live-note");
  if(!trigger)return;
  let taps=[];
  trigger.addEventListener("click",()=>{
    const now=Date.now(); taps=taps.filter(t=>now-t<4000); taps.push(now);
    if(taps.length>=5){
      taps=[];
      const enabled=!isVTEngineeringMode();
      setVTEngineeringMode(enabled);
      const msg=enabled?"Engineering mode enabled":"Engineering mode hidden";
      if(typeof fdMsg==="function")fdMsg("ok",msg);else alert(msg);
    }
  });
}
function applyFDVerificationTeaching(){
  Object.entries(FD_MANUFACTURERS).forEach(([manufacturerKey,manufacturer])=>{
    Object.entries(manufacturer.products||{}).forEach(([productKey,product])=>{
      Object.entries(product.methods||{}).forEach(([methodKey,method])=>{
        const unsupported=/link|manual/i.test(String(method.type||""));
        const dynamicMappedTypes=new Set(["advanced-rect-table","advanced-circle-fixed","advanced-circle-floor","advanced-rect-fixed","advanced-26scd-afs"]);
        const mappedSetting=!!((method.settingOut && ["casing-edge","nominal-duct","table-centred","not-applicable"].includes(method.settingOut.basis)) || method.dynamicSettingOut===true || dynamicMappedTypes.has(method.type));
        method.engineeringVerification={
          manufacturerKey,productKey,methodKey,
          manufacturerVerified:true,
          productVerified:!!product.label,
          installationMethodVerified:!!method.reference && !unsupported,
          sourceDocumentVerified:!!product.manual,
          sourceRevisionVerified:!!product.revision,
          openingRuleVerified:!unsupported,
          builderSettingOutVerified:mappedSetting,
          taughtBy:"VentTools verified-method registry"
        };
      });
    });
  });
}
function getFDVerification(r){
  const live=currentFD();
  const manKey=r?.manufacturerKey||live.manKey;
  const productKey=r?.productKey||live.productKey;
  const methodKey=r?.methodKey||live.methodKey;
  const man=FD_MANUFACTURERS[manKey];
  const p=man?.products?.[productKey];
  const m=p?.methods?.[methodKey];
  const taught=m?.engineeringVerification||{};
  const activeSetting=r?.settingOut||m?.settingOut;
  const settingMapped=!!(activeSetting && ["casing-edge","nominal-duct","table-centred","not-applicable"].includes(activeSetting.basis));
  const checks={
    manufacturer:{pass:taught.manufacturerVerified===true && !!man?.label,label:"Manufacturer identified and verified",reason:taught.manufacturerVerified?"Manufacturer exists in the verified registry.":"Manufacturer verification flag is missing."},
    product:{pass:taught.productVerified===true && !!p?.label,label:"Product record identified and verified",reason:taught.productVerified?"Product is mapped to the selected manufacturer.":"Product verification flag is missing."},
    installationMethod:{pass:taught.installationMethodVerified===true && !!m?.reference && !r?.isLinkOnly,label:"Installation method verified",reason:taught.installationMethodVerified?"Method is tied to a recorded manufacturer reference.":"Method is drawing-led, link-only, or not yet verified."},
    sourceDocument:{pass:taught.sourceDocumentVerified===true && !!p?.manual,label:"Official source document linked",reason:p?.manual||"No official URL recorded."},
    sourceRevision:{pass:taught.sourceRevisionVerified===true && !!p?.revision,label:"Source revision recorded",reason:p?.revision||"No revision recorded."},
    openingCalculation:{pass:taught.openingRuleVerified===true && !!r && !r.error && !r.invalidSize && !r.isLinkOnly && r.statusType!=="manual",label:"Opening calculation verified",reason:r?.sourceStatus||"No calculated result."},
    finishedOpening:{pass:(r?.noBuilderOpening===true || r?.noSeparateFinishedOpening===true || !!r?.finishedStage) && !r?.invalidSize && !r?.isLinkOnly,label:"Finished opening verified",reason:r?.noSeparateFinishedOpening===true?"Manufacturer publishes one structural D-hole and a sealing/infill detail inside it; no separate finished clear-opening dimension is specified.":(r?.finishedStage||"The formed/finished aperture is not separately recorded.")},
    apertureLining:{pass:!r?.includesLining || (r?.liningMapped===true && Number(r?.structuralLiningBottom)>0 && !!r?.cutStage && !!r?.finishedStage),label:"Aperture lining build-up verified",reason:!r?.includesLining?"Selected method does not add a separate aperture lining.":(r?.liningMapped===true&&Number(r?.structuralLiningBottom)>0?`One ${r.structuralLiningBottom} mm fire-rated lining layer is accounted for at each internal edge; opposite edges add ${2*Number(r.structuralLiningBottom)} mm per dimension.`:"Lining is required but its thickness/build-up is not mapped.")},
    structuralCut:{pass:(r?.noBuilderOpening===true || !!r?.cutStage) && (!r?.includesLining || (r?.liningMapped===true && Number(r?.cutW)>Number(r?.finishedW) && Number(r?.cutH)>Number(r?.finishedH))),label:"Structural cut verified separately",reason:r?.cutStage||"The structural builder cut is not separately recorded."},
    builderSettingOut:{pass:(r?.noBuilderOpening===true || (taught.builderSettingOutVerified===true && settingMapped)) && !r?.invalidSize && !r?.isLinkOnly,label:"Builder setting-out verified",reason:activeSetting?.source||"Nominal duct → casing → clearance → lining chain is not fully mapped."}
  };
  const failed=Object.entries(checks).filter(([,v])=>!v.pass).map(([key,v])=>({key,label:v.label,reason:v.reason}));
  let status="verified";
  if(r?.error || r?.invalidSize || r?.isLinkOnly || !checks.installationMethod.pass || !checks.openingCalculation.pass) status="draft";
  else if(failed.length) status="partial";
  const meta={
    verified:{icon:"🟢",label:"Verified",issueLabel:"Ready to issue",canIssue:true},
    partial:{icon:"🟡",label:"Partially verified",issueLabel:"Engineering review required",canIssue:true},
    draft:{icon:"🔴",label:"Draft",issueLabel:"Do not issue",canIssue:false}
  }[status];
  return {status,...meta,checks,failed,traceability:{manufacturer:man?.label||"—",product:p?.label||r?.product||"—",installationMethod:m?.label||r?.reference||"—",sourceDocument:p?.guide||p?.manualTitle||"—",sourceRevision:p?.revision||"—",sourceUrl:p?.manual||"",databaseVersion:VT_ENGINEERING_DB_VERSION,generatedAt:new Date().toISOString()},engineering:{manufacturerKey:manKey,productKey,methodKey,methodType:m?.type||"—",settingBasis:activeSetting?.basis||"unmapped",taughtBy:taught.taughtBy||"not registered"}};
}
function renderFDVerification(r){
  window.__lastFDResult=r;
  const v=getFDVerification(r);r.verification=v;
  let panel=document.getElementById("fdVerificationPanel");
  if(!panel){panel=document.createElement("section");panel.id="fdVerificationPanel";panel.className="fd-verification-panel";document.getElementById("fdResultStatus")?.insertAdjacentElement("afterend",panel)}
  const checks=Object.values(v.checks).map(c=>`<li class="${c.pass?'pass':'fail'}"><span>${c.pass?'✓':'!'}</span>${c.label}</li>`).join('');
  panel.className=`fd-verification-panel ${v.status}`;
  const debug=isVTEngineeringMode()?`<section class="fd-engineering-debug"><h4>Engineering mode</h4><dl><div><dt>Manufacturer key</dt><dd>${v.engineering.manufacturerKey}</dd></div><div><dt>Product key</dt><dd>${v.engineering.productKey}</dd></div><div><dt>Method key</dt><dd>${v.engineering.methodKey}</dd></div><div><dt>Method type</dt><dd>${v.engineering.methodType}</dd></div><div><dt>Setting-out basis</dt><dd>${v.engineering.settingBasis}</dd></div><div><dt>Registry</dt><dd>${v.engineering.taughtBy}</dd></div></dl>${v.failed.length?`<h4>Why it is not green</h4><ul>${v.failed.map(f=>`<li class="fail"><span>!</span><strong>${f.label}</strong><small>${f.reason||""}</small></li>`).join("")}</ul>`:`<p class="fd-engineering-all-pass">All required engineering checks pass.</p>`}</section>`:"";
  panel.innerHTML=`<button type="button" class="fd-verification-head" aria-expanded="false"><span class="fd-verification-badge">${v.icon} ${v.label}</span><strong>${v.issueLabel}</strong><span class="chev">Details ▾</span></button><div class="fd-verification-body" hidden><h4>Engineering verification</h4><ul>${checks}</ul><h4>Engineering traceability</h4><dl><div><dt>Manufacturer</dt><dd>${v.traceability.manufacturer}</dd></div><div><dt>Product</dt><dd>${v.traceability.product}</dd></div><div><dt>Method</dt><dd>${v.traceability.installationMethod}</dd></div><div><dt>Source</dt><dd>${v.traceability.sourceDocument}</dd></div><div><dt>Revision</dt><dd>${v.traceability.sourceRevision}</dd></div><div><dt>Database</dt><dd>${v.traceability.databaseVersion}</dd></div></dl>${debug}</div>`;
  const btn=panel.querySelector('button'),body=panel.querySelector('.fd-verification-body');btn.onclick=()=>{const open=body.hidden;body.hidden=!open;btn.setAttribute('aria-expanded',String(open));btn.querySelector('.chev').textContent=open?'Details ▴':'Details ▾'};
  return v;
}

const ADVANCED_AIR_DOCUMENTS={
  IOM_0160:{url:"https://www.advancedair.co.uk/app/uploads/0160_IOM_Rev1.0.pdf",title:"0160 Installation Manual"},
  IOM_2530:{url:"https://www.advancedair.co.uk/app/uploads/2530_IOM_Rev1.1.pdf",title:"2530 Installation Manual"},
  IOM_0400_0500:{url:"https://www.advancedair.co.uk/app/uploads/0400-0500_IOM_Rev1.1.pdf",title:"0400/0500 Installation Manual"},
  IOM_26SCD:{url:"https://www.advancedair.co.uk/app/uploads/26SCD_IOM_Rev1.0.pdf",title:"26SCD Installation Manual"}
};

const BSB_FSD_TD_IOM_URL="https://www.bsb-dampers.co.uk/wp-content/uploads/2024/07/fsd_td_iom.pdf";
const BSB_FSD_TD_SERIES_URL="https://www.bsb-dampers.co.uk/wp-content/uploads/2024/07/fsd_td_series.pdf";
const BSB_FD_SERIES_URL="https://www.bsb-dampers.co.uk/wp-content/uploads/2024/07/fd_series.pdf";
const BSB_FSD_TD_C_DIMENSIONS=Object.freeze({
  100:{a:84,b:41},150:{a:109,b:41},200:{a:84,b:41},250:{a:159,b:41},300:{a:184,b:41},350:{a:159,b:41},
  400:{a:184,b:55},450:{a:259,b:55},500:{a:284,b:55},550:{a:259,b:55},600:{a:284,b:55},650:{a:359,b:55},
  700:{a:384,b:55},750:{a:359,b:55},800:{a:384,b:55},850:{a:459,b:55},900:{a:484,b:55},950:{a:459,b:55},1000:{a:484,b:55}
});

function bsbFsdTdMethods(dryType="bsb-rect-dry",solidType="bsb-rect-solid"){
  return {
    M5:{label:"M5 — Drywall, non-cleated frameless",type:dryType,finishedW:121,finishedH:96,casingAddW:76,casingAddH:76,clearanceLeft:10,clearanceRight:35,clearanceBottom:10,clearanceTop:10,reference:"FSD-TD M5",wall:"Symmetrical drywall: 50 mm steel frame with two layers of 12.5 mm D&F fire board on each wall face. These wall-face layers are separate from the single aperture-lining board fitted around each internal edge",seal:"Two-layer plasterboard pattress each side; void filling is not required",classification:"See BSB method M5",note:"Finished aperture allows 10 mm top/bottom, 10 mm non-actuator side and 35 mm actuator side.",settingOut:{basis:"casing-edge",casingProjectionBottom:38,casingProjectionTop:38,bottomClearance:10,topClearance:10,source:"BSB FSD-TD IOM 8.1.2 and 8.2.9: finished aperture is nominal height +96 mm, with 10 mm clearance above and below the damper casing; the damper is centred vertically."}},
    M6:{label:"M6 — Drywall, pattress and cleat",type:dryType,finishedW:156,finishedH:96,casingAddW:76,casingAddH:76,clearanceLeft:40,clearanceRight:40,clearanceBottom:10,clearanceTop:10,reference:"FSD-TD M6",wall:"Symmetrical drywall: 50 mm steel frame with two layers of 12.5 mm D&F fire board on each wall face. These wall-face layers are separate from the single aperture-lining board fitted around each internal edge",seal:"Lined opening with tested pattress and cleat arrangement",classification:"See BSB method M6",note:"Use every fixing position and ensure screws pick up the aperture track.",settingOut:{basis:"casing-edge",casingProjectionBottom:38,casingProjectionTop:38,bottomClearance:10,topClearance:10,source:"BSB FSD-TD IOM 9.1: nominal height +96 mm, with 10 mm above and below the casing; the damper is centred vertically."}},
    M9:{label:"M9 — Drywall, AF Easy Fix angle frame",type:dryType,finishedW:122,finishedH:99,casingAddW:77,casingAddH:79,clearanceLeft:10,clearanceRight:35,clearanceBottom:10,clearanceTop:10,reference:"FSD-TD M9",wall:"Symmetrical drywall: 50 mm steel frame with two layers of 12.5 mm D&F fire board on each wall face. These wall-face layers are separate from the single aperture-lining board fitted around each internal edge",seal:"Lined opening; Easy Fix angle frame fixed through the tested pilot holes",classification:"See BSB method M9",note:"Finished aperture includes the manufacturer-specified installation gaps around the casing. Use the inner row of pilot holes for drywall.",settingOut:{basis:"casing-edge",casingProjectionBottom:39.5,casingProjectionTop:39.5,bottomClearance:10,topClearance:10,source:"BSB FSD-TD IOM 10.1: published finished opening is nominal +122 mm wide and +99 mm high, with 10 mm top/bottom, 10 mm non-actuator-side and 35 mm actuator-side casing clearances."}},
    M10:{label:"M10 — Masonry wall, AF Easy Fix angle frame",type:solidType,finishedW:122,finishedH:99,casingAddW:77,casingAddH:79,clearanceLeft:10,clearanceRight:35,clearanceBottom:10,clearanceTop:10,reference:"FSD-TD M10",wall:"Masonry wall matching the BSB tested construction",seal:"Easy Fix angle frame; void behind the frame does not require filling where stated",classification:"See BSB method M10",note:"Use the outer pilot holes and keep fixing anchors at least 20 mm from aperture edges.",settingOut:{basis:"casing-edge",casingProjectionBottom:39.5,casingProjectionTop:39.5,bottomClearance:10,topClearance:10,source:"BSB FSD-TD IOM 11.1: published finished opening is nominal +122 mm wide and +99 mm high, with 10 mm top/bottom, 10 mm non-actuator-side and 35 mm actuator-side casing clearances."}},
    M11:{label:"M11 — Masonry floor, AF Easy Fix angle frame",type:solidType,finishedW:122,finishedH:99,casingAddW:77,casingAddH:79,clearanceLeft:10,clearanceRight:35,clearanceBottom:10,clearanceTop:10,reference:"FSD-TD M11",wall:"Masonry floor, minimum 150 mm, density 580 kg/m³",seal:"Easy Fix angle frame; no need to fill the opening void",classification:"E 120 (ho i←o) S",note:"Finished aperture: nominal width +122 mm and nominal height +99 mm.",settingOut:{basis:"casing-edge",casingProjectionBottom:39.5,casingProjectionTop:39.5,bottomClearance:10,topClearance:10,source:"BSB FSD-TD IOM 12.1: published finished opening is nominal +122 mm wide and +99 mm high, with 10 mm top/bottom, 10 mm non-actuator-side and 35 mm actuator-side casing clearances."}}
  };
}

const FD_MANUFACTURERS={
  BSB:{label:"BSB",products:{
    "FSD-TD":{label:"FSD-TD-S — Rectangular-spigot fire/smoke damper",shape:"rect",variant:"S",manual:BSB_FSD_TD_IOM_URL,brochure:BSB_FSD_TD_SERIES_URL,guide:"BSB FSD-TD Installation, Operation and Maintenance Instructions",revision:"V62904",methods:bsbFsdTdMethods()},
    "FSD-TD-C":{label:"FSD-TD-C — Circular-spigot multiblade (listed Ø100–1000)",shape:"circle",variant:"C",manual:BSB_FSD_TD_IOM_URL,brochure:BSB_FSD_TD_SERIES_URL,guide:"BSB FSD-TD Series dimensions and Installation, Operation and Maintenance Instructions",revision:"FSD-TD Series V12607 • IOM V62904",dimensionTable:BSB_FSD_TD_C_DIMENSIONS,spigotOutsideAdd:-3,minSize:100,maxSize:1000,methods:bsbFsdTdMethods("bsb-fsd-td-c-dry","bsb-fsd-td-c-solid")},
    "FD-C-AF":{label:"FD-C-AF — FD Series curtain-blade, circular spigot, angle frame (Ø100–1000)",shape:"circle",variant:"C-AF",manual:BSB_FD_SERIES_URL,guide:"BSB FD Series dimensions and verified installation method drawings",revision:"FD Series V12607",spigotOutsideAdd:-3,minSize:100,maxSize:1000,methods:{
      M9:{label:"M9 — Drywall, angle frame, lined opening",type:"bsb-fd-c-af-dry",gapNominal:10,gapTolerance:5,reference:"FD M9",wall:"BSB FD M9 tested symmetrical drywall construction selected to match the required classification",seal:"Angle frame fixed to the supporting track; opening lined; no filling of the opening void required",note:"The manufacturer drawing specifies a 10 ±5 mm gap all around the rectangular damper casing. Match the single- or double-skin M9 sheet to the required wall construction.",settingOut:{basis:"casing-edge",casingProjectionBottom:29.5,casingProjectionTop:29.5,bottomClearance:10,topClearance:10,source:"BSB FD Series V12607 Type C dimensions and FD M9: circular spigot O.D. is nominal diameter -3 mm; rectangular casing extends 31 mm beyond the spigot at the bottom; finished lined aperture has 10 ±5 mm gap all around the casing."}},
      M10:{label:"M10 — Masonry wall, angle frame",type:"bsb-fd-c-af-solid",gapNominal:10,gapTolerance:5,reference:"FD M10",wall:"150 mm masonry wall, density 650 kg/m³, matching BSB FD M10",seal:"Angle frame fixed with the tested steel fixings; no filling of the opening void required",note:"The manufacturer drawing specifies a 10 ±5 mm gap all around the rectangular damper casing.",settingOut:{basis:"casing-edge",casingProjectionBottom:29.5,casingProjectionTop:29.5,bottomClearance:10,topClearance:10,source:"BSB FD Series V12607 Type C dimensions and FD M10: circular spigot O.D. is nominal diameter -3 mm; rectangular casing extends 31 mm beyond the spigot at the bottom; aperture has 10 ±5 mm gap all around the casing."}},
      M11:{label:"M11 — Masonry floor, angle frame",type:"bsb-fd-c-af-solid",gapNominal:10,gapTolerance:5,reference:"FD M11",wall:"150 mm masonry floor, density 580 kg/m³, matching BSB FD M11",seal:"Angle frame fixed with the tested steel fixings; no filling of the opening void required",note:"The manufacturer drawing specifies a 10 ±5 mm gap around the rectangular damper casing.",settingOut:{basis:"casing-edge",casingProjectionBottom:29.5,casingProjectionTop:29.5,bottomClearance:10,topClearance:10,source:"BSB FD Series V12607 Type C dimensions and FD M11: circular spigot O.D. is nominal diameter -3 mm; rectangular casing extends 31 mm beyond the spigot at the bottom; aperture has 10 ±5 mm gap around the casing."}}
    }},
    "FD-C":{label:"FD-C — FD-C Series externally resettable circular single-blade (Ø100–315)",shape:"circle",manual:"https://www.bsb-dampers.co.uk/wp-content/uploads/2024/07/fd_c_series_iom.pdf",guide:"BSB FD-C Installation, Operation and Maintenance Instructions",revision:"V62904",minSize:100,maxSize:315,methods:{
      M9:{label:"M9 — Drywall partition, lined opening",type:"bsb-circle-dry-lined",add:20,reference:"FD-C M9",wall:"Fire-rated drywall supporting construction",seal:"10 mm nominal gap all round; opening lined with fire-rated wall board",note:"Finished aperture is square and nominal diameter +20 mm.",settingOut:{basis:"nominal-duct",bottomFinished:10,topFinished:10,source:"BSB FD-C M9: 10 mm nominal gap all round"}},
      M10:{label:"M10 — Masonry wall",type:"bsb-circle-solid",add:20,reference:"FD-C M10",settingOut:{basis:"nominal-duct",bottomFinished:10,topFinished:10,source:"BSB FD M10: opening is 10 mm larger than the casing on each side and the damper is centred."},wall:"Masonry wall matching the tested detail",seal:"Follow the tested BSB masonry sealing and plate fixing arrangement",note:"Opening is nominal diameter +20 mm."},
      M11:{label:"M11 — Masonry floor",type:"bsb-circle-solid",add:20,reference:"FD-C M11",settingOut:{basis:"nominal-duct",bottomFinished:10,topFinished:10,source:"BSB FD M11: opening is 10 mm larger than the casing on each side and the damper is centred."},wall:"Concrete/masonry floor matching the tested detail",seal:"Follow the tested BSB floor sealing and plate fixing arrangement",note:"Opening is nominal diameter +20 mm."},
      M14:{label:"M14 — Flexible fire curtain",type:"bsb-circle-trim",add:10,reference:"FD-C M14",wall:"Tested flexible fire-curtain construction",seal:"Trim opening to the BSB tested fire-curtain detail",note:"Use nominal diameter with up to 10 mm trim tolerance."}
    }},
    "FSD-C":{label:"FSD-C — Circular single-blade fire/smoke damper (Ø100–315)",shape:"circle",manual:"https://www.bsb-dampers.co.uk/wp-content/uploads/2024/07/fsd_c_iom_11zon.pdf",guide:"BSB FSD-C Installation, Operation and Maintenance Instructions",revision:"V62904",minSize:100,maxSize:315,methods:{
      M9:{label:"M9 — Drywall partition, lined opening",type:"bsb-circle-dry-lined",add:20,reference:"FSD-C M9",wall:"Fire-rated drywall supporting construction",seal:"10 mm nominal gap all round; line opening to the tested BSB detail",note:"Use every installation-plate fixing position.",settingOut:{basis:"nominal-duct",bottomFinished:10,topFinished:10,source:"BSB FSD-C M9: 10 mm nominal gap all round"}},
      M10:{label:"M10 — Masonry wall",type:"bsb-circle-solid",add:20,reference:"FSD-C M10",settingOut:{basis:"nominal-duct",bottomFinished:10,topFinished:10,source:"BSB FSD-C M10: nominal diameter +20 mm opening, damper centred."},wall:"Masonry wall matching the tested detail",seal:"Tested plate and penetration-seal arrangement",note:"Opening is nominal diameter +20 mm."},
      M11:{label:"M11 — Masonry floor / Batt infill",type:"bsb-circle-solid",add:20,reference:"FSD-C M11",wall:"Masonry floor matching the tested detail",seal:"Ablative Batt infill where required by the selected drawing",note:"Use all fixing holes and the exact Batt arrangement."},
      M14:{label:"M14 — Flexible fire curtain",type:"bsb-circle-trim",add:10,reference:"FSD-C M14",wall:"Tested flexible fire-curtain construction",seal:"Trim and fix only as shown in the BSB drawing",note:"Use nominal diameter with up to 10 mm trim tolerance."}
    }},
    "MFD-IC":{label:"MFD-IC — Motorised insulated circular fire damper",shape:"circle",manual:"https://www.bsb-dampers.co.uk/wp-content/uploads/2026/06/MFD-IC-IOM.pdf",guide:"BSB MFD-IC Installation, Operation and Maintenance Instructions",revision:"V012606",minSize:100,maxSize:315,methods:{
      M9:{label:"M9 — Drywall, Batt installation — opening NOT lined",type:"bsb-circle-square-table",openingTable:{100:140,125:165,150:190,160:200,200:240,250:290,300:340,315:355},settingOut:{basis:"table-centred",source:"BSB MFD-IC M9 opening table; damper positioned centrally and opening is not lined."},reference:"MFD-IC M9",wall:"Group A 50 mm steel stud; 2 × 12.5 mm Type F board each side",seal:"Two layers of 50 mm ablative-coated Batt; seal exposed insulation faces",note:"The wall opening must not be lined. Fix the plate into the steel track using all applicable holes."},
      M10:{label:"M10 — Masonry wall, Batt infill",type:"bsb-circle-square-table",openingTable:{100:140,125:165,150:190,160:200,200:240,250:290,300:340,315:355},settingOut:{basis:"table-centred",source:"BSB MFD-IC M10 opening table; damper positioned centrally."},reference:"MFD-IC M10",wall:"Masonry wall, minimum 100 mm and density 600 kg/m³",seal:"Ablative-coated Batt infill",note:"Use fire-rated steel anchors and all fixing positions."},
      M11:{label:"M11 — Masonry floor, Batt infill",type:"bsb-circle-square-table",openingTable:{100:140,125:165,150:190,160:200,200:240,250:290,300:340,315:355},settingOut:{basis:"table-centred",source:"BSB MFD-IC M11 opening table; damper positioned centrally."},reference:"MFD-IC M11",wall:"Concrete floor, minimum 150 mm and density 600 kg/m³",seal:"Ablative-coated Batt infill",note:"Use fire-rated steel anchors and all fixing positions."},
      M15:{label:"M15 — Masonry floor, mortar infill",type:"bsb-circle-round-table",openingTable:{100:178.5,125:203.5,150:228.5,160:238.5,200:278.5,250:328.5,300:378.5,315:393.5},settingOut:{basis:"table-centred",source:"BSB MFD-IC M15 published round opening table; damper positioned centrally."},reference:"MFD-IC M15",wall:"Concrete floor, minimum 150 mm and density 600 kg/m³",seal:"Tested mortar infill arrangement",note:"Follow the current M15 drawing for mortar depth and fixing detail."}
    }},
    "AT-FSD":{label:"AT-FSD — Air-transfer fire/smoke damper",shape:"rect",manual:"https://www.bsb-dampers.co.uk/wp-content/uploads/2024/07/at_fsd_iom_compressed.pdf",guide:"BSB AT-FSD Installation, Operation and Maintenance Instructions",revision:"V12204",methods:{
      M9:{label:"M9 — Drywall, fully lined unducted opening",type:"bsb-at-dry",reference:"AT-FSD M9",wall:"Tested drywall construction, fully lined on all four internal sides",seal:"No intumescent mastic is required for fire integrity; it may be used only where an airtight everyday joint is required",classification:"E 120 (ve i→o) S",note:"Actual sleeve is 10 mm below nominal size, giving 5 mm clearance per side. Finished aperture is the ordered nominal size with the BSB +5/-0 mm tolerance.",settingOut:{basis:"nominal-duct",bottomFinished:0,topFinished:0,source:"BSB AT-FSD IOM 10.7–10.9: finished aperture is nominal size and the sleeve is nominal minus 10 mm."}},
      M10:{label:"M10 — Masonry wall, unducted opening",type:"bsb-at-solid",reference:"AT-FSD M10",wall:"Masonry/concrete wall with lintel over the aperture where required",seal:"No intumescent mastic is required for fire integrity; it may be used only where an airtight everyday joint is required",classification:"E 120 (ve i→o) S",note:"Use 5 mm diameter × 40 mm minimum steel fixings through the outer flange holes. Actual sleeve is 10 mm below nominal size.",settingOut:{basis:"nominal-duct",bottomFinished:0,topFinished:0,source:"BSB AT-FSD IOM 10.7–10.8 and M10 drawing."}}
    }}
  }},
  ADVANCED_AIR:{label:"Advanced Air",products:{
    "0160":{label:"0160 — Curtain fire damper",shape:"rect",documentId:"IOM_0160",manual:ADVANCED_AIR_DOCUMENTS.IOM_0160.url,manualTitle:ADVANCED_AIR_DOCUMENTS.IOM_0160.title,guide:"Advanced Air 0160 Installation, Operation and Maintenance Manual",revision:"Rev 1.1 • April 2026",methods:{
      AFS_60:{label:"AFS — 60 minute flexible/rigid wall",type:"advanced-rect-table",tableRule:"AA0160_AFS",reference:"0160 AFS • E60",wall:"Flexible or rigid supporting construction, minimum 94 mm",seal:"Two layers of 50 mm, 140 kg/m³ coated fire batt with tested intumescent sealant",classification:"E60",note:"Opening shown is the manufacturer table minimum. Letterbox lining is part of the wall construction and is not added again by VentTools."},
      AFS_120:{label:"AFS — 120 minute flexible/rigid wall",type:"advanced-rect-table",tableRule:"AA0160_AFS",reference:"0160 AFS • E120",wall:"Flexible or rigid supporting construction, minimum 131 mm",seal:"Two layers of 50 mm, 140 kg/m³ coated fire batt with tested intumescent sealant",classification:"E120",note:"Opening shown is the manufacturer table minimum. Letterbox lining is part of the wall construction and is not added again by VentTools."},
      TRIMOTERM:{label:"Trimoterm wall — E120",type:"advanced-rect-fixed",addW:55,addH:55,tolerance:10,reference:"0160 Trimoterm • E120",wall:"Trimoterm sandwich panel, minimum 120 mm",seal:"Tested capping, Astroflame Astro INTU Mastic or equivalent, and retaining flanges",classification:"E120",note:"Opening is nominal width and height +55 mm, tolerance ±10 mm."}
    }},
    "2530":{label:"2530 — Motorised fire damper",shape:"rect",documentId:"IOM_2530",manual:ADVANCED_AIR_DOCUMENTS.IOM_2530.url,manualTitle:ADVANCED_AIR_DOCUMENTS.IOM_2530.title,guide:"Advanced Air 2530 Installation, Operation and Maintenance Manual",revision:"Rev 1.1 • April 2026",methods:{
      AFS:{label:"AFS — flexible/rigid wall",type:"advanced-rect-table",tableRule:"AA2530_AFS",reference:"2530 AFS",wall:"Flexible or rigid wall matching the selected 60/120 minute tested construction",seal:"Two layers of 50 mm, 140 kg/m³ coated fire batt with tested intumescent sealant",classification:"E60/E120 S",note:"The opening shown is the published minimum for the entered nominal size. The AFS frame and fire-batt zone are already included."},
      HEVAC:{label:"HEVAC frame — rigid wall E120",type:"advanced-rect-table",tableRule:"AA2530_HEVAC",reference:"2530 HEVAC • E120",wall:"Rigid wall, minimum 150 mm",seal:"HEVAC frame with turnback tabs and 4:1 mortar mix",classification:"E120 S",note:"The damper must remain able to move within the HEVAC frame. Do not fill mortar onto the damper spigots."}
    }},
    "26SCD":{label:"26SCD — Smoke control damper",shape:"rect",documentId:"IOM_26SCD",manual:ADVANCED_AIR_DOCUMENTS.IOM_26SCD.url,manualTitle:ADVANCED_AIR_DOCUMENTS.IOM_26SCD.title,guide:"Advanced Air 26SCD Installation, Operation and Maintenance Manual",revision:"Rev 1.0 • April 2026",methods:{
      AFS_FLEX:{label:"AFS — two-hour flexible wall",type:"advanced-26scd-afs",reference:"26SCD IOM page 5 • E120 S500",wall:"Flexible supporting construction, minimum 122 mm; minimum 150 mm for multi-section dampers",seal:"Two layers of 50 mm, 140 kg/m³ fire batt with fire-batt sealant and intumescent mastic",classification:"E120 S500",dynamicSettingOut:true,note:"Published minimum and maximum openings are based on the damper being centralised in the opening."},
      AFS_RIGID:{label:"AFS — two-hour rigid wall",type:"advanced-26scd-afs",reference:"26SCD IOM page 6 • E120 S500",wall:"Rigid blockwork, masonry or homogeneous concrete wall, minimum 122 mm; minimum 150 mm for multi-section dampers",seal:"Two layers of 50 mm, 140 kg/m³ fire batt with fire-batt sealant and intumescent mastic",classification:"E120 S500",dynamicSettingOut:true,note:"Published minimum and maximum openings are based on the damper being centralised in the opening."},
      REMOTE_INLINE:{label:"Remote from wall — duct mounted in-line",type:"advanced-26scd-remote",reference:"26SCD IOM page 7 • E120 S500",wall:"Remote duct-mounted installation using fire-rated ductwork tested to BS EN 1366-8",seal:"Ductwork and insulation system to the tested duct supplier's installation",classification:"E120 S500",settingOut:{basis:"not-applicable",source:"26SCD IOM page 7: remote duct-mounted in-line method; no separate damper wall opening is formed."},note:"The damper is supported in-line in the fire-rated ductwork. No separate builder opening is calculated for the damper body."},
      REMOTE_SIDE:{label:"Remote from wall — duct mounted side",type:"advanced-26scd-remote",reference:"26SCD IOM page 8 • E120 S500",wall:"Remote side-mounted installation using fire-rated ductwork tested to BS EN 1366-8",seal:"High-temperature ceramic sealant at damper-to-duct joint; tested duct insulation system",classification:"E120 S500",settingOut:{basis:"not-applicable",source:"26SCD IOM page 8: remote duct-mounted side method; no separate damper wall opening is formed."},note:"The damper is mounted to the side of the fire-rated ductwork and independently supported. No separate builder opening is calculated for the damper body."}
    }},
    "0400MAN":{label:"0400MAN — Circular fire damper",shape:"circle",documentId:"IOM_0400_0500",manual:ADVANCED_AIR_DOCUMENTS.IOM_0400_0500.url,manualTitle:ADVANCED_AIR_DOCUMENTS.IOM_0400_0500.title,guide:"Advanced Air 0400/0500 Installation, Operation and Maintenance Manual",revision:"Rev 1.1 • December 2025",minSize:100,maxSize:315,methods:{
      FLEX_60:{label:"60 minute flexible wall — square letterbox",type:"advanced-circle-fixed",add:55,openingShape:"square",reference:"0400MAN flexible wall • E60",wall:"Flexible wall, minimum 106 mm, two layers of 12.5 mm Type F board each side",seal:"Two layers of 50 mm, 140 kg/m³ fire batt",note:"Manufacturer opening to form: nominal diameter +55 mm, square, tolerance ±4 mm."},
      FLEX_120:{label:"120 minute flexible wall — square letterbox",type:"advanced-circle-fixed",add:55,openingShape:"square",reference:"0400MAN flexible wall • E120",wall:"Flexible wall, minimum 131 mm, two layers of 15 mm Type F board each side",seal:"Two layers of 50 mm, 140 kg/m³ fire batt",note:"Manufacturer opening to form: nominal diameter +55 mm, square, tolerance ±4 mm."},
      RIGID_60:{label:"60 minute rigid wall — square/circular opening",type:"advanced-circle-fixed",add:35,openingShape:"square",reference:"0400MAN rigid wall • E60",wall:"Rigid wall, minimum 106 mm",seal:"Two layers of 50 mm, 140 kg/m³ fire batt",note:"Manufacturer opening: nominal diameter +35 mm; stated tolerance ±25 mm."},
      RIGID_120:{label:"120 minute rigid wall — square/circular opening",type:"advanced-circle-fixed",add:35,openingShape:"square",reference:"0400MAN rigid wall • E120",wall:"Rigid wall, minimum 131 mm",seal:"Two layers of 50 mm, 140 kg/m³ fire batt",note:"Manufacturer opening: nominal diameter +35 mm; stated tolerance ±25 mm."}
    }},
    "0400FME":{label:"0400FME — Circular motorised fire damper",shape:"circle",documentId:"IOM_0400_0500",manual:ADVANCED_AIR_DOCUMENTS.IOM_0400_0500.url,manualTitle:ADVANCED_AIR_DOCUMENTS.IOM_0400_0500.title,guide:"Advanced Air 0400/0500 Installation, Operation and Maintenance Manual",revision:"Rev 1.1 • December 2025",minSize:100,maxSize:315,methods:{
      FLEX_60:{label:"60 minute flexible wall — square letterbox",type:"advanced-circle-fixed",add:55,openingShape:"square",reference:"0400FME flexible wall • E60 S",wall:"Flexible wall, minimum 106 mm",seal:"Two layers of 50 mm, 140 kg/m³ fire batt",note:"Manufacturer opening to form: nominal diameter +55 mm, square."},
      FLEX_120:{label:"120 minute flexible wall — square letterbox",type:"advanced-circle-fixed",add:55,openingShape:"square",reference:"0400FME flexible wall • E120 S",wall:"Flexible wall, minimum 131 mm",seal:"Two layers of 50 mm, 140 kg/m³ fire batt",note:"Manufacturer opening to form: nominal diameter +55 mm, square."},
      RIGID_60:{label:"60 minute rigid wall — square/circular opening",type:"advanced-circle-fixed",add:35,openingShape:"square",reference:"0400FME rigid wall • E60 S",wall:"Rigid wall, minimum 106 mm",seal:"Two layers of 50 mm, 140 kg/m³ fire batt",note:"Manufacturer opening: nominal diameter +35 mm; published tolerance ±25 mm."},
      RIGID_120:{label:"120 minute rigid wall — square/circular opening",type:"advanced-circle-fixed",add:35,openingShape:"square",reference:"0400FME rigid wall • E120 S",wall:"Rigid wall, minimum 131 mm",seal:"Two layers of 50 mm, 140 kg/m³ fire batt",note:"Manufacturer opening: nominal diameter +35 mm; published tolerance ±25 mm."}
    }},
    "0500MAN":{label:"0500MAN — Circular floor fire damper",shape:"circle",documentId:"IOM_0400_0500",manual:ADVANCED_AIR_DOCUMENTS.IOM_0400_0500.url,manualTitle:ADVANCED_AIR_DOCUMENTS.IOM_0400_0500.title,guide:"Advanced Air 0400/0500 Installation, Operation and Maintenance Manual",revision:"Rev 1.1 • December 2025",minSize:100,maxSize:315,methods:{
      FLOOR:{label:"Rigid floor — compound infill E120",type:"advanced-circle-floor",add:10,reference:"0500MAN floor • E120",wall:"Aerated concrete floor, minimum 150 mm, density 575 kg/m³ ±50 kg/m³",seal:"Silverseal HS Compound, minimum 100 mm thick",note:"Minimum opening is nominal diameter +10 mm. Maximum permitted opening is 1800 × 1800 mm."}
    }},
    "0500FME":{label:"0500FME — Circular motorised floor fire damper",shape:"circle",documentId:"IOM_0400_0500",manual:ADVANCED_AIR_DOCUMENTS.IOM_0400_0500.url,manualTitle:ADVANCED_AIR_DOCUMENTS.IOM_0400_0500.title,guide:"Advanced Air 0400/0500 Installation, Operation and Maintenance Manual",revision:"Rev 1.1 • December 2025",minSize:100,maxSize:315,methods:{
      FLOOR:{label:"Rigid floor — compound infill E120 S",type:"advanced-circle-floor",add:10,reference:"0500FME floor • E120 S",wall:"Aerated concrete floor, minimum 150 mm, density 575 kg/m³ ±50 kg/m³",seal:"Silverseal HS Compound, minimum 100 mm thick",note:"Minimum opening is nominal diameter +10 mm. Maximum permitted opening is 1800 × 1800 mm."}
    }}
  }},
  ACTIONAIR:{label:"Swegon (Actionair products)",products:{
    CSS:{label:"CSS — Circular fire/smoke damper",shape:"circle",manual:"https://www.swegon.com/globalassets/digizuite/10514-en-css_installation_en.pdf",guide:"Actionair CSS Installation Guide",revision:"LNNN00356 v6.0 • 27 May 2025",methods:{
      CSS_DRY:{label:"Vertical — plasterboard wall",type:"css-dry",reference:"AA/F13440 / AA/F12820",min:10,max:40,step:10,defaultAllowance:30,dynamicSettingOut:true},
      CSS_MASONRY:{label:"Vertical — masonry wall",type:"css-masonry",reference:"AA/F12822",squareMin:10,squareMax:40,circleMin:10,circleMax:30,step:10,defaultAllowance:30,dynamicSettingOut:true},
      CSS_SLAB:{label:"Horizontal — concrete slab",type:"css-slab",reference:"AA/F12821",squareMin:10,squareMax:30,step:10,defaultAllowance:20,dynamicSettingOut:true}
    }},
    "DWFX-F":{label:"DWFX-F / DWFX-3F — Rectangular",shape:"rect",manual:"https://www.swegon.com/globalassets/digizuite/10506-en-smokeshield_fireshield_dwfx-f_installation_en.pdf",guide:"Actionair DWFX-F Installation Guide",revision:"LNNN00354 v6.0 • 17 March 2026",methods:{
      DW_DRY_1:{label:"Vertical plasterboard wall — 1 × Type F board each face",type:"dwfx-dry-fixed",referenceSmoke:"AA/F13412",referenceFire:"AA/F13440",w:30,h:30,boardsW:2,boardsH:2,dynamicSettingOut:true},
      DW_DRY_2:{label:"Vertical plasterboard wall — 2 × Type F boards each face",type:"dwfx-dry-range",referenceSmoke:"AA/F10704",referenceFire:"AA/F10705",smokeW:[10,52],smokeH:[10,40],fireW:[10,40],fireH:[10,40],boardsW:2,boardsH:2,dynamicSettingOut:true},
      DW_UNDER_DRY:{label:"DWFX-3F plasterboard wall under concrete slab",type:"dwfx-under-dry",referenceSmoke:"AA/F11945",referenceFire:"AA/F11944",smokeW:[10,57],smokeH:[10,30],fireW:[10,60],fireH:[5,30],boardsW:2,boardsH:1,dynamicSettingOut:true},
      DW_UNDER_MASONRY:{label:"DWFX-3F masonry wall under concrete slab",type:"dwfx-range",referenceSmoke:"AA/F12394",referenceFire:"AA/F12827",smokeW:[10,57],smokeH:[5,30],fireW:[10,80],fireH:[5,40],boardsW:0,boardsH:0,dynamicSettingOut:true},
      DW_SHAFT:{label:"DWFX-F plasterboard shaftwall — SmokeShield only",type:"dwfx-fixed",referenceSmoke:"AA/F13472",smokeOnly:true,w:30,h:30,boardsW:2,boardsH:2,dynamicSettingOut:true},
      DW_COMPOSITE:{label:"DWFX-F composite panel wall — SmokeShield only",type:"dwfx-fixed",referenceSmoke:"AA/F13396",smokeOnly:true,w:52,h:60,boardsW:0,boardsH:0,dynamicSettingOut:true},
      DW_MASONRY_LINK:{label:"DWFX-F masonry wall — use official hole sizer / drawing",type:"dwfx-link",referenceSmoke:"AA/F12493",referenceFire:"AA/F10707"},
      DW_TIMBER_LINK:{label:"DWFX-F timber stud partition — official drawing required",type:"dwfx-link",referenceSmoke:"AA/F13752",smokeOnly:true}
    }},
    "SPAN":{label:"SPAN — SmokeShield builder's opening",shape:"span",manual:"https://www.swegon.com/uk/products/fire-and-smoke-control/fire-and-smoke-dampers/fire-dampers/smokeshield/",guide:"Actionair SPAN builder's opening data",revision:"VentTools checked against uploaded Actionair V5 opening calculator",methods:{
      SPAN_STANDARD:{label:"SPAN slab installation — recommended opening",type:"actionair-span",reference:"SmokeShield PTC SPAN"}
    }},
    "HEVAC-IF":{label:"HEVAC / HVCA Installation Frame — Rectangular",shape:"rect",manual:"https://www.swegon.com/globalassets/digizuite/10508-en-smokeshield_hevac_hvca_installation_en.pdf",guide:"Actionair I/F Installation Guide",revision:"LNNN00352 v5.1 • 26 May 2022",methods:{
      HEVAC_WALL:{label:"Vertical installation frame in masonry wall",type:"hevac-frame",referenceSmoke:"AA/F10702",referenceFire:"AA/F10703",dynamicSettingOut:true},
      HEVAC_SLAB:{label:"Horizontal installation frame in concrete slab — FireShield only",type:"hevac-frame",referenceFire:"AA/F10701",fireOnly:true,dynamicSettingOut:true}
    }}
  }},
  LINDAB:{label:"Lindab",products:{
    "FNC1":{label:"FNC1 — Circular 300 Pa",shape:"circle",manual:"https://www.lindab.com/globalassets/commerce/lindabwebproductsdoc/assets/production/ywe3nwrhmtqtmgmwoc00njm2ltliotatywzjzjiwmty0otdh/5249534188784331220/fnc1_booklet_document_en_l.pdf?v=1783815510",guide:"Lindab FNC1 Installation Booklet",revision:"1MUBFNC1EN-LIND rev 20-12",minSize:100,maxSize:400,methods:{
      FNC1_WET30:{label:"Rigid/flexible wall — wet or rock wool seal",type:"lindab-circle-fixed",reference:"EI 60 S",add:30,openingShape:"circle",note:"Wall minimum thickness 95 mm."},
      FNC1_DRY10:{label:"Rigid/flexible wall — acrylic dry seal",type:"lindab-circle-fixed",reference:"EI 60 S",add:10,openingShape:"circle",note:"Wall minimum thickness 95 mm."},
      FNC1_FLOOR:{label:"Floor — mortar/plaster/rock wool seal",type:"lindab-circle-range",reference:"EI 60 S",minAdd:30,maxAdd:55,recommendedAdd:30,openingShape:"circle",note:"Floor minimum thickness 100 mm; density 550 kg/m³."}
    }},
    "WH25":{label:"WH25 — Circular 500 Pa",shape:"circle",manual:"https://www.lindab.com/globalassets/commerce/lindabwebproductsdoc/assets/production/ntaxztfkngitmzcwny00n2yxlwflodutzmm4mtqyowvlyju0/5249534188948240062/wh25_booklet_document_en_l.pdf?v=1783815573",guide:"Lindab WH25 Installation Booklet",revision:"1MUBWH25EN-LIND rev 20-10",minSize:100,maxSize:315,methods:{
      WH25_RIGID_WET:{label:"Rigid wall — mortar/plaster seal",type:"lindab-circle-range",reference:"EI 120 S",minAdd:25,maxAdd:440,recommendedAdd:25,openingShape:"circle",note:"Wall minimum thickness 100 mm; density 550 kg/m³."},
      WH25_RIGID_DRY:{label:"Rigid wall — plasterboard and rock wool",type:"lindab-circle-square-range",reference:"EI 90 S",minAdd:50,maxAdd:70,recommendedAdd:50,note:"Square opening. Wall minimum thickness 100 mm."},
      WH25_FLOOR:{label:"Floor — mortar seal",type:"lindab-circle-range",reference:"EI 90/120 S",minAdd:25,maxAdd:35,recommendedAdd:25,openingShape:"circle",note:"Floor minimum thickness 100 mm for EI90 or 150 mm for EI120."}
    }},
    "WH45":{label:"WH45 — Circular 500 Pa",shape:"circle",manual:"https://www.lindab.com/globalassets/commerce/lindabwebproductsdoc/assets/production/ytgxowu4ytgtmwviyi00otk0lwe4mzqtyjjhmja0ymqwmgy4/5249534189216862126/wh45_booklet_document_en_l.pdf?v=1783815574",guide:"Lindab WH45 Installation Booklet",revision:"1MUBWH45EN-LIND rev 20-10",minSize:200,maxSize:800,methods:{
      WH45_RIGID_DRY:{label:"Rigid/flexible wall — plasterboard and rock wool",type:"lindab-circle-square-range",reference:"EI 90 S",minAdd:35,maxAdd:50,recommendedAdd:35,note:"Square opening. Wall minimum thickness 100 mm."},
      WH45_RIGID_WET:{label:"Rigid/flexible wall — mortar or plaster",type:"lindab-circle-range",reference:"EI 120 S",minAdd:25,maxAdd:580,recommendedAdd:25,openingShape:"circle",note:"Wall minimum thickness 100 mm."},
      WH45_FLOOR:{label:"Floor — mortar seal",type:"lindab-circle-range",reference:"EI 90/120/180 S",minAdd:40,maxAdd:55,recommendedAdd:40,openingShape:"circle",note:"Floor minimum thickness 100 or 150 mm depending on classification."}
    }},
    "WK25":{label:"WK25 — Rectangular 500 Pa",shape:"rect",manual:"https://www.lindab.com/globalassets/commerce/lindabwebproductsdoc/assets/production/mme2zdgzzjuty2u2ns00ndu4ltgzzwmtzjrjyzu4zmfmm2y3/5250840905260342233/wk25_booklet_document_en_l.pdf?v=1783821298",guide:"Lindab WK25 Installation Booklet",revision:"1MUBWK25EN-LIND rev 25-03",methods:{
WK25_RIGID_WET:{label:"Rigid wall — inside — mortar/plaster",type:"wk25-range",reference:"EI 120 S • 500 Pa • page 26",minW:50,maxW:440,minH:50,maxH:440,recommendedW:50,recommendedH:50,wall:"Rigid wall, minimum 100 mm, 550 kg/m³",seal:"Mortar or plaster putty",spacingA:44,spacingB:75,pairAllowed:true,note:"Single or approved paired assembly."},
WK25_RIGID_DRY:{label:"Rigid wall — inside — rock wool/plasterboard",type:"wk25-range",reference:"EI 120 S • 500 Pa • page 26",minW:50,maxW:70,minH:50,maxH:70,recommendedW:50,recommendedH:50,wall:"Rigid wall, minimum 100 mm, 550 kg/m³",seal:"100 kg/m³ rock wool with plasterboard or calcium silicate",spacingA:44,spacingB:75,pairAllowed:true,note:"Single or approved paired assembly."},
WK25_RIGID_WEICH:{label:"Rigid wall — inside — Fire Batt / Weichschott",type:"wk25-fixed",reference:"EI 120 S • 300 Pa • page 27",w:800,h:800,wall:"Rigid wall, minimum 100 mm, 550 kg/m³",seal:"140 kg/m³ rock-wool boards with approved coating/sealant",spacingA:44,spacingB:50,pairAllowed:true,note:"Fixed square opening allowance."},
WK25_RIGID_ON:{label:"Rigid wall — face mounted — KITFP",type:"wk25-fixed",reference:"EI 90 S • 300 Pa • page 28",w:50,h:50,wall:"Rigid wall, minimum 100 mm",seal:"Factory-fitted face-wall kit with mortar wall seal",spacingA:165,spacingB:80,pairAllowed:false,note:"KITFP must be factory assembled."},
WK25_RIGID_REMOTE_WET:{label:"Rigid wall — remote — mortar/plaster",type:"wk25-range",reference:"EI 90/120 S • page 29",minW:50,maxW:440,minH:50,maxH:440,recommendedW:50,recommendedH:50,wall:"Rigid wall, minimum 100 mm, 550 kg/m³",seal:"140 kg/m³ duct insulation with approved coating; mortar/plaster wall seal",spacingA:200,spacingB:110,pairAllowed:false,note:"Follow official suspension and distance details."},
WK25_RIGID_REMOTE_WEICH:{label:"Rigid wall — remote — Fire Batt / Weichschott",type:"wk25-fixed",reference:"EI 90/120 S • page 30",w:800,h:800,wall:"Rigid wall, minimum 100 mm, 550 kg/m³",seal:"140 kg/m³ duct insulation and Weichschott wall seal",spacingA:200,spacingB:110,pairAllowed:false,note:"Remote installation."},
WK25_RIGID_REMOTE_KIT:{label:"Rigid wall — remote — KITFP + Promat 478",type:"wk25-fixed",reference:"EI 90 S • page 31",w:50,h:50,wall:"Rigid wall, minimum 100 mm",seal:"Factory KITFP; Promat 478 duct insulation; mortar wall seal",spacingA:165,spacingB:80,pairAllowed:false,note:"Use specified KITSRP components."},
WK25_LIGHTF_DRY:{label:"Light wall type F — inside — rock wool/plasterboard",type:"wk25-range",reference:"EI 120 S • 500 Pa • page 32",minW:75,maxW:95,minH:75,maxH:95,recommendedW:75,recommendedH:75,wall:"Light wall type F, minimum 100 mm",seal:"100 kg/m³ rock wool with plasterboard both sides or calcium silicate",spacingA:44,spacingB:75,pairAllowed:true,note:"Single or approved paired assembly."},
WK25_LIGHTF_WET:{label:"Light wall type F — inside — mortar/plaster",type:"wk25-range",reference:"EI 120 S • 500 Pa • page 32",minW:75,maxW:440,minH:75,maxH:440,recommendedW:75,recommendedH:75,wall:"Light wall type F, minimum 100 mm",seal:"Mortar or plaster putty",spacingA:44,spacingB:75,pairAllowed:true,note:"Single or approved paired assembly."},
WK25_LIGHT_REMOTE_DRY:{label:"Light wall — remote — rock wool/plasterboard",type:"wk25-range",reference:"EI 90/120 S • page 39",minW:75,maxW:95,minH:75,maxH:95,recommendedW:75,recommendedH:75,wall:"Certified light wall, minimum 100 mm",seal:"100 kg/m³ wall infill; 140 kg/m³ insulated duct with approved coating",spacingA:200,spacingB:110,pairAllowed:false,note:"Maximum wall distance 1000 mm; maximum connected duct 2100 mm."},
WK25_LIGHT_REMOTE_WET:{label:"Light wall — remote — mortar/plaster",type:"wk25-range",reference:"EI 90/120 S • page 39",minW:75,maxW:440,minH:75,maxH:440,recommendedW:75,recommendedH:75,wall:"Certified light wall, minimum 100 mm",seal:"Mortar/plaster wall seal; 140 kg/m³ insulated duct with approved coating",spacingA:200,spacingB:110,pairAllowed:false,note:"Maximum wall distance 1000 mm; maximum connected duct 2100 mm."},
WK25_GYPSUM_DRY:{label:"Solid gypsum-block wall — inside",type:"wk25-range",reference:"EI 120 S • manual method",minW:75,maxW:95,minH:75,maxH:95,recommendedW:75,recommendedH:75,wall:"Solid gypsum blocks, minimum 100 mm, 995 kg/m³",seal:"Plasterboard on both sides",spacingA:44,spacingB:75,pairAllowed:true,note:"Approved paired assembly permitted."},
WK25_GYPSUM_WEICH:{label:"Solid gypsum-block wall — Fire Batt / Weichschott",type:"wk25-fixed",reference:"EI 120 S • manual method",w:800,h:800,wall:"Solid gypsum blocks, minimum 100 mm, 995 kg/m³",seal:"140 kg/m³ rock-wool boards with approved coating/sealant",spacingA:44,spacingB:50,pairAllowed:true,note:"Fixed square opening allowance."},
WK25_SHAFT:{label:"Shaft wall — inside",type:"wk25-range",reference:"EI 60 S • manual method",minW:75,maxW:95,minH:75,maxH:95,recommendedW:75,recommendedH:75,wall:"Certified shaft-wall construction",seal:"Mortar or plaster putty on motor side",spacingA:200,spacingB:75,pairAllowed:false,note:"Paired installation not permitted."},
WK25_FLOOR_WET:{label:"Floor — inside slab — mortar",type:"wk25-range",reference:"EI 90/120/180 S • floor methods",minW:50,maxW:440,minH:50,maxH:440,recommendedW:50,recommendedH:50,wall:"Certified floor; required thickness/density depends on EI rating",seal:"Mortar",spacingC:44,spacingD:75,pairAllowed:true,note:"Paired assembly permitted with separate ducts."},
WK25_FLOOR_WEICH:{label:"Floor — Fire Batt / Weichschott",type:"wk25-fixed",reference:"EI 120 S • floor method",w:800,h:800,wall:"Certified floor construction",seal:"140 kg/m³ rock-wool boards with approved coating/sealant",spacingC:200,spacingD:75,pairAllowed:false,note:"Paired installation not permitted."}
}},
    "WK45":{label:"WK45 — Rectangular 500/300 Pa",shape:"rect",manual:"https://www.lindab.com/globalassets/commerce/lindabwebproductsdoc/assets/production/yzk1nduxndytztk1my00odhlltlkztutztdkyweymta3zti5/5250833076614407765/wk45_booklet_document_en_l.pdf?v=1783821283",guide:"Lindab WK45 Installation Booklet",revision:"1MUBWK45EN-LIND rev 25-12",methods:{
      WK45_RIGID_180:{label:"Rigid wall 140 mm — mortar — EI 180 S",type:"lindab-rect-range",reference:"EI 180 S • 500 Pa • page 22",minW:80,maxW:110,minH:80,maxH:110,recommendedW:80,recommendedH:80,wall:"Rigid wall, minimum 140 mm, minimum density 550 kg/m³",seal:"Mortar",spacing:0,edge:75,classification:"EI 180 S",pairAllowed:true,note:"Inside the wall; horizontal or vertical blade axis."},
      WK45_RIGID_WET:{label:"Rigid wall 100 mm — mortar/plaster — EI 120 S",type:"lindab-rect-range",reference:"EI 120 S • 500 Pa • page 22",minW:80,maxW:580,minH:80,maxH:580,recommendedW:80,recommendedH:80,wall:"Rigid wall, minimum 100 mm, minimum density 550 kg/m³",seal:"Mortar or plaster putty",spacing:0,edge:75,classification:"EI 120 S",pairAllowed:true,note:"Inside the wall; installation without duct connection permitted."},
      WK45_RIGID_DRY:{label:"Rigid wall 100 mm — rock wool/plasterboard — EI 120 S",type:"lindab-rect-range",reference:"EI 120 S • 500 Pa • page 22",minW:80,maxW:110,minH:80,maxH:110,recommendedW:80,recommendedH:80,wall:"Rigid wall, minimum 100 mm, minimum density 550 kg/m³",seal:"100 kg/m³ rock wool with plasterboard",spacing:0,edge:75,classification:"EI 120 S",pairAllowed:true,note:"Dry-seal arrangement."},
      WK45_RIGID_FIREBATT:{label:"Rigid wall — Fire Batt / Weichschott — EI 90 S",type:"lindab-rect-range",reference:"EI 90 S • 300 Pa • page 23",minW:100,maxW:800,minH:100,maxH:800,recommendedW:100,recommendedH:100,wall:"Rigid wall, minimum 100 mm, minimum density 550 kg/m³",seal:"140 kg/m³ coated rock-wool panel / Weichschott",spacing:0,edge:50,classification:"EI 90 S",pairAllowed:true,note:"Use the tested coated-panel sealing arrangement."},
      WK45_LIGHT_WET:{label:"Type F light wall — mortar/plaster — EI 120 S",type:"lindab-rect-range",reference:"EI 120 S • 500 Pa • page 24",minW:100,maxW:580,minH:100,maxH:580,recommendedW:100,recommendedH:100,wall:"Type F plasterboard wall, minimum 100 mm",seal:"Mortar or plaster putty",spacing:0,edge:75,classification:"EI 120 S",pairAllowed:true,note:"Inside the wall; metal studs; optional rock-wool insulation."},
      WK45_LIGHT_DRY:{label:"Type F light wall — rock wool/plasterboard — EI 90 S",type:"lindab-rect-range",reference:"EI 90 S • 500 Pa • page 24",minW:75,maxW:95,minH:75,maxH:95,recommendedW:75,recommendedH:75,wall:"Type F plasterboard wall, minimum 100 mm",seal:"100 kg/m³ rock wool with plasterboard on both sides",spacing:0,edge:75,classification:"EI 90 S",pairAllowed:true,note:"Dry-seal arrangement."},
      WK45_LIGHT_FIREBATT:{label:"Type F light wall — Fire Batt / Weichschott — EI 90 S",type:"lindab-rect-range",reference:"EI 90 S • 300 Pa • page 25",minW:100,maxW:800,minH:100,maxH:800,recommendedW:100,recommendedH:100,wall:"Type F plasterboard wall, minimum 100 mm",seal:"140 kg/m³ coated rock-wool panel / Weichschott",spacing:0,edge:50,classification:"EI 90 S",pairAllowed:true,note:"Use the tested coated-panel arrangement."},
      WK45_SAFETY_WALL:{label:"Safety light wall — EI 120 S",type:"lindab-rect-range",reference:"EI 120 S • 500 Pa • page 26",minW:100,maxW:580,minH:100,maxH:580,recommendedW:100,recommendedH:100,wall:"Safety light wall, minimum 100 mm",seal:"Mortar/plaster or 100 kg/m³ rock wool with plasterboard",spacing:0,edge:75,classification:"EI 120 S",pairAllowed:true,note:"Use the sealing option that matches the certified drawing."},
      WK45_GYPSUM_120:{label:"Solid gypsum blocks 100 mm — EI 120 S",type:"lindab-rect-range",reference:"EI 120 S • 500 Pa • page 26",minW:80,maxW:110,minH:80,maxH:110,recommendedW:80,recommendedH:80,wall:"Solid gypsum blocks, minimum 100 mm, minimum density 995 kg/m³",seal:"Plaster putty",spacing:0,edge:75,classification:"EI 120 S",pairAllowed:true,note:"Inside the wall."},
      WK45_GYPSUM_90:{label:"Solid gypsum blocks 70 mm — EI 90 S",type:"lindab-rect-range",reference:"EI 90 S • 500 Pa • page 26",minW:80,maxW:110,minH:80,maxH:110,recommendedW:80,recommendedH:80,wall:"Solid gypsum blocks, minimum 70 mm, minimum density 995 kg/m³",seal:"Plaster putty",spacing:200,edge:75,classification:"EI 90 S",pairAllowed:false,note:"Maintain the manufacturer-stated separation for independent dampers."},
      WK45_SANDWICH:{label:"Sandwich wall — Fire Batt / Weichschott — EI 90 S",type:"lindab-rect-range",reference:"EI 90 S • 300 Pa • page 28",minW:100,maxW:800,minH:100,maxH:800,recommendedW:100,recommendedH:100,wall:"Sandwich wall, minimum 100 mm",seal:"140 kg/m³ pre-coated rock-wool panel",spacing:0,edge:50,classification:"EI 90 S",pairAllowed:true,note:"Use the tested sandwich-wall detail."},
      WK45_FLOOR_180:{label:"Floor 140 mm / 2200 kg/m³ — mortar — EI 180 S",type:"lindab-rect-range",reference:"EI 180 S • 500 Pa • page 29",minW:130,maxW:170,minH:130,maxH:170,recommendedW:130,recommendedH:130,wall:"Floor, minimum 140 mm, minimum density 2200 kg/m³",seal:"Mortar",spacing:0,edge:75,classification:"EI 180 S",pairAllowed:true,note:"Inside the floor; axis irrelevant."},
      WK45_FLOOR_120:{label:"Floor 150 mm / 650 kg/m³ — mortar — EI 120 S",type:"lindab-rect-range",reference:"EI 120 S • 500 Pa • page 29",minW:130,maxW:170,minH:130,maxH:170,recommendedW:130,recommendedH:130,wall:"Floor, minimum 150 mm, minimum density 650 kg/m³",seal:"Mortar",spacing:0,edge:75,classification:"EI 120 S",pairAllowed:true,note:"Inside the floor."},
      WK45_FLOOR_90:{label:"Floor 100 mm / 650 kg/m³ — mortar — EI 90 S",type:"lindab-rect-range",reference:"EI 90 S • 500 Pa • page 29",minW:130,maxW:170,minH:130,maxH:170,recommendedW:130,recommendedH:130,wall:"Floor, minimum 100 mm, minimum density 650 kg/m³",seal:"Mortar",spacing:0,edge:75,classification:"EI 90 S",pairAllowed:true,note:"Inside the floor."},
      WK45_FLOOR_FIREBATT:{label:"Floor 150 mm — Fire Batt / Weichschott — EI 120 S",type:"lindab-rect-range",reference:"EI 120 S • 300 Pa • page 30",minW:100,maxW:800,minH:100,maxH:800,recommendedW:100,recommendedH:100,wall:"Floor, minimum 150 mm, minimum density 650 kg/m³",seal:"140 kg/m³ coated rock-wool panel / Weichschott",spacing:0,edge:75,classification:"EI 120 S",pairAllowed:true,note:"Use the tested floor Fire Batt detail."}
    }},
    "WKS25":{label:"WKS25 — Slim rectangular 500 Pa",shape:"rect",manual:"https://www.lindab.com/globalassets/commerce/lindabwebproductsdoc/assets/production/mgqwzwe0zdmtm2vmni00nzfklwiwmgitn2zhywi0ntfhnmiy/5250833079139246718/wks25_booklet_document_en_l.pdf?v=1783821283",guide:"Lindab WKS25 Installation Booklet",revision:"1MUBWKS25EN-LIND rev 25-03",methods:{
      WKS25_RIGID:{label:"Vertical rigid wall",type:"lindab-rect-fixed",reference:"EI 120 S",w:50,h:50,note:"Wall minimum thickness 100 mm; density 550 kg/m³."},
      WKS25_LIGHT:{label:"Vertical light wall — plasterboard",type:"lindab-rect-fixed",reference:"EI 60/120 S",w:75,h:75,note:"Wall minimum thickness 100 mm."},
      WKS25_GYPSUM:{label:"Solid gypsum block wall",type:"lindab-rect-fixed",reference:"EI 90/120 S",w:50,h:50,note:"Wall minimum thickness 70 or 100 mm; density 995 kg/m³."},
      WKS25_SHAFT:{label:"Shaft wall",type:"lindab-rect-fixed",reference:"EI 120 S",w:90,h:90,note:"Do not exceed the stated opening by more than 10 mm."}
    }}
  }}
};
function fdMsg(t,s){const e=$("fdMessage");e.className="msg "+t;e.textContent=s}


// RC10 Lindab engineering enrichment.
// Builder setting-out is enabled only where the selected Lindab installation
// drawing defines a nominal-size opening allowance that is centred on the damper.
(function applyLindabEngineeringMapping(){
  const lindab=FD_MANUFACTURERS.LINDAB;
  if(!lindab)return;
  const centred=(method,source)=>{
    method.settingOut={basis:"table-centred",source};
    method.packReady=true;
    method.verificationStatus="manufacturer-mapped";
  };
  const addCommon=(method,extra=[])=>{
    method.engineeringNotes=[
      "Position the damper centrally within the tested opening shown by the selected Lindab installation detail.",
      "Connected ductwork must be independently supported so its weight is not carried by the damper or penetration seal.",
      "Keep access available for inspection, actuator operation and removal of connected ductwork.",
      ...extra
    ];
  };

  const fnc=lindab.products.FNC1;
  if(fnc){
    centred(fnc.methods.FNC1_WET30,"FNC1 installation booklet rev 20-12, wall installation diagrams: nominal Ø +30 mm");
    centred(fnc.methods.FNC1_DRY10,"FNC1 installation booklet rev 20-12, acrylic-seal wall diagrams: nominal Ø +10 mm");
    centred(fnc.methods.FNC1_FLOOR,"FNC1 installation booklet rev 20-12, floor installation diagram");
    Object.values(fnc.methods).forEach(m=>addCommon(m,["Allow approximately 200 mm clear working space at the control mechanism where practicable.","Inspection hatches are recommended on both sides of connected ductwork."]));
  }

  ["WH25","WH45"].forEach(productKey=>{
    const product=lindab.products[productKey]; if(!product)return;
    Object.values(product.methods).forEach(m=>{
      centred(m,`${productKey} Lindab installation booklet, selected tested installation drawing`);
      addCommon(m,["Observe the method-specific minimum distance to adjacent construction and other dampers shown in the booklet.","Allow approximately 200 mm clear working space at the control mechanism where practicable."]);
    });
  });

  ["WK25","WK45"].forEach(productKey=>{
    const product=lindab.products[productKey]; if(!product)return;
    Object.values(product.methods).forEach(m=>{
      if(m.type==="wk25-range"){
        m.settingOut={basis:"table-centred",source:`${productKey} installation booklet, selected opening range; VentTools uses the documented recommended minimum allowance`};
        m.packReady=true;
      }else if(m.type==="wk25-fixed" || m.type==="lindab-rect-fixed"){
        m.settingOut={basis:"table-centred",source:`${productKey} installation booklet, selected fixed opening detail`};
        m.packReady=true;
      }
      addCommon(m,[m.spacingA!=null?`Recorded minimum separation field A: ${m.spacingA} mm for this method.`:"",m.spacingB!=null?`Recorded minimum edge-distance field B: ${m.spacingB} mm for this method.`:""] .filter(Boolean));
    });
  });

  const wks=lindab.products.WKS25;
  if(wks){
    const map={
      WKS25_RIGID:{source:"WKS25 booklet rev 25-03 pp.2,18: square hole b+50 / h+50",wall:"Vertical rigid wall, minimum 100 mm, 550 kg/m³",seal:"Plasterboard sheet on motor side / dry sealing with binders",spacing:0,edge:0},
      WKS25_LIGHT:{source:"WKS25 booklet rev 25-03 pp.2,20: square hole b+75 / h+75",wall:"Vertical light wall Type A or F, minimum 100 mm",seal:"Plasterboard strip/sheet on motor side / dry sealing with binders",spacing:0,edge:0},
      WKS25_GYPSUM:{source:"WKS25 booklet rev 25-03 pp.3,27-28: square hole b+50 / h+50",wall:"Solid gypsum-block wall, 70 or 100 mm, 995 kg/m³",seal:"Plasterboard sheet on motor side / dry sealing with binders",spacing:200,edge:75},
      WKS25_SHAFT:{source:"WKS25 booklet rev 25-03 pp.4,30: square hole b+90 / h+90",wall:"Vertical shaft wall, minimum 90 mm",seal:"Plasterboard sheet on motor side / dry sealing with binders",spacing:200,edge:75}
    };
    Object.entries(wks.methods).forEach(([key,m])=>{
      const d=map[key]; if(!d)return;
      m.wall=d.wall;m.seal=d.seal;m.spacing=d.spacing;m.edge=d.edge;
      centred(m,d.source);
      addCommon(m,["Raise and use the factory fixing flaps as shown in the WKS25 booklet.","No more than two dampers may be paired; three or more are prohibited.","Two vertically paired dampers must not both have vertical blade axes.",`Minimum independent-damper separation recorded for this method: ${d.spacing} mm.`,`Minimum distance to adjacent wall/floor/ceiling recorded for this method: ${d.edge} mm.`]);
    });
  }
})();

applyFDVerificationTeaching();

function clearFDSelectionDependentUI(message="Selection changed — recalculating…"){
  // Selection changes are handled synchronously: clear once, then calculate once.
  // No manufacturer-specific token or Android lifecycle guard is used here.
  window.__lastFDResult=null;
  const rangePanel=$("fdOpeningRange"); if(rangePanel)rangePanel.hidden=true;
  const verification=document.getElementById("fdVerificationPanel"); if(verification)verification.remove();
  const status=$("fdResultStatus"); if(status){status.textContent=message;status.className="fd-result-status warning";}
  ["fdReqConstruction","fdReqDuct","fdReqSupports","fdReqAccess","fdReqPosition","fdReqCritical"].forEach(id=>{
    const el=$(id); if(!el)return; el.hidden=true;
    const content=el.querySelector(".fd-requirement-content"); if(content)content.innerHTML="";
  });
  ["fdSetOpeningBottom","fdSetOpeningTop","fdSetDuctTop","fdSetBottomOffset"].forEach(id=>{if($(id))$(id).textContent="—"});
  const diagram=$("fdDiagramLayer"); if(diagram)diagram.innerHTML="";
  if($("fdSettingAnswer"))$("fdSettingAnswer").textContent=message;
  if($("fdSettingStatus")){ $("fdSettingStatus").textContent="Recalculating"; $("fdSettingStatus").className="fd-setting-badge warning"; }
}
function fdSelectionToken(selection=currentFD()){
  return `${selection.manKey||""}::${selection.productKey||""}::${selection.methodKey||""}`;
}
function currentFD(){
  const manKey=String($("fdManufacturer")?.value||"").trim();
  const man=FD_MANUFACTURERS[manKey];
  const rawProductKey=String($("fdSeries")?.value||"").trim();
  // The select value is the authoritative engineering key. Numeric-looking
  // Advanced Air codes (0160 / 2530) must never be re-derived from display text.
  const productKey=man?.products?.[rawProductKey] ? rawProductKey : canonicalFDProductKey(manKey,$("fdSeries"));
  const p=man?.products?.[productKey];
  const methodKey=String($("fdMethod")?.value||"").trim();
  const m=p?.methods?.[methodKey];
  return{man,p,m,manKey,productKey,methodKey};
}
function fillFDProducts(){
  const manKey=String($("fdManufacturer")?.value||"").trim();
  const man=FD_MANUFACTURERS[manKey],s=$("fdSeries");
  if(!man||!s)return;
  const previous=canonicalFDProductKey(manKey,s);
  s.innerHTML="";
  Object.entries(man.products||{}).forEach(([k,v])=>{
    const o=document.createElement("option");o.value=String(k);o.textContent=v.label;
    o.dataset.manual=v.manual||"";o.dataset.manualTitle=v.manualTitle||v.guide||"";
    o.dataset.revision=v.revision||"";o.dataset.productLabel=(v.label||String(k)).split(" — ")[0];s.appendChild(o)
  });
  if(previous&&man.products[previous])s.value=previous;
  if(!s.value&&s.options.length)s.selectedIndex=0;
  fillFDMethods();
}
function fillFDMethods(){
  const manKey=String($("fdManufacturer")?.value||"").trim();
  const man=FD_MANUFACTURERS[manKey];
  const rawProductKey=String($("fdSeries")?.value||"").trim();
  const productKey=man?.products?.[rawProductKey] ? rawProductKey : canonicalFDProductKey(manKey,$("fdSeries"));
  const p=man?.products?.[productKey],sel=$("fdMethod");
  if(!sel)return;
  const previous=String(sel.value||"").trim();sel.innerHTML="";
  Object.entries(p?.methods||{}).forEach(([k,v])=>{const o=document.createElement("option");o.value=String(k);o.textContent=v.label;sel.appendChild(o)});
  if(previous&&p?.methods?.[previous])sel.value=previous;
  if(!sel.value&&sel.options.length)sel.selectedIndex=0;
  if(!p||!sel.options.length){
    window.__lastFDResult=null;updateFDManualButtonLabel();
    const answer=$("fdSettingAnswer"),status=$("fdSettingStatus");
    if(answer)answer.innerHTML="<strong>Installation methods did not initialise.</strong> Reload this release once; VentTools will not reuse a previous product calculation.";
    if(status){status.textContent="Data reload required";status.className="fd-setting-badge warning";}
    return;
  }
  updateFDInputs();refreshFDManualResource();
}
function setAllowanceOptions(min,max,step,def){const sel=$("fdAllowance");sel.innerHTML="";for(let n=min;n<=max;n+=step){const o=document.createElement("option");o.value=n;o.textContent=`${n} mm total (${n/2} mm nominal each side)`;if(n===def)o.selected=true;sel.appendChild(o)}}

function setNumericOptions(id,min,max,def){const s=$(id);s.innerHTML="";for(let n=min;n<=max;n++){const o=document.createElement("option");o.value=n;o.textContent=n+" mm";if(n===def)o.selected=true;s.appendChild(o)}}
function configureDwfx(m){const variant=$("fdDwfxVariant").value;const isSmoke=variant==="SMOKE";if(m.smokeOnly&&!isSmoke){$("fdDwfxVariant").value="SMOKE"}
 const v=$("fdDwfxVariant").value;let wr=null,hr=null;
 if(m.type==="dwfx-dry-fixed"||m.type==="dwfx-fixed"){wr=[m.w,m.w];hr=[m.h,m.h]}
 else if(m.type.startsWith("dwfx-")&&m.type!=="dwfx-link"){wr=v==="SMOKE"?m.smokeW:m.fireW;hr=v==="SMOKE"?m.smokeH:m.fireH}
 if(wr&&hr){setNumericOptions("fdDwfxWAllowance",wr[0],wr[1],Math.round((wr[0]+wr[1])/2));setNumericOptions("fdDwfxHAllowance",hr[0],hr[1],Math.round((hr[0]+hr[1])/2))}
 $("fdDwfxAllowanceWrap").style.display=m.type==="dwfx-link"?"none":"grid";
 $("fdDwfxBoard").closest("div").style.display=(m.boardsW||m.boardsH)?"block":"none";
 const basis=$("fdDwfxInputBasis")?.value||"NOMINAL";
 const isAuto=isSmoke&&basis==="NOMINAL";
 $("fdDwfxInputBasis").querySelector('option[value="NOMINAL"]').disabled=!isSmoke;
 if(!isSmoke&&basis==="NOMINAL")$("fdDwfxInputBasis").value="MEASURED";
 $("fdDwfxDimensionKey").style.display=isAuto?"flex":"none";
 $("fdDwfxHint").textContent=m.type==="dwfx-link"
   ?'This method is listed for reference only because the current guide does not provide one safe universal opening formula. Use the official Actionair hole-sizing tool or installation drawing.'
   :isAuto
     ?'Enter the ordered nominal duct width and height. VentTools calculates the rectangular SmokeShield casing, adds the separate 28 mm PTC interface shroud on the actuator side, then applies the selected certified opening allowance.'
     :'Enter the measured overall casing width and height. For SmokeShield, the measured width must include the 28 mm PTC shroud. Do not include the peripheral flange.';
}
function updateFDInputs(){const {p,m,productKey}=currentFD(),circle=p.shape==="circle",dwfx=productKey==="DWFX-F",hevac=productKey==="HEVAC-IF",span=productKey==="SPAN",wk25=productKey==="WK25";
  $("fdRectInputs").style.display=p.shape==="rect"?"block":"none";
  $("fdCircularInputs").style.display=circle?"block":"none";
  $("fdDwfxWrap").style.display=dwfx?"block":"none";
  $("fdHevacWrap").style.display=hevac?"block":"none";
  $("fdSpanWrap").style.display=span?"block":"none";
  $("fdWk25Wrap").style.display=wk25?"block":"none";
  const wkConfig=$("fdWk25Config")?.value||"single";
  const dwBasis=$("fdDwfxInputBasis")?.value||"NOMINAL",dwSmoke=$("fdDwfxVariant")?.value==="SMOKE",dwAuto=dwfx&&dwSmoke&&dwBasis==="NOMINAL";
  $("fdWidthLabel").textContent=dwfx?(dwAuto?"Nominal duct width (mm)":"Measured overall casing width (mm)"):hevac?"Nominal duct width (mm)":wk25&&wkConfig!=="single"?"Measured overall joined assembly width (mm)":"Nominal duct width (mm)";
  $("fdHeightLabel").textContent=dwfx?(dwAuto?"Nominal duct height (mm)":"Measured overall casing height (mm)"):hevac?"Nominal duct height (mm)":wk25&&wkConfig!=="single"?"Measured overall joined assembly height (mm)":"Nominal duct height (mm)";
  $("fdBoardWrap").style.display=["bsb-dry","bsb-rect-dry","bsb-fsd-td-c-dry","bsb-fd-c-af-dry","bsb-circle-dry-lined","bsb-at-dry","css-dry"].includes(m.type)?"block":"none";
  $("fdWallBuildWrap").style.display=m.type==="css-dry"?"block":"none";
  $("fdShapeWrap").style.display=["css-masonry"].includes(m.type)?"block":"none";
  $("fdAllowanceWrap").style.display=["css-dry","css-masonry","css-slab"].includes(m.type)?"block":"none";
  $("fdDiameterLabel").textContent=["FSD-TD-C","FD-C-AF"].includes(productKey)?"Nominal circular duct diameter (mm)":m.type&&m.type.startsWith("css-")?"Overall damper casing diameter (mm)":"Nominal damper diameter (mm)";
  const circularHint=$("fdCircularProductHint");if(circularHint){circularHint.hidden=!(["FSD-TD-C","FD-C-AF","FD-C","FSD-C"].includes(productKey));circularHint.textContent=productKey==="FSD-TD-C"?"FSD-TD-C is the motorised multiblade product and only its published diameter table is accepted. Its circular spigot and rectangular casing are different geometries.":productKey==="FD-C-AF"?"FD-C-AF is the FD Series mechanical curtain-blade damper with a Type C circular spigot and rectangular Angle Frame casing. BSB permits Ø100–1000 in millimetre increments, including Ø355 and Ø560.":productKey==="FD-C"?"FD-C is BSB's separate externally resettable circular single-blade product, limited to Ø100–315. Do not confuse it with the FD Series FD-C-AF curtain-blade product.":"FSD-C is the separate motorised circular single-blade product. Product ranges overlap, so select the model stated on the project specification or damper label.";}
  if(m.type==="css-dry")setAllowanceOptions(m.min,m.max,m.step,m.defaultAllowance);
  if(m.type==="css-masonry"){const shape=$("fdApertureShape").value;setAllowanceOptions(shape==="square"?m.squareMin:m.circleMin,shape==="square"?m.squareMax:m.circleMax,m.step,m.defaultAllowance)}
  if(m.type==="css-slab")setAllowanceOptions(m.squareMin,m.squareMax,m.step,m.defaultAllowance);
  if(dwfx)configureDwfx(m);
  if(hevac){
    const g=$("fdHevacGap");g.innerHTML="";
    for(let n=5;n<=75;n+=5){const o=document.createElement("option");o.value=n;o.textContent=`${n} mm each side`;if(n===25)o.selected=true;g.appendChild(o)}
    $("fdHevacVariant").querySelector('option[value="SMOKE"]').disabled=!!m.fireOnly;
    if(m.fireOnly)$("fdHevacVariant").value="FIRE";
  }
  if(span)updateSpanInputs();
  calcFD();
}
function updateSpanInputs(){
  const circular=$("fdSpanVariant").value==="601";
  $("fdSpanWidthWrap").style.display=circular?"none":"block";
  $("fdSpanHeightWrap").style.display=circular?"none":"block";
  $("fdSpanDiameterWrap").style.display=circular?"block":"none";
}
function drawFD(r){const g=$("fdDiagramLayer"),title=`${r.manufacturer} • ${r.product}`;
 if(r.shape==="rect"){const ow=420,oh=Math.max(100,Math.min(190,ow*r.openH/r.openW)),x=(760-ow)/2,y=75+(190-oh)/2,gx=28,gy=24;g.innerHTML=`<rect x="${x}" y="${y}" width="${ow}" height="${oh}" rx="6" fill="#eef2f6" stroke="#334155" stroke-width="3"/><rect x="${x+gx}" y="${y+gy}" width="${ow-2*gx}" height="${oh-2*gy}" rx="3" fill="#cbd5e1" stroke="#064b82" stroke-width="3"/><line x1="${x}" y1="${y+oh+28}" x2="${x+ow}" y2="${y+oh+28}" stroke="#064b82" stroke-width="2" marker-start="url(#fdArrow)" marker-end="url(#fdArrow)"/><text x="380" y="${y+oh+52}" text-anchor="middle" font-family="system-ui" font-size="16" font-weight="900" fill="#064b82">${r.opening}</text><text x="380" y="32" text-anchor="middle" font-family="system-ui" font-size="18" font-weight="950" fill="#142033">${title}</text><text x="380" y="300" text-anchor="middle" font-family="system-ui" font-size="14" font-weight="800" fill="#142033">Damper ${r.damper}</text>`}
 else{const cx=380,cy=150,ro=105,ratio=Math.min(.92,r.dia/(r.visualOpen||r.dia+20)),rd=Math.max(52,ro*ratio);if(r.apertureShape==="square"){g.innerHTML=`<rect x="${cx-ro}" y="${cy-ro}" width="${2*ro}" height="${2*ro}" rx="5" fill="#eef2f6" stroke="#334155" stroke-width="3"/><circle cx="${cx}" cy="${cy}" r="${rd}" fill="#cbd5e1" stroke="#064b82" stroke-width="3"/><line x1="${cx-ro}" y1="${cy+ro+30}" x2="${cx+ro}" y2="${cy+ro+30}" stroke="#064b82" stroke-width="2" marker-start="url(#fdArrow)" marker-end="url(#fdArrow)"/><text x="${cx}" y="${cy+ro+55}" text-anchor="middle" font-family="system-ui" font-size="16" font-weight="900" fill="#064b82">${r.opening}</text><text x="${cx}" y="32" text-anchor="middle" font-family="system-ui" font-size="18" font-weight="950" fill="#142033">${title}</text><text x="${cx}" y="${cy+7}" text-anchor="middle" font-family="system-ui" font-size="15" font-weight="900" fill="#142033">Ø ${fmt0(r.dia)} casing</text>`}else{g.innerHTML=`<circle cx="${cx}" cy="${cy}" r="${ro}" fill="#eef2f6" stroke="#334155" stroke-width="3"/><circle cx="${cx}" cy="${cy}" r="${rd}" fill="#cbd5e1" stroke="#064b82" stroke-width="3"/><line x1="${cx-ro}" y1="${cy+ro+30}" x2="${cx+ro}" y2="${cy+ro+30}" stroke="#064b82" stroke-width="2" marker-start="url(#fdArrow)" marker-end="url(#fdArrow)"/><text x="${cx}" y="${cy+ro+55}" text-anchor="middle" font-family="system-ui" font-size="16" font-weight="900" fill="#064b82">${r.opening}</text><text x="${cx}" y="32" text-anchor="middle" font-family="system-ui" font-size="18" font-weight="950" fill="#142033">${title}</text><text x="${cx}" y="${cy+7}" text-anchor="middle" font-family="system-ui" font-size="15" font-weight="900" fill="#142033">Ø ${fmt0(r.dia)} casing</text>`}}
}

function actionairSpanCase501(w,h){
  if(w<100||h<100||w>1000||h>1000)return null;
  const caseW=w<151?273:(w<200?323:w+73);
  const caseH=h<151?270:(h<200?320:h+70);
  return {caseW,caseH};
}
function actionairSpanCase601(d){
  if(d<100||d>1000)return null;
  const caseW=d<151?275:(d<200?325:(d<950?d+125:(d<970?1075:d+105)));
  const caseH=d<151?272:(d<200?322:(d<950?d+122:(d<970?1072:d+102)));
  return {caseW,caseH};
}
function actionairSmokeRectCasing(w,h){
  if(w<100||w>1000||h<100||h>1000)return null;
  const bodyW=w<151?200:(w<200?250:w+50);
  const bodyH=h<151?200:(h<200?250:h+50);
  const topProjection=(bodyH-h)/2;
  const bottomProjection=(bodyH-h)/2;
  return {bodyW,bodyH,casingW:bodyW+28,casingH:bodyH,topProjection,bottomProjection};
}
function actionairHevacSmokeFrame(w,h){
  if(w<100||w>1000||h<100||h>1000)return null;
  const frameW=w<151?314:(w<200?364:w+114);
  const frameH=h<151?340:(h<200?390:h+140);
  return {frameW,frameH};
}
function actionairHevacFireFrame(w,h){
  if(w<100||w>1250||h<100||h>1000)return null;
  const frameW=w+114;
  let frameH;
  if(h<=249)frameH=h+114;
  else if(h<=450)frameH=h+133;
  else if(h<=650)frameH=h+140;
  else frameH=h+170;
  return {frameW,frameH};
}
function calculateActionairSpan(){
  const variant=$("fdSpanVariant").value;
  let dims,damper;
  if(variant==="501"){
    const w=parseFloat($("fdSpanWidth").value)||0,h=parseFloat($("fdSpanHeight").value)||0;
    dims=actionairSpanCase501(w,h);
    damper=`SmokeShield 501 PTC • ${fmt0(w)} × ${fmt0(h)} mm duct`;
  }else{
    const d=parseFloat($("fdSpanDiameter").value)||0;
    dims=actionairSpanCase601(d);
    damper=`SmokeShield 601 PTC • Ø ${fmt0(d)} mm duct`;
  }
  if(!dims)return {error:"Supported SPAN sizes are 100–1000 mm."};
  const minW=dims.caseW+122,minH=dims.caseH+122;
  const recW=dims.caseW+172,recH=dims.caseH+172;
  const maxW=dims.caseW+572,maxH=dims.caseH+572;
  return {
    shape:"rect",
    manufacturer:"Swegon (Actionair products)",
    product:"SPAN",
    method:"SPAN_STANDARD",
    opening:`${fmt0(recW)} × ${fmt0(recH)} mm recommended`,
    damper,
    openW:recW,openH:recH,
    nomW:dims.caseW,nomH:dims.caseH,
    reference:"SmokeShield PTC SPAN",
    rule:`Recommended opening = overall case +172 mm in width and height`,
    range:`Permitted range: ${fmt0(minW)} × ${fmt0(minH)} mm minimum to ${fmt0(maxW)} × ${fmt0(maxH)} mm maximum. Recommended opening allows 100 mm infill on all four sides.`
  };
}
const ADVANCED_AIR_RECT_TABLES={
  AA0160_AFS:{
    source:"Advanced Air 0160 IOM Rev 1.1 opening tables",
    width:{mode:"add",min:194,max:350},
    heightBands:[
      {max:100,min:100,maxAdd:350},{max:300,min:125,maxAdd:375},
      {max:525,min:150,maxAdd:400},{max:700,min:175,maxAdd:425},
      {max:925,min:200,maxAdd:450},{max:1000,min:225,maxAdd:475}
    ]
  },
  AA2530_AFS:{
    source:"Advanced Air 2530 IOM Rev 1.1 AFS opening table",
    sizeBands:[
      {test:(w,h)=>w>=200&&h>=200,minW:(w)=>w+194,maxW:(w)=>w+310,minH:(h)=>h+100,maxH:(h)=>h+310},
      {test:(w,h)=>w>=175&&h>=175,minW:(w)=>w+219,maxW:(w)=>w+335,minH:(h)=>h+125,maxH:(h)=>h+335},
      {test:()=>true,minW:()=>394,maxW:()=>510,minH:()=>300,maxH:()=>510}
    ]
  },
  AA2530_HEVAC:{
    source:"Advanced Air 2530 IOM Rev 1.1 HEVAC opening table",
    sizeBands:[
      {test:(w,h)=>w>=200&&h>=200,minW:(w)=>w+170,maxW:(w)=>w+200,minH:(h)=>h+170,maxH:(h)=>h+200},
      {test:()=>true,minW:()=>370,maxW:()=>400,minH:()=>370,maxH:()=>400}
    ]
  }
};
function resolveAdvancedAirRectTable(ruleKey,w,h){
  const table=ADVANCED_AIR_RECT_TABLES[ruleKey];
  if(!table)return null;
  if(table.sizeBands){
    const band=table.sizeBands.find(b=>b.test(w,h));
    return {minW:band.minW(w),maxW:band.maxW(w),minH:band.minH(h),maxH:band.maxH(h),source:table.source};
  }
  const hb=table.heightBands.find(b=>h<=b.max)||table.heightBands[table.heightBands.length-1];
  return {minW:w+table.width.min,maxW:w+table.width.max,minH:h+hb.min,maxH:h+hb.maxAdd,source:table.source};
}

function advancedAirDirectProductKey(){
  const man=String($("fdManufacturer")?.value||"").trim();
  if(man!=="ADVANCED_AIR")return "";
  const sel=$("fdSeries");
  const raw=String(sel?.value||"").trim();
  const label=String(sel?.options?.[sel.selectedIndex]?.textContent||"").trim();
  if(raw==="0160"||/^0160\b/.test(label))return "0160";
  if(raw==="2530"||/^2530\b/.test(label))return "2530";
  return "";
}
function calculateAdvancedAirDirect(){
  const productKey=advancedAirDirectProductKey();
  if(!productKey)return null;
  const methodKey=String($("fdMethod")?.value||"").trim();
  const W=parseFloat($("fdWidth")?.value)||0,H=parseFloat($("fdHeight")?.value)||0;
  const product=FD_MANUFACTURERS.ADVANCED_AIR.products[productKey];
  const method=product?.methods?.[methodKey];
  if(!method||W<=0||H<=0)return null;
  let d=null;
  if(method.type==="advanced-rect-table")d=resolveAdvancedAirRectTable(method.tableRule,W,H);
  else if(method.type==="advanced-rect-fixed")d={minW:W+method.addW,maxW:W+method.addW,minH:H+method.addH,maxH:H+method.addH,source:method.reference};
  if(!d)return null;
  const opening=`${fmt0(d.minW)} × ${fmt0(d.minH)} mm minimum opening to form`;
  const range=`Published range: ${fmt0(d.minW)}–${fmt0(d.maxW)} mm wide × ${fmt0(d.minH)}–${fmt0(d.maxH)} mm high.`;
  const r={
    shape:"rect",manufacturer:"Advanced Air",manufacturerKey:"ADVANCED_AIR",product:productKey,productKey,method:methodKey,methodKey,
    nomW:W,nomH:H,openW:d.minW,openH:d.minH,opening,damper:`${fmt0(W)} × ${fmt0(H)} mm nominal duct`,
    rule:method.type==="advanced-rect-fixed"?`Nominal width +${method.addW} mm; nominal height +${method.addH} mm`:`Published ${method.tableRule==="AA2530_HEVAC"?"HEVAC":"AFS"} opening table selected from the nominal-size band`,
    reference:method.reference,range,nominalStage:`${fmt0(W)} × ${fmt0(H)} mm`,
    casingStage:method.tableRule==="AA2530_HEVAC"?"HEVAC frame allowance included in the manufacturer table":"AFS frame, rails/brackets and fire-batt zone included in the manufacturer table",
    finishedStage:`${fmt0(d.minW)} × ${fmt0(d.minH)} mm minimum formed opening`,cutStage:`${fmt0(d.minW)} × ${fmt0(d.minH)} mm minimum structural opening`,
    sourceStatus:"Verified from manufacturer opening table",statusType:"verified",includesLining:false,
    settingOut:{basis:"table-centred",source:`${d.source}: minimum opening shown with the nominal damper centred for builder setting-out.`},
    minOpenW:d.minW,minOpenH:d.minH,maxOpenW:d.maxW,maxOpenH:d.maxH,
    rangeNote:"The minimum published opening is shown as the main result.",methodSnapshot:method,
    criticalRules:[`Supporting construction: ${method.wall}.`,`Certified penetration seal: ${method.seal}.`,`Leave the manufacturer-required 10 mm duct expansion clearance and independently support connected ductwork within one metre.`,method.note].filter(Boolean)
  };
  r.selectionToken=`ADVANCED_AIR::${productKey}::${methodKey}`;
  window.__lastFDResult=r;
  const set=(id,value)=>{const el=$(id);if(el)el.textContent=value};
  set("fdOpeningLabel","Opening Required by Selected Method");set("fdOpeningBig",opening);set("fdMethodBig",`${productKey} • ${method.reference}`);
  set("fdDamperSummary",r.damper);set("fdRuleSummary",r.rule);set("fdReferenceSummary",r.reference);set("fdGuideSummary",`${product.manualTitle||product.guide} — ${product.revision}`);
  set("fdNominalStage",r.nominalStage);set("fdCasingStage",r.casingStage);set("fdFinishedStage",r.finishedStage);set("fdCutStage",r.cutStage);
  const st=$("fdResultStatus");if(st){st.textContent=r.sourceStatus;st.className="fd-result-status verified"}
  const rp=$("fdOpeningRange");if(rp){rp.hidden=false;set("fdRangeMinW",`${fmt0(d.minW)} mm`);set("fdRangeMinH",`${fmt0(d.minH)} mm`);set("fdRangeSelectedW",`${fmt0(d.minW)} mm`);set("fdRangeSelectedH",`${fmt0(d.minH)} mm`);set("fdRangeMaxW",`${fmt0(d.maxW)} mm`);set("fdRangeMaxH",`${fmt0(d.maxH)} mm`);set("fdRangeNote",r.rangeNote)}
  try{updateFDSettingOut(r)}catch(e){console.error("Advanced Air direct setting-out",e);set("fdSettingAnswer",opening)}
  try{drawFD(r)}catch(e){console.error("Advanced Air direct diagram",e)}
  try{renderFDInstallationRequirements(r.criticalRules,r.selectionToken)}catch(e){console.error(e)}
  try{renderFDVerification(r)}catch(e){console.error(e)}
  try{refreshFDManualResource()}catch(e){console.error(e)}
  fdMsg("ok",`✅ Advanced Air ${productKey} calculation complete.`);
  return r;
}
function bsbFsdTdCircularGeometry(product,method,diameter,boardThickness=12.5){
  const dia=Number(diameter),dimensions=product?.dimensionTable?.[dia];
  if(!Number.isFinite(dia)||!dimensions)return {valid:false,diameter:dia};
  const lined=method.type==="bsb-fsd-td-c-dry";
  const board=lined?Number(boardThickness):0;
  const finishedW=dia+Number(method.finishedW),finishedH=dia+Number(method.finishedH);
  const casingW=dia+Number(method.casingAddW),casingH=dia+Number(method.casingAddH);
  return {valid:true,diameter:dia,dimensions,lined,board,spigotOutside:dia+Number(product.spigotOutsideAdd),casingW,casingH,finishedW,finishedH,cutW:finishedW+2*board,cutH:finishedH+2*board};
}

function bsbFdSeriesCircularAfGeometry(product,method,diameter,boardThickness=12.5){
  const dia=Number(diameter),min=Number(product?.minSize),max=Number(product?.maxSize);
  if(!Number.isInteger(dia)||dia<min||dia>max)return {valid:false,diameter:dia};
  const spigotOutside=dia+Number(product.spigotOutsideAdd);
  const topReturn=dia<=300?31:dia<=500?55:dia<=750?75:95;
  const casingSideReturn=31,casingBottomReturn=31;
  const nominalToSpigotEdge=(dia-spigotOutside)/2;
  const casingProjectionLeft=casingSideReturn-nominalToSpigotEdge;
  const casingProjectionRight=casingProjectionLeft;
  const casingProjectionBottom=casingBottomReturn-nominalToSpigotEdge;
  const casingProjectionTop=topReturn-nominalToSpigotEdge;
  const casingW=spigotOutside+casingSideReturn*2;
  const casingH=spigotOutside+casingBottomReturn+topReturn;
  const gap=Number(method.gapNominal),tolerance=Number(method.gapTolerance);
  const lined=method.type==="bsb-fd-c-af-dry",board=lined?Number(boardThickness):0;
  const finishedW=casingW+2*gap,finishedH=casingH+2*gap;
  const cutW=finishedW+2*board,cutH=finishedH+2*board;
  const frameHeightAdd=dia<=300?180:dia<=500?204:dia<=750?224:244;
  return {valid:true,diameter:dia,spigotOutside,topReturn,casingSideReturn,casingBottomReturn,casingProjectionLeft,casingProjectionRight,casingProjectionBottom,casingProjectionTop,casingW,casingH,gap,tolerance,lined,board,finishedW,finishedH,cutW,cutH,frameW:dia+180,frameH:dia+frameHeightAdd,finishedMinW:casingW+2*(gap-tolerance),finishedMinH:casingH+2*(gap-tolerance),finishedMaxW:casingW+2*(gap+tolerance),finishedMaxH:casingH+2*(gap+tolerance)};
}

function calcFD(){const aaDirect=calculateAdvancedAirDirect();if(aaDirect)return aaDirect;if(!$("fdSeries")?.value)return null;const startSelection=currentFD(),startToken=fdSelectionToken(startSelection);const {man,p,m,manKey,productKey,methodKey}=startSelection;if(!man||!p||!m){clearFDSelectionDependentUI("Installation method did not initialise.");refreshFDManualResource();return null;}let r;
 if(productKey==="SPAN"){
   r=calculateActionairSpan();
   if(r.error){
     $("fdOpeningBig").textContent="Check size";
     $("fdMethodBig").textContent="SPAN";
     $("fdDamperSummary").textContent="—";
     $("fdRuleSummary").textContent=r.error;
     $("fdReferenceSummary").textContent="SmokeShield PTC SPAN";
     $("fdGuideSummary").textContent=`${p.manualTitle||p.guide} — ${p.revision}`;
     $("fdManualLink").href=p.manual;
     fdMsg("bad","⚠ "+r.error);
     return r;
   }
 }
 else if(p.shape==="rect"){const W=parseFloat($("fdWidth").value)||0,H=parseFloat($("fdHeight").value)||0;
  if(m.type==="bsb-link"){
    r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW:W,openH:H,opening:"Official BSB drawing required",damper:`${fmt0(W)} × ${fmt0(H)} mm entered size`,rule:"No universal opening formula is enabled for this product.",reference:m.reference,isLinkOnly:true,range:m.note,sourceStatus:"Official drawing required",statusType:"manual",criticalRules:[m.note,"Confirm the ordered overall damper dimensions with BSB before forming the opening.","Install only to the tested supporting-construction detail."]};
  }else if(m.type==="bsb-rect-dry" || m.type==="bsb-rect-solid"){
    const b=parseFloat($("fdBoardThickness").value)||12.5;
    const finishedW=W+m.finishedW,finishedH=H+m.finishedH;
    const lined=m.type==="bsb-rect-dry";
    const cutW=finishedW+(lined?2*b:0),cutH=finishedH+(lined?2*b:0);
    const hasMappedCasing=Number.isFinite(m.casingAddW)&&Number.isFinite(m.casingAddH);
    const casingW=hasMappedCasing?W+m.casingAddW:null,casingH=hasMappedCasing?H+m.casingAddH:null;
    const casingText=hasMappedCasing
      ?`Overall damper casing: ${fmt0(W)} + ${fmt0(m.casingAddW)} = ${fmt0(casingW)} mm wide; ${fmt0(H)} + ${fmt0(m.casingAddH)} = ${fmt0(casingH)} mm high. No physical damper measurement is required for this recorded size method.`
      :`Published finished-aperture allowance: nominal +${fmt0(m.finishedW)} mm width and +${fmt0(m.finishedH)} mm height.`;
    const clearanceText=hasMappedCasing
      ?`Tested aperture clearance: ${fmt0(m.clearanceLeft)} mm left + ${fmt0(m.clearanceRight)} mm right, and ${fmt0(m.clearanceBottom)} mm below + ${fmt0(m.clearanceTop)} mm above the casing.`
      :"";
    r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW:cutW,openH:cutH,opening:`${fmt0(cutW)} × ${fmt0(cutH)} mm ${lined?"structural cut":"finished aperture"}`,damper:`${fmt0(W)} × ${fmt0(H)} mm nominal duct`,rule:`${casingText}${clearanceText?` ${clearanceText}`:""} Finished aperture: ${fmt0(finishedW)} × ${fmt0(finishedH)} mm${lined?`; structural cut adds one ${fmt(b)} mm lining board at each opposite edge (${fmt0(2*b)} mm overall per dimension)`:"; no aperture lining added by VentTools"}`,reference:m.reference,range:m.note,nominalStage:`${fmt0(W)} × ${fmt0(H)} mm ordered nominal size`,casingStage:hasMappedCasing?`${fmt0(casingW)} × ${fmt0(casingH)} mm overall casing — derived from manufacturer dimensions; no site measurement required`:`Published method allowance — see finished opening stage`,finishedStage:hasMappedCasing?`${fmt0(finishedW)} × ${fmt0(finishedH)} mm lined aperture, including tested casing clearances`:`${fmt0(finishedW)} × ${fmt0(finishedH)} mm${lined?" before aperture lining":""}`,cutStage:lined?`Width: ${fmt0(finishedW)} + 2 × ${fmt(b)} mm aperture lining = ${fmt0(cutW)} mm; height: ${fmt0(finishedH)} + 2 × ${fmt(b)} mm aperture lining = ${fmt0(cutH)} mm`:`${fmt0(cutW)} × ${fmt0(cutH)} mm`,sourceStatus:"Verified from manufacturer method",statusType:"verified",includesLining:lined,liningMapped:lined,structuralLiningBottom:lined?b:0,finishedW,finishedH,cutW,cutH,criticalRules:[`Supporting construction: ${m.wall}.`,`BSB case/frame build-up: nominal ${fmt0(W)} × ${fmt0(H)} mm plus ${fmt0(m.finishedW)} mm width and ${fmt0(m.finishedH)} mm height = ${fmt0(finishedW)} × ${fmt0(finishedH)} mm finished aperture.`,`Opening treatment: ${lined?`fit one ${fmt(b)} mm fire-rated lining board to each internal edge of the aperture. That adds ${fmt(b)} mm at the left and right (${fmt0(2*b)} mm overall width) and ${fmt(b)} mm at the top and bottom (${fmt0(2*b)} mm overall height). The two wall-face boards are not added again`:"do not add a board lining unless the selected BSB drawing requires it"}.`,`Certified sealing/fixing arrangement: ${m.seal}.`,`Minimum clear structural separation: 200 mm between separate damper casings.`,`Minimum distance from damper casing to adjacent wall, floor or ceiling: 75 mm.`,m.note,"Other services must not share the damper opening."]};
  }else if(m.type==="bsb-at-dry" || m.type==="bsb-at-solid"){
    const lined=m.type==="bsb-at-dry";
    const b=parseFloat($("fdBoardThickness").value)||12.5;
    const finishedW=W,finishedH=H;
    const cutW=finishedW+(lined?2*b:0),cutH=finishedH+(lined?2*b:0);
    r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW:cutW,openH:cutH,
      opening:`${fmt0(cutW)} × ${fmt0(cutH)} mm ${lined?"structural cut":"finished masonry aperture"}`,
      damper:`${fmt0(W)} × ${fmt0(H)} mm ordered nominal opening`,
      rule:lined?`Finished lined aperture = ordered nominal size. Structural cut adds 2 × ${fmt(b)} mm aperture lining in each dimension.`:`Finished masonry aperture = ordered nominal size (+5/-0 mm manufacturer tolerance).`,
      reference:m.reference,range:m.note,nominalStage:`${fmt0(W)} × ${fmt0(H)} mm ordered nominal aperture`,
      casingStage:`${fmt0(W-10)} × ${fmt0(H-10)} mm actual sleeve (nominal minus 10 mm)`,
      finishedStage:`${fmt0(finishedW)} × ${fmt0(finishedH)} mm finished aperture (+5/-0 mm tolerance)`,
      cutStage:lined?`${fmt0(finishedW)} + 2 × ${fmt(b)} = ${fmt0(cutW)} mm wide; ${fmt0(finishedH)} + 2 × ${fmt(b)} = ${fmt0(cutH)} mm high`:`${fmt0(finishedW)} × ${fmt0(finishedH)} mm`,
      sourceStatus:"Verified from manufacturer method",statusType:"verified",includesLining:lined,liningMapped:lined,structuralLiningBottom:lined?b:0,finishedW,finishedH,cutW,cutH,
      criticalRules:[`Supporting construction: ${m.wall}.`,lined?`Opening treatment: fully line all four internal sides with ${fmt(b)} mm fire-rated plasterboard and track.`:"Opening treatment: form the masonry aperture to the ordered nominal size.",`Damper fixing: ${lined?"3.5 mm × 38 mm drywall screws through the outer flange holes into the aperture track":"5 mm diameter × 40 mm minimum steel fixings through the outer flange holes"}.`,`Certified joint treatment: ${m.seal}.`,`Position the damper centrally in the prepared opening.`,`This is an unducted air-transfer damper; no duct connection is required.`,`Minimum separation: 200 mm between separate dampers and 75 mm to adjacent wall or floor.`,m.note]};
  }else if(productKey==="DWFX-F"){
    const variant=$("fdDwfxVariant").value,board=parseFloat($("fdDwfxBoard").value)||0;
    if(m.smokeOnly&&variant!=="SMOKE")$("fdDwfxVariant").value="SMOKE";
    const actualVariant=$("fdDwfxVariant").value;
    const ref=actualVariant==="SMOKE"?m.referenceSmoke:m.referenceFire;
    if(m.type==="dwfx-link"){
      r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW:W,openH:H,opening:"Official hole sizer / drawing required",damper:`${fmt0(W)} × ${fmt0(H)} mm casing`,rule:"No universal Vent Tools calculation enabled for this method",reference:ref||"See official guide",isLinkOnly:true};
    }else{
      const wa=parseFloat($("fdDwfxWAllowance").value)||0,ha=parseFloat($("fdDwfxHAllowance").value)||0;
      const basis=$("fdDwfxInputBasis")?.value||"NOMINAL";
      const automatic=actualVariant==="SMOKE"&&basis==="NOMINAL";
      const autoDims=automatic?actionairSmokeRectCasing(W,H):null;
      if(automatic&&!autoDims){
        r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW:W,openH:H,opening:"Size outside published SmokeShield range",damper:`${fmt0(W)} × ${fmt0(H)} mm nominal duct`,rule:"Published dimensional data covers nominal widths and heights from 100 mm to 1000 mm.",reference:ref,isLinkOnly:true,range:"Check the current Actionair DWFX-F dimensional table."};
      }else{
        let casingW=W,casingH=H,baseCasingW=null,baseCasingH=null,spigotW=null,spigotH=null,flangeW=null,flangeH=null;
        if(automatic){
          spigotW=W-5; spigotH=H-5;
          baseCasingW=autoDims.bodyW; baseCasingH=autoDims.bodyH;
          casingW=autoDims.casingW; casingH=autoDims.casingH;
          flangeW=W<151?398:(W<200?448:W+198);
          flangeH=H<151?395:(H<200?445:H+195);
        }
        const finishedW=casingW+wa,finishedH=casingH+ha;
        const cutW=finishedW+(m.boardsW||0)*board,cutH=finishedH+(m.boardsH||0)*board;
        const hasBoards=(m.boardsW||m.boardsH);
        const breakdown=automatic
          ?`Nominal duct ${fmt0(W)} × ${fmt0(H)} mm. Spigot ${fmt0(spigotW)} × ${fmt0(spigotH)} mm. Base casing ${fmt0(baseCasingW)} × ${fmt0(baseCasingH)} mm. PTC shroud adds 28 mm on the actuator side, giving the opening-measurement casing ${fmt0(casingW)} × ${fmt0(casingH)} mm. Overall peripheral flange ${fmt0(flangeW)} × ${fmt0(flangeH)} mm (not included in the opening calculation). Minimum actuator removal clearance: 120 mm.`
          :`Measured casing used directly: ${fmt0(casingW)} × ${fmt0(casingH)} mm${actualVariant==="SMOKE"?" including the PTC shroud":""}, excluding the peripheral flange.`;
        r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW:cutW,openH:cutH,opening:`${fmt0(cutW)} × ${fmt0(cutH)} mm${hasBoards?" cut size":""}`,damper:automatic?`${fmt0(W)} × ${fmt0(H)} mm nominal duct`:`${fmt0(W)} × ${fmt0(H)} mm measured casing`,rule:`Finished opening ${fmt0(finishedW)} × ${fmt0(finishedH)} mm: casing +${fmt0(wa)} mm width / +${fmt0(ha)} mm height${hasBoards?`; cut size adds ${m.boardsW||0} × ${fmt0(board)} mm board to width and ${m.boardsH||0} × ${fmt0(board)} mm board to height`:""}`,reference:ref,variant:actualVariant,range:`${breakdown} Minimum separation: 200 mm between dampers in separate ducts and 75 mm from a damper to an adjacent wall or floor.`,nominalStage:automatic?`${fmt0(W)} × ${fmt0(H)} mm`:"Measured casing input",casingStage:automatic?`${fmt0(casingW)} × ${fmt0(casingH)} mm incl. PTC shroud`:`${fmt0(casingW)} × ${fmt0(casingH)} mm measured`,finishedStage:`${fmt0(finishedW)} × ${fmt0(finishedH)} mm`,cutStage:`${fmt0(cutW)} × ${fmt0(cutH)} mm`,sourceStatus:automatic?"Verified from Actionair DWFX-F dimensional data pages 14–15":"Manual casing measurement required",statusType:automatic?"verified":"manual",settingOut:automatic?{basis:"casing-edge",casingProjectionBottom:autoDims.bottomProjection,casingProjectionTop:autoDims.topProjection,bottomClearance:ha/2,topClearance:ha/2,source:`Actionair DWFX-F LNNN00354 v6.0 pages 3–9 and 14–15: SmokeShield casing derived from nominal duct size; selected finished-opening allowance split equally above and below the casing.`}:null,structuralLiningBottom:hasBoards?board:0,criticalRules:[`Permitted finished-opening allowance selected: +${fmt0(wa)} mm width and +${fmt0(ha)} mm height.`,`Include the 28 mm PTC shroud in the casing width; exclude the peripheral flange.`,hasBoards?`Structural cut includes the certified board build-up (${m.boardsW||0} board thicknesses in width and ${m.boardsH||0} in height).`:"No additional board build-up is applied by this selected method.",`Minimum spacing: 200 mm between separate dampers and 75 mm from adjacent wall/floor for this Actionair method.`,`Allow at least 120 mm actuator removal clearance.`]};
      }
    }
  }else if(productKey==="HEVAC-IF"){
    const gap=parseFloat($("fdHevacGap").value)||25;
    let variant=$("fdHevacVariant").value;if(m.fireOnly)variant="FIRE";
    const ref=variant==="SMOKE"?m.referenceSmoke:m.referenceFire;
    const frame=variant==="SMOKE"?actionairHevacSmokeFrame(W,H):actionairHevacFireFrame(W,H);
    if(!frame){r={error:"Size outside the published Actionair I/F dimensional range."};}
    else{
      const openW=frame.frameW+2*gap,openH=frame.frameH+2*gap;
      r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW,openH,opening:`${fmt0(openW)} × ${fmt0(openH)} mm`,damper:`${variant==="SMOKE"?"SmokeShield PTC":"FireShield"} • ${fmt0(W)} × ${fmt0(H)} mm nominal duct`,rule:`Published I/F frame ${fmt0(frame.frameW)} × ${fmt0(frame.frameH)} mm + 2 × ${fmt0(gap)} mm clear mortar gap`,reference:ref,range:"Official drawing permits 5–75 mm from the installation-frame upstand to the aperture face all round.",nominalStage:`${fmt0(W)} × ${fmt0(H)} mm nominal duct`,casingStage:`${fmt0(frame.frameW)} × ${fmt0(frame.frameH)} mm installation frame`,finishedStage:`${fmt0(openW)} × ${fmt0(openH)} mm masonry opening`,cutStage:`${fmt0(openW)} × ${fmt0(openH)} mm`,sourceStatus:"Verified from Actionair I/F dimensional tables pages 9–11",statusType:"verified",settingOut:(()=>{const bottomProjection=variant==="SMOKE"?(((H<151?200:(H<200?250:H+50))-H)/2+57):57;const topProjection=frame.frameH-H-bottomProjection;return {basis:"casing-edge",casingProjectionBottom:bottomProjection,casingProjectionTop:topProjection,bottomClearance:gap,topClearance:gap,source:"Actionair I/F LNNN00352 v5.1 pages 9–11: nominal duct to installation-frame projections are derived from the published dimensional drawings; the selected mortar gap is then applied outside the frame."};})(),criticalRules:[`Installation frame: ${fmt0(frame.frameW)} × ${fmt0(frame.frameH)} mm.`,`Selected clear mortar gap: ${fmt0(gap)} mm all round (permitted 5–75 mm).`,`Ductwork must be independently supported with a break-away joint on both sides.`,`Minimum spacing: 200 mm between separate dampers and 75 mm to adjacent construction.`]};
    }
  }else if(m.type==="wk25-fixed" || m.type==="wk25-range"){
 const config=$("fdWk25Config")?.value||"single",axis=$("fdWk25Axis")?.value||"horizontal",paired=config!=="single";
 if(paired&&!m.pairAllowed)r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW:W,openH:H,opening:"Paired arrangement not certified",damper:`${fmt0(W)} × ${fmt0(H)} mm entered assembly`,rule:"Choose a method that permits paired dampers.",reference:m.reference,isLinkOnly:true,range:`Minimum separation to another damper: ${m.spacingA||m.spacingC} mm. Minimum distance to wall/floor: ${m.spacingB||m.spacingD} mm. ${m.note}`};
 else if(config==="pair-stack"&&axis==="vertical")r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW:W,openH:H,opening:"Orientation not permitted",damper:`${fmt0(W)} × ${fmt0(H)} mm entered assembly`,rule:"Two vertically stacked WK25 dampers must not both have vertical blade axes.",reference:"WK25 booklet page 2",isLinkOnly:true,range:"Select horizontal or mixed blade-axis arrangement."};
 else{const aw=m.type==="wk25-fixed"?m.w:m.recommendedW,ah=m.type==="wk25-fixed"?m.h:m.recommendedH,openW=W+aw,openH=H+ah,sd=m.spacingA||m.spacingC,se=m.spacingB||m.spacingD,rr=m.type==="wk25-range"?`Permitted structural D-hole allowance: width +${m.minW} to +${m.maxW} mm; height +${m.minH} to +${m.maxH} mm.`:`Fixed structural D-hole allowance: width +${m.w} mm; height +${m.h} mm.`;
 const dHole=`${fmt0(openW)} × ${fmt0(openH)} mm`;
 r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW,openH,opening:`${dHole}${m.type==="wk25-range"?" recommended structural D-hole":" structural D-hole"}`,damper:`${fmt0(W)} × ${fmt0(H)} mm ${paired?"measured joined assembly":"nominal damper"}`,rule:`${rr} The sealing material and any plasterboard/calcium-silicate infill are installed within this published D-hole; they are not a separate reveal lining to add outside it. ${paired?"Use the approved Lindab pairing kit and intumescent gasket.":""}`,reference:m.reference,range:`Construction: ${m.wall}. Seal: ${m.seal}. Minimum separation to another independent damper/assembly: ${sd} mm. Minimum distance to adjacent wall/floor: ${se} mm. ${m.note}`,nominalStage:`${fmt0(W)} × ${fmt0(H)} mm`,casingStage:`${fmt0(W)} × ${fmt0(H)} mm nominal damper`,finishedStage:"Not published separately — sealing/infill is formed inside the structural D-hole",cutStage:`${dHole} structural D-hole`,noSeparateFinishedOpening:true,sourceStatus:`Verified from Lindab WK25 installation booklet ${m.reference}`,statusType:"verified",settingOut:{basis:"table-centred",source:`Lindab WK25 ${m.reference}: structural D-hole is centred on the nominal damper/approved assembly using the selected documented allowance.`},criticalRules:[`Structural D-hole: ${dHole}.`,m.type==="wk25-range"?`Permitted D-hole range: width +${m.minW} to +${m.maxW} mm and height +${m.minH} to +${m.maxH} mm.`:`Use the fixed D-hole allowance shown by the selected detail.`,`Do not subtract plasterboard or calcium-silicate infill from the D-hole and do not add it again outside the D-hole.`,`Certified sealing arrangement: ${m.seal}.`,`Minimum separation to another independent damper/assembly: ${sd} mm.`,`Minimum distance to adjacent wall/floor: ${se} mm.`,m.note]};}
}else if(m.type==="lindab-rect-fixed"){
    const openW=W+m.w,openH=H+m.h;
    const critical=[`Supporting construction: ${m.wall||m.note||"See official Lindab method"}.`,`Certified sealing arrangement: ${m.seal||"See official Lindab method"}.`,`Opening allowance: +${m.w} mm width and +${m.h} mm height.`,m.spacing!==undefined?`Minimum separation between independent dampers: ${m.spacing} mm.`:"Check the official separation detail.",m.edge!==undefined?`Minimum distance to adjacent wall/floor/ceiling: ${m.edge} mm.`:"Check the official edge-distance detail.",m.note||"Install exactly to the selected certified detail."];
    r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW,openH,opening:`${fmt0(openW)} × ${fmt0(openH)} mm`,damper:`${fmt0(W)} × ${fmt0(H)} mm nominal`,rule:`Nominal width +${m.w} mm; nominal height +${m.h} mm`,reference:m.reference,range:m.note,nominalStage:`${fmt0(W)} × ${fmt0(H)} mm`,casingStage:`${fmt0(W)} × ${fmt0(H)} mm nominal damper`,finishedStage:`${fmt0(openW)} × ${fmt0(openH)} mm`,cutStage:`${fmt0(openW)} × ${fmt0(openH)} mm`,sourceStatus:"Verified from manufacturer method",statusType:"verified",criticalRules:critical};
  }else if(m.type==="lindab-rect-range"){
    const openW=W+m.recommendedW,openH=H+m.recommendedH;
    const critical=[`Supporting construction: ${m.wall||m.note||"See official Lindab method"}.`,`Certified sealing arrangement: ${m.seal||"See official Lindab method"}.`,`Permitted opening allowance: width +${m.minW} to +${m.maxW} mm; height +${m.minH} to +${m.maxH} mm.`,m.spacing!==undefined?`Minimum separation between independent dampers: ${m.spacing} mm.`:"Check the official separation detail.",m.edge!==undefined?`Minimum distance to adjacent wall/floor/ceiling: ${m.edge} mm.`:"Check the official edge-distance detail.",m.pairAllowed===false?"Paired installation is not enabled for this method.":m.pairAllowed===true?"A paired assembly is permitted only with the official Lindab kit and tested arrangement.":"Verify whether pairing is permitted.",m.note||"Install exactly to the selected certified detail."];
    r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW,openH,opening:`${fmt0(openW)} × ${fmt0(openH)} mm selected`,damper:`${fmt0(W)} × ${fmt0(H)} mm nominal`,rule:`Selected opening: width +${m.recommendedW} mm; height +${m.recommendedH} mm`,reference:m.reference,range:`Permitted range: width +${m.minW} to +${m.maxW} mm; height +${m.minH} to +${m.maxH} mm. ${m.note||""}`,nominalStage:`${fmt0(W)} × ${fmt0(H)} mm`,casingStage:`${fmt0(W)} × ${fmt0(H)} mm nominal damper`,finishedStage:`${fmt0(openW)} × ${fmt0(openH)} mm selected`,cutStage:`${fmt0(openW)} × ${fmt0(openH)} mm`,sourceStatus:"Verified from manufacturer method",statusType:"verified",criticalRules:critical};
  }else if(m.type==="advanced-rect-table"){
    const d=resolveAdvancedAirRectTable(m.tableRule,W,H);
    if(!d){
      r={error:"Advanced Air opening table did not initialise."};
    }else{
      const isHevac=m.tableRule==="AA2530_HEVAC";
      const frameText=isHevac?"HEVAC frame allowance included in the manufacturer table":"AFS frame, rails/brackets and fire-batt zone included in the manufacturer table";
      r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW:d.minW,openH:d.minH,
        opening:`${fmt0(d.minW)} × ${fmt0(d.minH)} mm minimum opening to form`,
        damper:`${fmt0(W)} × ${fmt0(H)} mm nominal duct`,
        rule:`Published ${isHevac?"HEVAC":"AFS"} opening table selected from the nominal-size band`,reference:m.reference,
        range:`Published range: width ${fmt0(d.minW)}–${fmt0(d.maxW)} mm; height ${fmt0(d.minH)}–${fmt0(d.maxH)} mm.`,
        nominalStage:`${fmt0(W)} × ${fmt0(H)} mm`,casingStage:frameText,
        finishedStage:`${fmt0(d.minW)} × ${fmt0(d.minH)} mm minimum formed opening`,cutStage:`${fmt0(d.minW)} × ${fmt0(d.minH)} mm minimum structural opening`,
        sourceStatus:"Verified from manufacturer opening table",statusType:"verified",includesLining:false,
        settingOut:{basis:"table-centred",source:`${d.source}: minimum opening shown with the nominal damper centred for builder setting-out.`},
        minOpenW:d.minW,minOpenH:d.minH,maxOpenW:d.maxW,maxOpenH:d.maxH,
        rangeNote:"The minimum published opening is shown as the main result. Any opening within the published range must follow the complete selected tested method.",
        criticalRules:[`Supporting construction: ${m.wall}.`,`Certified penetration seal: ${m.seal}.`,isHevac?"Centre the HEVAC frame evenly in the opening and keep mortar off the damper spigots.":"The wall-board/letterbox construction and AFS frame are already included in the published opening table; do not add board thickness again.","Leave the manufacturer-required 10 mm duct expansion clearance and independently support connected ductwork within one metre.",m.note]
      };
    }
  }else if(m.type==="advanced-rect-fixed"){
    const openW=W+m.addW,openH=H+m.addH;
    r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW,openH,opening:`${fmt0(openW)} × ${fmt0(openH)} mm`,damper:`${fmt0(W)} × ${fmt0(H)} mm nominal duct`,rule:`Nominal width +${m.addW} mm; nominal height +${m.addH} mm`,reference:m.reference,range:`Tolerance ±${m.tolerance} mm.`,nominalStage:`${fmt0(W)} × ${fmt0(H)} mm`,casingStage:"Manufacturer fixed opening allowance",finishedStage:`${fmt0(openW)} × ${fmt0(openH)} mm`,cutStage:`${fmt0(openW)} × ${fmt0(openH)} mm`,sourceStatus:"Verified from manufacturer method",statusType:"verified",includesLining:false,criticalRules:[`Supporting construction: ${m.wall}.`,`Certified sealing/fixing arrangement: ${m.seal}.`,`Opening tolerance: ±${m.tolerance} mm.`,`Use all specified retaining-flange fixings at the stated centres.`,m.note]};
  }else if(m.type==="advanced-26scd-afs"){
    const widthMin=W>=200?W+194:(W>=175?W+219:394);
    const widthMax=W>=200?W+310:(W>=175?W+335:510);
    const heightMin=H>=200?H+100:(H>=175?H+125:300);
    const heightMax=H>=200?H+310:(H>=175?H+335:510);
    r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW:widthMin,openH:heightMin,
      opening:`${fmt0(widthMin)} × ${fmt0(heightMin)} mm minimum opening to form`,damper:`${fmt0(W)} × ${fmt0(H)} mm nominal duct`,
      rule:"26SCD AFS published opening table, with width and height bands applied independently",reference:m.reference,
      range:`Published opening range: ${fmt0(widthMin)}–${fmt0(widthMax)} mm wide × ${fmt0(heightMin)}–${fmt0(heightMax)} mm high.`,
      nominalStage:`${fmt0(W)} × ${fmt0(H)} mm nominal duct`,casingStage:"26SCD casing, AFS rails/brackets and fire-batt zone included in the published method",
      finishedStage:`${fmt0(widthMin)} × ${fmt0(heightMin)} mm minimum opening to form`,cutStage:`${fmt0(widthMin)} × ${fmt0(heightMin)} mm minimum structural opening`,
      finishedW:widthMin,finishedH:heightMin,cutW:widthMin,cutH:heightMin,includesLining:false,
      sourceStatus:"Verified from Advanced Air 26SCD IOM opening table",statusType:"verified",
      settingOut:{basis:"table-centred",source:`${m.reference}: published opening table states the damper is centralised in the opening.`},
      criticalRules:[`Supporting construction: ${m.wall}.`,`Certified penetration seal: ${m.seal}.`,`Use the published minimum/maximum opening band for each nominal dimension.`,`The damper must be centralised unless the later AFS non-centralised guidance is followed in full.`,`Use M10 drop rods and the tested AFS rail/bracket/Z-piece support.`,`Leave at least 10 mm duct expansion clearance and independently support ductwork within one metre.`,`Provide access doors on both sides for DW145 compliance.`,m.note]};
  }else if(m.type==="advanced-26scd-remote"){
    r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW:W,openH:H,
      opening:"No separate damper opening — remote duct-mounted method",damper:`${fmt0(W)} × ${fmt0(H)} mm nominal duct`,
      rule:"The selected tested method mounts the damper in or beside fire-rated ductwork remote from the wall.",reference:m.reference,
      nominalStage:`${fmt0(W)} × ${fmt0(H)} mm nominal duct`,casingStage:"Damper supported from M10 drop rods / AFS support as shown in the selected remote method",
      finishedStage:"Not applicable — no separate wall opening for the damper body",cutStage:"Not applicable — coordinate the fire-rated duct penetration separately",
      sourceStatus:"Verified from Advanced Air 26SCD remote-from-wall method",statusType:"verified",includesLining:false,noBuilderOpening:true,settingOut:m.settingOut,
      criticalRules:[`Tested construction: ${m.wall}.`,`Certified sealing arrangement: ${m.seal}.`,`Use self-tapping steel fixings at 150 mm centres where stated.`,`Maintain the permitted overlap and 10 mm duct expansion allowance.`,`Support the damper and ductwork exactly as shown in the selected remote method.`,`Leave the actuator uncovered and provide access for maintenance.`,m.note]};
  }else if(m.type==="advanced-link"){
    r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW:W,openH:H,opening:"Official product opening table required",damper:`${fmt0(W)} × ${fmt0(H)} mm entered size`,rule:"No 0160/2530 opening rule has been reused for this product.",reference:m.reference,isLinkOnly:true,range:m.note,sourceStatus:"Official drawing required",statusType:"manual",criticalRules:[m.note,"Select the exact wall or remote installation from the current Advanced Air IOM.","Do not form an opening from another Advanced Air product table."]};
  }else if(m.type==="lindab-link"){
    r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW:W,openH:H,opening:"Select official installation method",damper:`${fmt0(W)} × ${fmt0(H)} mm nominal`,rule:"No single universal builder's opening applies to every WK25 installation.",reference:m.reference,isLinkOnly:true,range:m.note};
  }else r={shape:"rect",manufacturer:man.label,product:productKey,method:methodKey,nomW:W,nomH:H,openW:W+m.w,openH:H+m.h,opening:`${fmt0(W+m.w)} × ${fmt0(H+m.h)} mm`,damper:`${fmt0(W)} × ${fmt0(H)} mm`,rule:`Width +${m.w} mm; height +${m.h} mm`,reference:m.reference}
 }
 else if(productKey!=="SPAN"){const dia=parseFloat($("fdDiameter").value)||0;r={shape:"circle",manufacturer:man.label,product:productKey,method:methodKey,dia,damper:`Ø ${fmt0(dia)} mm`,reference:m.reference};
  if(m.type==="bsb-fd-c-af-dry" || m.type==="bsb-fd-c-af-solid"){
    const b=parseFloat($("fdBoardThickness").value)||12.5;
    const g=bsbFdSeriesCircularAfGeometry(p,m,dia,b);
    if(!g.valid){
      r.opening="Size outside BSB FD Series Type C range";r.rule="Enter a whole-millimetre circular duct diameter from Ø100 to Ø1000.";r.range="BSB publishes the FD Series Type C circular connection from Ø100 to Ø1000 in millimetre increments.";r.invalidSize=true;r.sourceStatus="Manufacturer range check required";r.statusType="warning";
    }else{
      r.shape="rect";r.nomW=g.diameter;r.nomH=g.diameter;r.openW=g.cutW;r.openH=g.cutH;r.finishedW=g.finishedW;r.finishedH=g.finishedH;r.cutW=g.cutW;r.cutH=g.cutH;
      r.opening=`${fmt0(g.cutW)} × ${fmt0(g.cutH)} mm ${g.lined?"nominal structural cut":"nominal aperture"}`;
      r.damper=`Ø ${fmt0(g.diameter)} mm nominal FD Series Type C circular spigot with rectangular casing and Angle Frame`;
      r.rule=`Spigot O.D. Ø${fmt0(g.spigotOutside)} mm → rectangular casing ${fmt0(g.casingW)} × ${fmt0(g.casingH)} mm → ${fmt0(g.gap)} ±${fmt0(g.tolerance)} mm gap all around${g.lined?` → one ${fmt(g.board)} mm aperture-lining board at each internal edge`:""}.`;
      const structuralMinW=g.finishedMinW+(g.lined?2*g.board:0),structuralMinH=g.finishedMinH+(g.lined?2*g.board:0),structuralMaxW=g.finishedMaxW+(g.lined?2*g.board:0),structuralMaxH=g.finishedMaxH+(g.lined?2*g.board:0);
      r.range=`BSB FD Series Type C supports Ø${fmt0(g.diameter)} mm. The 10 ±5 mm casing-gap tolerance gives ${g.lined?"a structural-cut":"an aperture"} range of ${fmt0(structuralMinW)}–${fmt0(structuralMaxW)} mm wide × ${fmt0(structuralMinH)}–${fmt0(structuralMaxH)} mm high; VentTools shows the 10 mm nominal-gap result.`;
      r.nominalStage=`Ø ${fmt0(g.diameter)} mm nominal circular duct → Ø ${fmt0(g.spigotOutside)} mm circular spigot O.D.`;
      r.casingStage=`${fmt0(g.casingW)} × ${fmt0(g.casingH)} mm rectangular curtain-damper casing; bottom casing edge is ${fmt(g.casingProjectionBottom)} mm below the nominal duct edge`;
      r.finishedStage=`${fmt0(g.finishedW)} × ${fmt0(g.finishedH)} mm nominal finished aperture around the casing`;
      r.cutStage=g.lined?`Width: ${fmt0(g.finishedW)} + 2 × ${fmt(g.board)} mm lining = ${fmt0(g.cutW)} mm; height: ${fmt0(g.finishedH)} + 2 × ${fmt(g.board)} mm lining = ${fmt0(g.cutH)} mm`:`${fmt0(g.cutW)} × ${fmt0(g.cutH)} mm nominal structural aperture`;
      r.visualOpen=Math.max(g.cutW,g.cutH);r.openD=r.visualOpen;r.apertureShape="square";r.sourceStatus="Verified from BSB FD Series V12607 Type C dimensions and selected FD-AF method";r.statusType="verified";
      r.includesLining=g.lined;r.liningMapped=g.lined;r.structuralLiningBottom=g.lined?g.board:0;r.settingOut={...m.settingOut,casingProjectionBottom:g.casingProjectionBottom,casingProjectionTop:g.casingProjectionTop,bottomClearance:g.gap,topClearance:g.gap};
      r.criticalRules=[`Supporting construction: ${m.wall}.`,`The photographed/product-code geometry is FD-C-AF: FD Series curtain blades, Type C circular spigot and Angle Frame. It is not the FD-C Series single-blade product.`,`Nominal duct, actual Ø${fmt0(g.spigotOutside)} mm spigot and ${fmt0(g.casingW)} × ${fmt0(g.casingH)} mm rectangular casing are separate setting-out stages.`,`Manufacturer aperture clearance: ${fmt0(g.gap)} ±${fmt0(g.tolerance)} mm all around the rectangular casing; the result shown uses the nominal ${fmt0(g.gap)} mm gap.`,`Angle Frame overall size for this nominal diameter: ${fmt0(g.frameW)} × ${fmt0(g.frameH)} mm; the frame overlaps the supporting construction and is not used as the hole size.`,g.lined?`Opening treatment: line each internal edge with one ${fmt(g.board)} mm fire-rated board after forming the structural cut.`:"Opening treatment: no aperture lining is added for this selected masonry method.",`Certified fixing arrangement: ${m.seal}.`,`Use break-away joints with aluminium rivets on connecting ductwork.`,`Minimum clear structural separation: 200 mm between separate damper casings.`,`Minimum distance from casing to adjacent wall, floor or ceiling: 75 mm.`,m.note,"Other services must not share the damper opening."];
    }
  }
  else if(m.type==="bsb-fsd-td-c-dry" || m.type==="bsb-fsd-td-c-solid"){
    const b=parseFloat($("fdBoardThickness").value)||12.5;
    const g=bsbFsdTdCircularGeometry(p,m,dia,b);
    if(!g.valid){
      r.opening="Diameter not listed by BSB";r.rule="Select a diameter explicitly listed in the FSD-TD-C manufacturer table.";r.range="Verified listed diameters: Ø100 to Ø1000 mm in 50 mm steps. Values between the listed sizes are not extrapolated.";r.invalidSize=true;r.sourceStatus="Manufacturer size verification required";r.statusType="warning";
    }else{
      r.shape="rect";r.nomW=g.diameter;r.nomH=g.diameter;r.openW=g.cutW;r.openH=g.cutH;r.finishedW=g.finishedW;r.finishedH=g.finishedH;r.cutW=g.cutW;r.cutH=g.cutH;
      r.opening=`${fmt0(g.cutW)} × ${fmt0(g.cutH)} mm ${g.lined?"structural cut":"finished aperture"}`;
      r.damper=`Ø ${fmt0(g.diameter)} mm nominal circular duct on a rectangular multiblade casing`;
      r.rule=`The circular spigot is Ø${fmt0(g.spigotOutside)} mm outside diameter, but the opening is controlled by the rectangular FSD-TD casing. BSB ${m.reference} publishes nominal diameter +${fmt0(m.finishedW)} mm width and +${fmt0(m.finishedH)} mm height${g.lined?`; the structural cut then adds one ${fmt(g.board)} mm aperture-lining board at each opposite edge`:""}.`;
      r.range=`BSB FSD-TD-C listed size confirmed: Ø${fmt0(g.diameter)} mm (dimension A ${fmt0(g.dimensions.a)} mm; dimension B ${fmt0(g.dimensions.b)} mm).`;
      r.nominalStage=`Ø ${fmt0(g.diameter)} mm nominal circular duct → Ø ${fmt0(g.spigotOutside)} mm circular spigot O.D.`;
      r.casingStage=`${fmt0(g.casingW)} × ${fmt0(g.casingH)} mm rectangular casing envelope, derived from the IOM's stated casing clearances and published opening allowances`;
      r.finishedStage=`${fmt0(g.finishedW)} × ${fmt0(g.finishedH)} mm finished aperture around the rectangular casing`;
      r.cutStage=g.lined?`Width: ${fmt0(g.finishedW)} + 2 × ${fmt(g.board)} mm lining = ${fmt0(g.cutW)} mm; height: ${fmt0(g.finishedH)} + 2 × ${fmt(g.board)} mm lining = ${fmt0(g.cutH)} mm`:`${fmt0(g.cutW)} × ${fmt0(g.cutH)} mm finished structural aperture`;
      r.visualOpen=Math.max(g.cutW,g.cutH);r.openD=r.visualOpen;r.apertureShape="square";r.sourceStatus="Verified from BSB FSD-TD-C dimensions and selected FSD-TD installation method";r.statusType="verified";
      r.includesLining=g.lined;r.liningMapped=g.lined;r.structuralLiningBottom=g.lined?g.board:0;r.settingOut=m.settingOut;
      r.criticalRules=[`Supporting construction: ${m.wall}.`,`Nominal circular duct/spigot and rectangular damper casing are different geometries: never form the opening from Ø${fmt0(g.diameter)} mm or the Ø${fmt0(g.spigotOutside)} mm spigot alone.`,`Method casing envelope used for setting-out: ${fmt0(g.casingW)} × ${fmt0(g.casingH)} mm; finished aperture: ${fmt0(g.finishedW)} × ${fmt0(g.finishedH)} mm.`,`Manufacturer casing clearances: ${fmt0(m.clearanceLeft)} mm non-actuator side, ${fmt0(m.clearanceRight)} mm actuator side, ${fmt0(m.clearanceBottom)} mm below and ${fmt0(m.clearanceTop)} mm above.`,g.lined?`Opening treatment: line each internal edge with one ${fmt(g.board)} mm fire-rated board after forming the structural cut.`:"Opening treatment: do not add aperture lining unless the selected BSB drawing requires it.",`Certified sealing/fixing arrangement: ${m.seal}.`,`BSB series table entry: Ø${fmt0(g.diameter)} mm, A ${fmt0(g.dimensions.a)} mm, B ${fmt0(g.dimensions.b)} mm.`,`Minimum clear structural separation: 200 mm between separate damper casings.`,`Minimum distance from casing to adjacent wall, floor or ceiling: 75 mm.`,m.note,"Other services must not share the damper opening."];
    }
  }
  else if(m.type==="bsb-circle-dry-lined"){
    const b=parseFloat($("fdBoardThickness").value)||12.5,finished=dia+m.add,cut=finished+2*b;r.visualOpen=r.openD=cut;r.apertureShape="square";r.opening=`${fmt0(cut)} × ${fmt0(cut)} mm structural cut`;r.rule=`Finished square aperture ${fmt0(finished)} mm; cut adds 2 × ${fmt(b)} mm lining board`;r.nominalStage=`Ø ${fmt0(dia)} mm`;r.casingStage=`Ø ${fmt0(dia)} mm nominal damper`;r.finishedStage=`${fmt0(finished)} × ${fmt0(finished)} mm`;r.cutStage=`${fmt0(finished)} + 2 × ${fmt(b)} mm aperture lining = ${fmt0(cut)} mm each way`;r.sourceStatus="Verified from manufacturer method";r.statusType="verified";r.includesLining=true;r.liningMapped=true;r.structuralLiningBottom=b;r.finishedW=finished;r.finishedH=finished;r.cutW=cut;r.cutH=cut;r.criticalRules=[`Supporting construction: ${m.wall}.`,`The drywall opening must be lined with one fire-rated board around each internal edge; wall-face board layers are not added again.`,`Certified sealing/fixing arrangement: ${m.seal}.`,`Minimum clear structural separation: 200 mm between separate damper casings.`,`Minimum distance from casing to adjacent construction: 75 mm.`,m.note,"Provide adjacent access for commissioning, servicing and cleaning."];
  }
  else if(m.type==="bsb-circle-solid"){
    const open=dia+m.add;r.visualOpen=r.openD=open;r.apertureShape="square";r.opening=`${fmt0(open)} × ${fmt0(open)} mm finished aperture`;r.rule=`Nominal diameter +${m.add} mm`;r.nominalStage=`Ø ${fmt0(dia)} mm`;r.casingStage=`Ø ${fmt0(dia)} mm nominal damper`;r.finishedStage=r.opening;r.cutStage=r.opening;r.sourceStatus="Verified from manufacturer method";r.statusType="verified";r.criticalRules=[`Supporting construction: ${m.wall}.`,`Certified sealing/fixing arrangement: ${m.seal}.`,`Use all installation-plate fixing positions.`,`Minimum clear structural separation: 200 mm between separate damper casings, except where a specific tested Batt detail states otherwise.`,`Minimum distance from casing to adjacent construction: 75 mm unless the selected tested drawing states a reduced distance.`,m.note];
  }
  else if(m.type==="bsb-circle-trim"){
    r.visualOpen=r.openD=dia+m.add;r.apertureShape="circle";r.opening=`Ø ${fmt0(dia)} mm nominal — maximum trim Ø ${fmt0(dia+m.add)} mm`;r.rule=`Nominal diameter with up to +${m.add} mm trim tolerance`;r.nominalStage=`Ø ${fmt0(dia)} mm`;r.casingStage=`Ø ${fmt0(dia)} mm nominal damper`;r.finishedStage=r.opening;r.cutStage=r.opening;r.sourceStatus="Verified from manufacturer method";r.statusType="verified";r.criticalRules=[`Supporting construction: ${m.wall}.`,`Certified sealing/fixing arrangement: ${m.seal}.`,m.note,"Do not apply the standard drywall or masonry opening rule to this method."];
  }
  else if(m.type==="bsb-circle-square-table"){
    const open=Number(m.openingTable?.[dia]);
    if(!Number.isFinite(open)){
      r.opening="Size outside published BSB table";r.rule="Select a listed MFD-IC diameter";r.invalidSize=true;
    }else{
      r.visualOpen=r.openD=open;r.apertureShape="square";r.opening=`${fmt(open)} × ${fmt(open)} mm square opening`;r.rule=`Published BSB opening table for Ø${fmt0(dia)} mm`;
      r.nominalStage=`Ø ${fmt0(dia)} mm`;r.casingStage=`Ø ${fmt0(dia)} mm nominal damper`;r.finishedStage=r.opening;r.cutStage=r.opening;r.sourceStatus="Verified from manufacturer opening table";r.statusType="verified";
      r.criticalRules=[`Supporting construction: ${m.wall}.`,`Opening treatment: ${m.reference==="MFD-IC M9"?"the opening must NOT be lined":"do not add aperture lining; fit the tested two-layer ablative Batt arrangement"}.`,`Certified sealing/fixing arrangement: ${m.seal}.`,`Duct connection: connect in accordance with DW144/DW145 using aluminium rivets as breakaway fixings.`,`Supports: connected ductwork must be independently and adequately supported.`,`Minimum clear separation: 200 mm between damper casings and 75 mm to adjacent construction.`,`Use every required installation-plate fixing position.`,m.note];
    }
  }
  else if(m.type==="bsb-circle-round-table"){
    const open=Number(m.openingTable?.[dia]);
    if(!Number.isFinite(open)){
      r.opening="Size outside published BSB table";r.rule="Select a listed MFD-IC diameter";r.invalidSize=true;
    }else{
      r.visualOpen=r.openD=open;r.apertureShape="circle";r.opening=`Ø ${fmt(open)} mm opening`;r.rule=`Published BSB M15 mortar-infill opening table for Ø${fmt0(dia)} mm`;
      r.nominalStage=`Ø ${fmt0(dia)} mm`;r.casingStage=`Ø ${fmt0(dia)} mm nominal damper`;r.finishedStage=r.opening;r.cutStage=r.opening;r.sourceStatus="Verified from manufacturer opening table";r.statusType="verified";
      r.criticalRules=[`Supporting construction: ${m.wall}.`,`Certified sealing/fixing arrangement: ${m.seal}.`,`Duct connection: connect in accordance with DW144/DW145 using aluminium rivets as breakaway fixings.`,`Supports: connected ductwork must be independently and adequately supported.`,`Use fire-rated steel fixings and every required installation-plate fixing position.`,`Minimum clear separation: 200 mm between damper casings and 75 mm to adjacent construction.`,m.note];
    }
  }
  else if(m.type==="bsb-circle-square-fixed"){
    const open=dia+m.add;r.visualOpen=r.openD=open;r.apertureShape="square";r.opening=`${fmt0(open)} × ${fmt0(open)} mm square opening`;r.rule=`Nominal diameter +${m.add} mm`;r.nominalStage=`Ø ${fmt0(dia)} mm`;r.casingStage=`Ø ${fmt0(dia)} mm nominal damper`;r.finishedStage=r.opening;r.cutStage=r.opening;r.sourceStatus="Verified from manufacturer method";r.statusType="verified";r.criticalRules=[`Supporting construction: ${m.wall}.`,`Opening treatment: ${m.reference==="MFD-IC M9"?"the opening must NOT be lined":"do not add lining unless shown in the selected drawing"}.`,`Certified sealing/fixing arrangement: ${m.seal}.`,`Minimum clear separation: 200 mm between damper casings and 75 mm to adjacent construction.`,`Use all required installation-plate fixing holes.`,m.note];
  }
  else if(m.type==="advanced-circle-fixed"){
    const open=dia+m.add;r.visualOpen=open;r.apertureShape=m.openingShape||"square";r.openD=open;
    r.opening=r.apertureShape==="square"?`${fmt0(open)} × ${fmt0(open)} mm opening to form`:`Ø ${fmt0(open)} mm opening`;
    r.rule=`Nominal diameter +${m.add} mm`;
    r.nominalStage=`Ø ${fmt0(dia)} mm`;r.casingStage=`Ø ${fmt0(dia)} mm nominal damper`;r.finishedStage=r.opening;r.cutStage=r.opening;
    r.finishedW=open;r.finishedH=open;r.cutW=open;r.cutH=open;
    r.settingOut={basis:"table-centred",source:`${m.reference}: published opening is centred on the nominal circular duct.`};
    r.sourceStatus="Verified from manufacturer opening table";r.statusType="verified";r.includesLining=false;
    r.criticalRules=[`Supporting construction: ${m.wall}.`,`Certified penetration seal: ${m.seal}.`,`The published opening is the opening to form; where the wall is letterboxed, do not add the board thickness again.`,m.note,"Populate all pre-drilled flange fixing holes.","Leave the stated 10 mm duct expansion clearance and independently support connected ductwork within 1 metre."];
  }
  else if(m.type==="advanced-circle-floor"){
    const open=dia+m.add;r.visualOpen=open;r.apertureShape="square";r.openD=open;
    r.opening=`${fmt0(open)} × ${fmt0(open)} mm minimum opening`;
    r.rule=`Minimum opening = nominal diameter +${m.add} mm`;
    r.range="Maximum opening: 1800 × 1800 mm.";
    r.nominalStage=`Ø ${fmt0(dia)} mm`;r.casingStage=`Ø ${fmt0(dia)} mm nominal damper`;r.finishedStage=r.opening;r.cutStage=r.opening;
    r.finishedW=open;r.finishedH=open;r.cutW=open;r.cutH=open;
    r.settingOut={basis:"table-centred",source:`${m.reference}: minimum opening is formed around the nominal circular damper.`};
    r.sourceStatus="Verified from manufacturer method";r.statusType="verified";r.includesLining=false;
    r.criticalRules=[`Supporting construction: ${m.wall}.`,`Certified infill: ${m.seal}.`,`Minimum opening: nominal diameter +${m.add} mm; maximum 1800 × 1800 mm.`,"Use shuttering and the compound manufacturer's tested mixing/curing instructions.","Independently support connected ductwork within 1 metre.",m.note];
  }
  else if(m.type==="css-dry"){
    const a=parseFloat($("fdAllowance").value)||30,b=parseFloat($("fdBoardThickness").value)||12.5,finished=dia+a,cut=finished+2*b;
    r.visualOpen=cut;r.openD=cut;r.apertureShape="square";r.opening=`${fmt0(cut)} × ${fmt0(cut)} mm structural cut`;
    r.rule=`Finished square opening = casing Ø +${fmt0(a)} mm; structural cut adds 2 × ${fmt(b)} mm aperture lining`;
    r.reference=$("fdWallBuild").value;r.range=`Permitted finished-opening allowance: ${m.min}–${m.max} mm total.`;
    r.nominalStage=`Ø ${fmt0(dia)} mm`;r.casingStage=`Ø ${fmt0(dia)} mm overall casing`;
    r.finishedStage=`${fmt0(finished)} × ${fmt0(finished)} mm finished opening`;
    r.cutStage=`${fmt0(finished)} + 2 × ${fmt(b)} mm lining = ${fmt0(cut)} mm each way`;
    r.finishedW=finished;r.finishedH=finished;r.cutW=cut;r.cutH=cut;
    r.includesLining=true;r.liningMapped=true;r.structuralLiningBottom=b;
    r.sourceStatus="Verified from Actionair CSS installation guide and selected permitted opening allowance";r.statusType="verified";
  }
  else if(m.type==="css-masonry"){
    const a=parseFloat($("fdAllowance").value)||30,shape=$("fdApertureShape").value,open=dia+a;
    r.visualOpen=open;r.openD=open;r.apertureShape=shape;r.opening=shape==="square"?`${fmt0(open)} × ${fmt0(open)} mm square opening`:`Ø ${fmt0(open)} mm circular opening`;
    r.rule=`Overall casing diameter +${fmt0(a)} mm total clearance`;r.range=shape==="square"?`Permitted square allowance: ${m.squareMin}–${m.squareMax} mm total.`:`Permitted circular allowance: ${m.circleMin}–${m.circleMax} mm total.`;
    r.nominalStage=`Ø ${fmt0(dia)} mm`;r.casingStage=`Ø ${fmt0(dia)} mm overall casing`;r.finishedStage=r.opening;r.cutStage=r.opening;
    r.finishedW=open;r.finishedH=open;r.cutW=open;r.cutH=open;r.includesLining=false;
    r.sourceStatus="Verified from Actionair CSS installation guide and selected permitted opening allowance";r.statusType="verified";
  }
  else if(m.type==="css-slab"){
    const a=parseFloat($("fdAllowance").value)||30,open=dia+a;
    r.visualOpen=open;r.openD=open;r.apertureShape="square";r.opening=`${fmt0(open)} × ${fmt0(open)} mm square opening`;
    r.rule=`Overall casing diameter +${fmt0(a)} mm total clearance`;r.range=`Supported square-opening allowance: ${m.squareMin}–${m.squareMax} mm total. Circular slab opening is not enabled because the current guide text and drawing conflict.`;
    r.nominalStage=`Ø ${fmt0(dia)} mm`;r.casingStage=`Ø ${fmt0(dia)} mm overall casing`;r.finishedStage=r.opening;r.cutStage=r.opening;
    r.finishedW=open;r.finishedH=open;r.cutW=open;r.cutH=open;r.includesLining=false;
    r.sourceStatus="Verified from Actionair CSS installation guide and selected permitted opening allowance";r.statusType="verified";
  }
  else if(m.type==="lindab-circle-fixed"){
    const open=dia+m.add;r.visualOpen=open;r.apertureShape=m.openingShape||"circle";r.openD=open;
    r.opening=r.apertureShape==="circle"?`Ø ${fmt0(open)} mm structural wall opening`:`${fmt0(open)} × ${fmt0(open)} mm structural wall opening`;
    r.rule=`Manufacturer D hole size: nominal diameter +${m.add} mm`;r.range=m.note;
    r.nominalStage=`Ø ${fmt0(dia)} mm`;r.casingStage=`Ø ${fmt0(dia)} mm nominal damper`;
    r.finishedStage=`No separate finished clear-opening dimension published — use the structural D-hole and install the specified sealing/infill within it`;
    r.cutStage=r.opening;r.finishedW=null;r.finishedH=null;r.cutW=open;r.cutH=open;r.includesLining=false;r.noSeparateFinishedOpening=true;
    r.sourceStatus="Verified from Lindab manufacturer D-hole method";r.statusType="verified";
    r.criticalRules=[m.note||"Use the supporting construction stated in the official method.",`Structural D-hole allowance: nominal diameter +${m.add} mm.`,`The specified plasterboard, rock wool, mortar or putty is sealing/infill within this opening; VentTools does not add it again as aperture lining.`,`Use only the sealing system shown for the selected certified method.`,"Verify wall/floor thickness, fire classification and size range in the current Lindab booklet."];
  }
  else if(m.type==="lindab-circle-range"){
    const open=dia+m.recommendedAdd;r.visualOpen=open;r.apertureShape=m.openingShape||"circle";r.openD=open;
    r.opening=r.apertureShape==="circle"?`Ø ${fmt0(open)} mm structural wall opening selected`:`${fmt0(open)} × ${fmt0(open)} mm structural wall opening selected`;
    r.rule=`Selected manufacturer D hole: nominal diameter +${m.recommendedAdd} mm`;
    r.range=`Permitted D-hole allowance: +${m.minAdd} to +${m.maxAdd} mm. ${m.note||""}`;
    r.nominalStage=`Ø ${fmt0(dia)} mm`;r.casingStage=`Ø ${fmt0(dia)} mm nominal damper`;
    r.finishedStage=`No separate finished clear-opening dimension published — use the selected structural D-hole and install the specified sealing within it`;
    r.cutStage=r.opening;r.finishedW=null;r.finishedH=null;r.cutW=open;r.cutH=open;r.includesLining=false;r.noSeparateFinishedOpening=true;
    r.sourceStatus="Verified from Lindab manufacturer D-hole range";r.statusType="verified";
    r.criticalRules=[m.note||"Use the supporting construction stated in the official method.",`Permitted structural D-hole allowance: +${m.minAdd} to +${m.maxAdd} mm.`,`Selected allowance: +${m.recommendedAdd} mm.`,`Sealing material occupies the clearance inside the D hole; do not add its thickness to the structural cut.`,`Use only the sealing system shown for the selected certified method.`,"Verify the current Lindab booklet before construction."];
  }
  else if(m.type==="lindab-circle-square-range"){
    const open=dia+m.recommendedAdd;r.visualOpen=open;r.apertureShape="square";r.openD=open;
    r.opening=`${fmt0(open)} × ${fmt0(open)} mm square structural wall opening selected`;
    r.rule=`Selected manufacturer D hole: nominal diameter +${m.recommendedAdd} mm`;
    r.range=`Permitted square D-hole allowance: +${m.minAdd} to +${m.maxAdd} mm. ${m.note||""}`;
    r.nominalStage=`Ø ${fmt0(dia)} mm`;r.casingStage=`Ø ${fmt0(dia)} mm nominal damper`;
    r.finishedStage=`No separate finished clear-opening dimension published — the 12.5 mm plasterboard arch/infill is a face sealing component and rock wool fills the space within the structural D-hole`;
    r.cutStage=r.opening;r.finishedW=null;r.finishedH=null;r.cutW=open;r.cutH=open;r.includesLining=false;r.noSeparateFinishedOpening=true;
    r.sourceStatus="Verified from Lindab manufacturer D-hole range";r.statusType="verified";
    r.criticalRules=[m.note||"Use the supporting construction stated in the official method.",`Square structural D-hole allowance: +${m.minAdd} to +${m.maxAdd} mm.`,`Selected allowance: +${m.recommendedAdd} mm.`,`The 12.5 mm plasterboard arch/infill is a face sealing component around the penetration; it is not a four-sided reveal lining to subtract from D and it is not added outside the D-hole.`,`Use only the sealing system shown for the selected certified method.`,"Verify the current Lindab booklet before construction."];
  }
  if((man.label==="Lindab" || man.label==="BSB" || man.label==="Advanced Air") && p.minSize && (dia<p.minSize || dia>p.maxSize)){
    r.opening="Size outside manual range";
    r.rule=`Supported nominal range: Ø${p.minSize}–${p.maxSize} mm`;
    r.range="Check the current Lindab manual before proceeding.";
    r.invalidSize=true;
  }
 }
 
 if(r && !r.error && ["css-dry","css-masonry","css-slab"].includes(m.type)){
   const nominalDia=Number(r.dia||parseFloat($("fdDiameter")?.value)||0);
   const finishedHeight=Number(r.finishedH??r.openH??r.openD??r.visualOpen);
   const allowanceH=finishedHeight-nominalDia;
   if(Number.isFinite(allowanceH)){
     const cssBoard=m.type==="css-dry"?(parseFloat($("fdBoardThickness")?.value)||0):0;
     r.settingOut={basis:"nominal-duct",bottomFinished:allowanceH/2,topFinished:allowanceH/2,source:"Actionair CSS LNNN00356 v6.0: overall casing diameter plus the selected permitted finished-opening allowance, with the casing centred in the aperture."};
     if(cssBoard){r.includesLining=true;r.liningMapped=true;r.structuralLiningBottom=cssBoard;}
     r.sourceStatus="Verified from Actionair CSS installation guide";
     r.statusType="verified";
   }
 }

 const nominalStage=r.nominalStage||(r.shape==="circle"?r.damper:(r.damper||"—"));
 const casingStage=r.casingStage||(r.damper||"—");
 const finishedStage=r.finishedStage||(r.opening||"—");
 const cutStage=r.cutStage||(r.opening||"—");
 let sourceStatus=r.sourceStatus;
 let statusType=r.statusType;
 if(!sourceStatus){
   if(r.isLinkOnly){sourceStatus="Official drawing or manual input required";statusType="manual";}
   else if(r.invalidSize){sourceStatus="Outside recorded manufacturer range";statusType="warning";}
   else{sourceStatus="Verified from manufacturer method";statusType="verified";}
 }
 const genericRules=[
   r.range||"Verify the permitted opening and supporting construction in the current manufacturer document.",
   "The selected wall/floor construction, sealing system and accessories must match the tested installation method.",
   "Do not substitute materials or alter the tested arrangement without manufacturer approval."
 ].filter(Boolean);
 let criticalRules=(r.criticalRules&&r.criticalRules.length?r.criticalRules:genericRules);
 if(man.label==="BSB" && productKey!=="AT-FSD"){
   const hasDuct=criticalRules.some(x=>/aluminium rivet|breakaway|duct connection/i.test(String(x)));
   const hasSupport=criticalRules.some(x=>/independently supported|independent support/i.test(String(x)));
   if(!hasDuct)criticalRules=[...criticalRules,"Duct connection: connect in accordance with DW144/DW145 using aluminium rivets as breakaway fixings."];
   if(!hasSupport)criticalRules=[...criticalRules,"Supports: connected ductwork must be independently and adequately supported."];
 }
 $("fdOpeningLabel").textContent=r.includesLining
   ?"Structural Hole to Cut (including aperture lining)"
   :"Opening Required by Selected Method";
 $("fdOpeningBig").textContent=r.opening;
 $("fdMethodBig").textContent=`${r.product} • ${r.reference}`;
 $("fdDamperSummary").textContent=r.damper;
 $("fdRuleSummary").textContent=r.rule;
 $("fdReferenceSummary").textContent=r.reference;
 $("fdGuideSummary").textContent=`${p.manualTitle||p.guide} — ${p.revision}`;
 $("fdNominalStage").textContent=nominalStage;
 $("fdCasingStage").textContent=casingStage;
 $("fdFinishedStage").textContent=finishedStage;
 $("fdCutStage").textContent=cutStage;
 const statusEl=$("fdResultStatus");
 statusEl.textContent=sourceStatus;
 statusEl.className=`fd-result-status ${statusType||"verified"}`;
 const rangePanel=$("fdOpeningRange");
 const hasStructuredRange=[r.minOpenW,r.minOpenH,r.maxOpenW,r.maxOpenH].every(Number.isFinite);
 if(rangePanel){
   rangePanel.hidden=!hasStructuredRange;
   if(hasStructuredRange){
     $("fdRangeMinW").textContent=`${fmt0(r.minOpenW)} mm`;
     $("fdRangeMinH").textContent=`${fmt0(r.minOpenH)} mm`;
     $("fdRangeSelectedW").textContent=`${fmt0(r.openW)} mm`;
     $("fdRangeSelectedH").textContent=`${fmt0(r.openH)} mm`;
     $("fdRangeMaxW").textContent=`${fmt0(r.maxOpenW)} mm`;
     $("fdRangeMaxH").textContent=`${fmt0(r.maxOpenH)} mm`;
     $("fdRangeNote").textContent=r.rangeNote||"The minimum published opening is used as the main result.";
   }
 }
 // Bind the rendered result to the exact selection that produced it. This
 // prevents lifecycle/select refreshes from mixing another manufacturer
 // method's notes or setting-out rule into the visible result.
 r.manufacturerKey=manKey;
 r.productKey=productKey;
 r.methodKey=methodKey;
 r.selectionToken=startToken;
 r.methodSnapshot=m;
 r.settingOut=r.settingOut||m.settingOut||null;
 // calcFD is synchronous: the user cannot change the dropdown selection while
 // this calculation is running. The old post-calculation token guard produced
 // false Advanced Air mismatches on Android and trapped the setting-out panel in
 // a permanent “recalculating” state. Selection-change handlers already clear
 // stale UI before starting the next calculation, so render this captured result.
 const mappedNotes=Array.isArray(m.engineeringNotes) ? m.engineeringNotes : [];
 // Core output renders first. Auxiliary panels must never be able to suppress
 // the diagram or builder setting-out for an otherwise valid calculation.
 updateFDSettingOut(r);
 drawFD(r);
 try{renderFDInstallationRequirements([...(criticalRules||[]),...mappedNotes],startToken);}catch(err){console.error("VentTools requirements panel",err);}
 try{renderFDVerification(r);}catch(err){console.error("VentTools verification panel",err);window.__lastFDResult=r;}
 try{refreshFDManualResource();}catch(err){console.error("VentTools manual resource",err);}
 const range=r.range?` ${r.range}`:"";if(r.invalidSize)fdMsg("bad",`⚠ Size is outside the range recorded from the uploaded ${p.guide}.`);
else if(r.isLinkOnly)fdMsg("warn",`⚠ This product has multiple installation-specific opening rules. Select and verify the applicable official ${man.label} drawing before construction.`);
else fdMsg("ok",`✅ Verified from the selected ${man.label} tested installation method.${hasStructuredRange?" Permitted minimum and maximum openings are shown below.":range} The stated opening includes the manufacturer-specified casing build-up and installation/expansion gaps where published. Verify the current official manual before construction.`);return r}

function renderFDInstallationRequirements(rules,selectionToken=""){
  const liveToken=selectionToken||fdSelectionToken();
  const groups={construction:[],duct:[],supports:[],access:[],position:[],critical:[]};
  const clean=(rules||[]).filter(Boolean);
  clean.forEach(rule=>{
    const t=String(rule).toLowerCase();
    if(/ductwork|duct connection|expansion gap|expansion clearance|spigot|overlap|rivet|breakaway|duct seal|connected duct/.test(t)){groups.duct.push(rule);return;}
    if(/hanger|drop-rod|drop rod|independently supported|independent support|support within|afs rails|support rail/.test(t)){groups.supports.push(rule);return;}
    if(/actuator|access|commissioning|servicing|cleaning|maintenance/.test(t)){groups.access.push(rule);return;}
    if(/separation|distance from|adjacent construction|adjacent wall|adjacent floor|adjacent ceiling|centred|centered|position|orientation/.test(t)){groups.position.push(rule);return;}
    if(/supporting construction|wall|floor|opening treatment|penetration seal|sealing\/fixing|sealing arrangement|fire batt|mortar|plaster|board lining|lined opening/.test(t)){groups.construction.push(rule);return;}
    groups.critical.push(rule);
  });
  const map={
    construction:"fdReqConstruction",duct:"fdReqDuct",supports:"fdReqSupports",
    access:"fdReqAccess",position:"fdReqPosition",critical:"fdReqCritical"
  };
  Object.entries(map).forEach(([key,id])=>{
    const el=$(id); if(!el)return;
    const content=el.querySelector(".fd-requirement-content");
    if(!content)return;
    el.hidden=true;
    el.dataset.selectionToken=selectionToken||liveToken;
    content.innerHTML="";
    const items=groups[key];
    if(key==="duct" && !items.length){
      el.hidden=false;
      content.innerHTML='<p class="fd-no-specific-data">No manufacturer-specific duct connection detail is recorded for this selected method. Check the current official installation manual before connecting the ductwork.</p>';
      return;
    }
    el.hidden=!items.length;
    if(items.length)content.innerHTML=`<ul class="fd-checklist">${items.map(x=>`<li><span aria-hidden="true">✓</span><span>${x}</span></li>`).join("")}</ul>`;
  });
}

function updateFDSettingOut(r){
  const ids=["fdSetOpeningBottom","fdSetOpeningTop","fdSetDuctBottom","fdSetDuctTop","fdSetBottomOffset"];
  const clear=()=>ids.forEach(id=>{if($(id))$(id).textContent="—"});
  const answer=$("fdSettingAnswer"),warning=$("fdSettingWarning"),status=$("fdSettingStatus");
  if(!r || r.error || r.isLinkOnly || r.invalidSize){
    clear();
    if(answer)answer.textContent="A setting-out answer is not available for this selection.";
    if(status){status.textContent="Check manual";status.className="fd-setting-badge warning";}
    return;
  }
  // Use the method captured by the completed calculation, exactly as the other
  // manufacturer render paths do. Do not re-read the dropdowns during rendering.
  const m=r.methodSnapshot||null;
  if(r.noBuilderOpening===true){
    clear();
    if(answer)answer.innerHTML="<strong>No separate damper opening is formed.</strong> Coordinate the fire-rated duct penetration and supports to the selected remote-from-wall method.";
    if(warning)warning.textContent=r.settingOut?.source||m?.settingOut?.source||"See the official remote-from-wall installation drawing.";
    if(status){status.textContent="Verified remote method";status.className="fd-setting-badge verified";}
    return;
  }
  const ductH=Number(r.nomH ?? r.dia);
  const openingH=Number(r.openH ?? r.openD ?? r.visualOpen);
  const board=r.includesLining?(Number.isFinite(r.structuralLiningBottom)?Number(r.structuralLiningBottom):(parseFloat($("fdBoardThickness")?.value)||0)):0;
  const rule=r.settingOut||m?.settingOut||null;
  const casingMapped=rule?.basis==="casing-edge" && Number.isFinite(rule.casingProjectionBottom) && Number.isFinite(rule.bottomClearance);
  const nominalMapped=rule?.basis==="nominal-duct" && Number.isFinite(rule.bottomFinished);
  const tableMapped=rule?.basis==="table-centred" && Number.isFinite(openingH) && Number.isFinite(ductH);
  if(!casingMapped && !nominalMapped && !tableMapped){
    clear();
    if($("fdSetDuctBottom"))$("fdSetDuctBottom").textContent=`${fmt(parseFloat($("fdDatumLevel")?.value)||0)} mm AFFL`;
    if(answer)answer.innerHTML="<strong>Do not guess the hole start.</strong> This method has not yet been fully mapped from nominal duct edge → damper casing edge → manufacturer clearance → structural lining.";
    if(warning)warning.textContent="No centred or user-entered assumption has been applied. VentTools will show a setting-out instruction only after every part of that dimension chain has been verified from the official method.";
    if(status){status.textContent="Manual check required";status.className="fd-setting-badge warning";}
    return;
  }
  const casingBottom=casingMapped?Number(rule.casingProjectionBottom):0;
  const casingTop=casingMapped?Number(rule.casingProjectionTop):0;
  const tableHalf=tableMapped?(openingH-ductH)/2:NaN;
  const clearanceBottom=tableMapped?tableHalf:(casingMapped?Number(rule.bottomClearance):Number(rule.bottomFinished));
  const clearanceTop=tableMapped?tableHalf:(casingMapped?Number(rule.topClearance):Number(rule.topFinished));
  const bottomOffset=casingBottom+clearanceBottom+board;
  const topOffset=Number.isFinite(clearanceTop)?(casingTop+clearanceTop+board):NaN;
  const ductBottom=parseFloat($("fdDatumLevel")?.value)||0;
  const openingBottom=ductBottom-bottomOffset;
  const ductTop=Number.isFinite(ductH)?ductBottom+ductH:NaN;
  const openingTop=Number.isFinite(ductTop)?ductTop+topOffset:(Number.isFinite(openingH)?openingBottom+openingH:NaN);
  if($("fdSetOpeningBottom"))$("fdSetOpeningBottom").textContent=`${fmt(openingBottom)} mm AFFL`;
  if($("fdSetOpeningTop"))$("fdSetOpeningTop").textContent=Number.isFinite(openingTop)?`${fmt(openingTop)} mm AFFL`:"—";
  if($("fdSetDuctBottom"))$("fdSetDuctBottom").textContent=`${fmt(ductBottom)} mm AFFL`;
  if($("fdSetDuctTop"))$("fdSetDuctTop").textContent=Number.isFinite(ductTop)?`${fmt(ductTop)} mm AFFL`:"—";
  if($("fdSetBottomOffset"))$("fdSetBottomOffset").textContent=`${fmt(bottomOffset)} mm`;
  if(answer)answer.innerHTML=`Mark the bottom of the <strong>structural opening</strong> <strong>${fmt(bottomOffset)} mm below the bottom of the nominal duct</strong>. This is the cut line before the aperture lining is fitted.`;
  if(warning){
    const chain=casingMapped
      ? `${fmt(casingBottom)} mm from nominal duct to casing edge + ${fmt(clearanceBottom)} mm manufacturer gap below the casing`
      : `${fmt(clearanceBottom)} mm manufacturer gap below the nominal duct edge`;
    warning.textContent=`Breakdown: ${chain}${board?` + ${fmt(board)} mm aperture lining`:""} = ${fmt(bottomOffset)} mm. Source: ${rule.source} Confirm the selected method and official drawing before cutting.`;
  }
  if(status){status.textContent="Verified setting-out";status.className="fd-setting-badge verified";}
}

function getFDSiteSheetDetails(){
  return new Promise(resolve=>{
    document.getElementById("fdSiteSheetDetailsOverlay")?.remove();
    const overlay=document.createElement("div");
    overlay.id="fdSiteSheetDetailsOverlay";
    overlay.setAttribute("role","presentation");
    overlay.innerHTML=`
      <div class="fd-sheet-dialog" role="dialog" aria-modal="true" aria-labelledby="fdSheetDialogTitle">
        <div class="fd-sheet-dialog-head">
          <div>
            <span class="fd-sheet-dialog-kicker">VentTools site instruction</span>
            <h2 id="fdSheetDialogTitle">Sheet details</h2>
          </div>
          <button type="button" class="fd-sheet-dialog-close" aria-label="Cancel and close">&times;</button>
        </div>
        <p class="fd-sheet-dialog-copy">Add the project details for this damper. The verified calculation will be saved into the project pack.</p>
        <label class="fd-sheet-dialog-field">
          <span>Drawing reference / damper tag</span>
          <input id="fdSheetReference" type="text" inputmode="text" autocomplete="off" placeholder="For example FD-01" maxlength="80">
        </label>
        <label class="fd-sheet-dialog-field">
          <span>Location</span>
          <input id="fdSheetLocation" type="text" inputmode="text" autocomplete="off" placeholder="For example Level 1 corridor" maxlength="120">
        </label>
        <div class="fd-sheet-dialog-actions">
          <button type="button" class="fd-sheet-dialog-cancel">Cancel</button>
          <button type="button" class="fd-sheet-dialog-create">Save to Pack</button>
        </div>
      </div>`;
    const style=document.createElement("style");
    style.textContent=`
      #fdSiteSheetDetailsOverlay{position:fixed;inset:0;z-index:99999;display:grid;place-items:end center;padding:16px;background:rgba(10,20,32,.62);backdrop-filter:blur(3px)}
      .fd-sheet-dialog{width:min(100%,560px);max-height:calc(100dvh - 32px);overflow:auto;background:#fff;border-radius:22px;padding:20px;box-shadow:0 24px 70px rgba(0,0,0,.3);color:#142234}
      .fd-sheet-dialog-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px}.fd-sheet-dialog-head h2{margin:3px 0 0;font-size:24px;line-height:1.15}.fd-sheet-dialog-kicker{display:block;color:#075a93;font-size:11px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}
      .fd-sheet-dialog-close{border:0;background:#eef3f6;border-radius:50%;width:40px;height:40px;font-size:28px;line-height:1;cursor:pointer;color:#263746}.fd-sheet-dialog-copy{margin:14px 0 18px;color:#5c6b7a;font-size:14px}
      .fd-sheet-dialog-field{display:block;margin-top:14px}.fd-sheet-dialog-field span{display:block;margin-bottom:7px;font-size:13px;font-weight:800}.fd-sheet-dialog-field input{display:block;width:100%;min-height:52px;padding:12px 14px;border:1px solid #bfcbd5;border-radius:12px;background:#fff;color:#142234;font:inherit;font-size:16px;outline:none}.fd-sheet-dialog-field input:focus{border-color:#075a93;box-shadow:0 0 0 3px rgba(7,90,147,.14)}
      .fd-sheet-dialog-actions{display:grid;grid-template-columns:1fr 1.35fr;gap:10px;margin-top:22px}.fd-sheet-dialog-actions button{min-height:50px;border-radius:12px;font:inherit;font-weight:800;cursor:pointer}.fd-sheet-dialog-cancel{border:1px solid #bfcbd5;background:#fff;color:#263746}.fd-sheet-dialog-create{border:1px solid #075a93;background:#075a93;color:#fff}
      @media(min-width:620px){#fdSiteSheetDetailsOverlay{place-items:center}.fd-sheet-dialog{padding:24px}}
    `;
    overlay.appendChild(style);
    document.body.appendChild(overlay);
    const refInput=overlay.querySelector("#fdSheetReference");
    const locInput=overlay.querySelector("#fdSheetLocation");
    const finish=value=>{overlay.remove();resolve(value)};
    overlay.querySelector(".fd-sheet-dialog-close").addEventListener("click",()=>finish(null));
    overlay.querySelector(".fd-sheet-dialog-cancel").addEventListener("click",()=>finish(null));
    overlay.querySelector(".fd-sheet-dialog-create").addEventListener("click",()=>finish({
      ref:refInput.value.trim()||"Not entered",
      loc:locInput.value.trim()||"Not entered"
    }));
    overlay.addEventListener("click",e=>{if(e.target===overlay)finish(null)});
    overlay.addEventListener("keydown",e=>{
      if(e.key==="Escape")finish(null);
      if(e.key==="Enter" && e.target.tagName==="INPUT") overlay.querySelector(".fd-sheet-dialog-create").click();
    });
    requestAnimationFrame(()=>refInput.focus());
  });
}


const VT_PACK_DB="venttoolsProjectPackDB";
const VT_PACK_STORE="siteSheets";
function vtOpenPackDB(){
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open(VT_PACK_DB,1);
    req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains(VT_PACK_STORE))req.result.createObjectStore(VT_PACK_STORE,{keyPath:"id"})};
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error||new Error("Could not open project database"));
  });
}
async function vtSaveSheetDocument(entry,html){
  const db=await vtOpenPackDB();
  await new Promise((resolve,reject)=>{
    const tx=db.transaction(VT_PACK_STORE,"readwrite");
    tx.objectStore(VT_PACK_STORE).put({id:entry.id,entry,html,updatedAt:new Date().toISOString()});
    tx.oncomplete=resolve;
    tx.onerror=()=>reject(tx.error||new Error("Could not save project pack record"));
    tx.onabort=()=>reject(tx.error||new Error("Project pack save was aborted"));
  });
  const verified=await new Promise((resolve,reject)=>{
    const tx=db.transaction(VT_PACK_STORE,"readonly");
    const req=tx.objectStore(VT_PACK_STORE).get(entry.id);
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error||new Error("Could not verify project pack record"));
  });
  db.close();
  if(!verified?.entry?.id || verified.entry.id!==entry.id) throw new Error("Saved damper could not be verified");
  return verified;
}

function showPackSaveSuccess(entry){
  document.getElementById("vtPackSaveSuccess")?.remove();
  const overlay=document.createElement("div");
  overlay.id="vtPackSaveSuccess";
  overlay.innerHTML=`<div class="vt-save-card" role="dialog" aria-modal="true" aria-labelledby="vtSaveTitle">
    <div class="vt-save-tick" aria-hidden="true">✓</div>
    <h2 id="vtSaveTitle">Saved to Project Pack</h2>
    <p><strong>${String(entry.ref||"Damper")}</strong> has been saved and verified.</p>
    <div class="vt-save-actions"><button type="button" class="vt-stay">Stay here</button><button type="button" class="vt-back">Back to Pack</button></div>
  </div><style>
  #vtPackSaveSuccess{position:fixed;inset:0;z-index:100000;display:grid;place-items:center;padding:18px;background:rgba(10,20,32,.64);backdrop-filter:blur(3px)}
  .vt-save-card{width:min(100%,430px);padding:26px 22px;border-radius:22px;background:#fff;color:#142234;text-align:center;box-shadow:0 25px 70px rgba(0,0,0,.32)}
  .vt-save-tick{display:grid;place-items:center;width:72px;height:72px;margin:0 auto 15px;border-radius:50%;background:#e8f8ef;color:#167047;font-size:42px;font-weight:900}.vt-save-card h2{margin:0 0 8px}.vt-save-card p{margin:0;color:#5a6978}.vt-save-actions{display:grid;grid-template-columns:1fr 1.25fr;gap:10px;margin-top:22px}.vt-save-actions button{min-height:50px;border-radius:12px;font:inherit;font-weight:800}.vt-stay{border:1px solid #bcc8d2;background:#fff;color:#263746}.vt-back{border:1px solid #075a93;background:#075a93;color:#fff}
  </style>`;
  document.body.appendChild(overlay);
  overlay.querySelector(".vt-stay").onclick=()=>overlay.remove();
  overlay.querySelector(".vt-back").onclick=()=>window.location.assign("/pack-builder.html?added="+encodeURIComponent(entry.id));
}

async function buildFDSiteSheet(){
  const saveStatus=document.getElementById("fdSavePrimaryStatus");
  const setSaveStatus=(text,state="")=>{if(saveStatus){saveStatus.textContent=text;saveStatus.className="fd-save-primary-status"+(state?" "+state:"")}};
  setSaveStatus("Preparing save…","is-saving");
  const r=calcFD();
  const verification=r?getFDVerification(r):null;
  if(verification?.status==="draft"){
    fdMsg("warn","🔴 Draft calculations cannot be saved or issued. Open the verification details to see what is missing.");
    setSaveStatus("Draft — cannot be issued","is-error");
    return;
  }
  if(!r || r.error || r.invalidSize){
    fdMsg("warn","Select a valid damper and method first.");
    setSaveStatus("Complete a valid calculation first","is-error");
    return;
  }

  if(verification?.status==="partial" && !confirm("This calculation is only partially verified. Save it for engineering review? It will be marked REVIEW REQUIRED and cannot be issued without confirmation.")){setSaveStatus("Not saved yet");return;}
  const details=await getFDSiteSheetDetails();
  if(!details){setSaveStatus("Not saved yet");return;}
  const {ref,loc}=details;
  const {man,p,m}=currentFD();
  const esc=v=>String(v??"").replace(/[&<>\"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'\"':"&quot;","'":"&#39;"}[c]));
  const datum=parseFloat($("fdDatumLevel")?.value)||0;
  const openingBottom=$("fdSetOpeningBottom")?.textContent||"Manual setting-out check required";
  const openingTop=$("fdSetOpeningTop")?.textContent||"—";
  const ductBottom=$("fdSetDuctBottom")?.textContent||`${fmt(datum)} mm AFFL`;
  const ductTop=$("fdSetDuctTop")?.textContent||"—";
  const bottomOffset=$("fdSetBottomOffset")?.textContent||"—";
  const settingAnswer=$("fdSettingAnswer")?.textContent?.trim()||"Confirm the official manufacturer setting-out method before cutting.";
  const settingWarning=$("fdSettingWarning")?.textContent?.trim()||"No unverified assumption has been applied.";
  const generated=new Date().toLocaleString("en-GB",{dateStyle:"medium",timeStyle:"short"});
  const requirements=[];
  document.querySelectorAll("#fdRequirementsGrid .fd-requirement-group:not([hidden]) li span:last-child").forEach(el=>requirements.push(el.textContent.trim()));
  const builderItems=requirements.filter(x=>/wall|floor|board|track|opening|batt|mortar|separation|construction|lined|fixing/i.test(x));
  const hvacItems=requirements.filter(x=>/duct|rivet|support|actuator|access|thermal|commission|orientation/i.test(x));
  const otherItems=requirements.filter(x=>!builderItems.includes(x)&&!hvacItems.includes(x));
  const rule=m?.settingOut||{};
  const board=r.includesLining?(Number(r.structuralLiningBottom)||parseFloat($("fdBoardThickness")?.value)||0):0;
  const casingBottom=Number.isFinite(Number(rule.casingProjectionBottom))?`${fmt(Number(rule.casingProjectionBottom))} mm`:"Not separately published";
  const casingTop=Number.isFinite(Number(rule.casingProjectionTop))?`${fmt(Number(rule.casingProjectionTop))} mm`:"Not separately published";
  const clearanceBottom=Number.isFinite(Number(rule.bottomClearance))?`${fmt(Number(rule.bottomClearance))} mm`:Number.isFinite(Number(rule.bottomFinished))?`${fmt(Number(rule.bottomFinished))} mm`:"See selected method";
  const clearanceTop=Number.isFinite(Number(rule.topClearance))?`${fmt(Number(rule.topClearance))} mm`:Number.isFinite(Number(rule.topFinished))?`${fmt(Number(rule.topFinished))} mm`:"See selected method";
  const list=items=>items.length?items.map(x=>`<li>${esc(x)}</li>`).join(""):'<li>Follow the selected official manufacturer installation drawing.</li>';
  const isCircle=r.shape==="circle";
  const diagram=isCircle
    ? `<svg viewBox="0 0 560 400" role="img" aria-label="Circular structural opening and nominal damper schematic"><rect x="20" y="20" width="520" height="330" rx="18" class="construction"/><circle cx="280" cy="185" r="132" class="opening"/><circle cx="280" cy="185" r="91" class="damper"/><text x="280" y="181" text-anchor="middle" class="diagram-title">Nominal damper</text><text x="280" y="207" text-anchor="middle" class="diagram-value">${esc(r.damper)}</text><text x="280" y="43" text-anchor="middle" class="diagram-label">${diagramLabel}</text><line x1="148" y1="370" x2="412" y2="370" class="dimension"/><path d="M148 361v18M412 361v18" class="dimension"/><text x="280" y="396" text-anchor="middle" class="diagram-dimension">${esc(r.opening)}</text></svg>`
    : `<svg viewBox="0 0 660 430" role="img" aria-label="Rectangular structural opening and nominal damper schematic"><rect x="24" y="20" width="612" height="355" rx="18" class="construction"/><rect x="105" y="72" width="450" height="250" class="opening"/><rect x="172" y="120" width="316" height="154" class="damper"/><text x="330" y="191" text-anchor="middle" class="diagram-title">Nominal damper</text><text x="330" y="218" text-anchor="middle" class="diagram-value">${esc(r.damper)}</text><text x="330" y="56" text-anchor="middle" class="diagram-label">${diagramLabel}</text><line x1="105" y1="397" x2="555" y2="397" class="dimension"/><path d="M105 388v18M555 388v18" class="dimension"/><text x="330" y="425" text-anchor="middle" class="diagram-dimension">${esc(r.opening)}</text></svg>`;

  const html=`<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=yes,viewport-fit=cover"><meta name="color-scheme" content="light"><title>${esc(ref)} — VentTools Site Instruction Sheet</title>
<style>
:root{--ink:#142234;--muted:#5c6b7a;--line:#d7e0e8;--soft:#f3f6f8;--blue:#075a93;--blue-dark:#063e67;--blue-soft:#eaf5fc;--amber:#9a6500;--amber-soft:#fff7df;--green:#176b45;--white:#fff}
*{box-sizing:border-box}html{width:100%;min-width:0;background:#e9eef2}body{width:100%;min-width:0;margin:0;font-family:Arial,Helvetica,sans-serif;color:var(--ink);line-height:1.45;-webkit-font-smoothing:antialiased}.toolbar{position:sticky;top:0;z-index:20;display:flex;gap:10px;justify-content:center;padding:12px max(12px,env(safe-area-inset-right)) 12px max(12px,env(safe-area-inset-left));background:rgba(20,34,52,.96);box-shadow:0 4px 18px rgba(0,0,0,.18)}button{appearance:none;border:0;border-radius:9px;padding:11px 15px;font:700 14px Arial;cursor:pointer}.primary{background:#fff;color:var(--blue-dark)}.secondary{background:#2f465d;color:#fff}.sheet{width:calc(100% - 32px);max-width:210mm;min-height:297mm;margin:22px auto;background:#fff;box-shadow:0 10px 38px rgba(20,34,52,.16);padding:15mm}.report-header{display:grid;grid-template-columns:1fr auto;gap:20px;align-items:start;border-bottom:4px solid var(--blue);padding-bottom:14px}.brand{display:flex;gap:12px;align-items:center}.mark{width:52px;height:52px;border-radius:12px;background:var(--blue);color:#fff;display:grid;place-items:center;font-size:23px;font-weight:900}.eyebrow,.label{font-size:10px;line-height:1.2;letter-spacing:.09em;text-transform:uppercase;font-weight:800;color:var(--muted)}h1{font-size:27px;line-height:1.1;margin:3px 0 0;color:var(--blue-dark)}h2{font-size:16px;margin:0;color:var(--blue-dark)}.doc-meta{text-align:right;font-size:12px;color:var(--muted)}.doc-meta strong{display:block;color:var(--ink);font-size:13px}.identity{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:14px}.field{border:1px solid var(--line);border-radius:9px;padding:10px 11px;min-height:60px}.field strong{display:block;margin-top:5px;font-size:14px;overflow-wrap:anywhere}.hero{margin-top:14px;border:2px solid #78b9df;background:var(--blue-soft);border-radius:12px;padding:17px;text-align:center}.hero .value{display:block;font-size:30px;line-height:1.15;font-weight:900;color:var(--blue-dark);margin-top:5px}.hero p{margin:8px 0 0;font-size:12px;color:#3f5a6f}.section{margin-top:14px;border:1px solid var(--line);border-radius:11px;overflow:hidden;break-inside:avoid}.section-head{display:flex;justify-content:space-between;gap:10px;align-items:center;padding:10px 13px;background:var(--soft);border-bottom:1px solid var(--line)}.verified{font-size:10px;font-weight:800;color:var(--green);text-transform:uppercase;letter-spacing:.06em}.grid{display:grid}.setting-grid{grid-template-columns:repeat(5,1fr)}.engineering-grid{grid-template-columns:repeat(3,1fr)}.cell{padding:11px 12px;border-right:1px solid var(--line);border-bottom:1px solid var(--line);min-height:67px}.cell:nth-child(5n){border-right:0}.engineering-grid .cell:nth-child(3n){border-right:0}.cell strong{display:block;margin-top:5px;font-size:14px}.instruction{padding:13px;border-top:1px solid var(--line);background:#fbfcfd;font-size:13px}.instruction strong{color:var(--blue-dark)}.breakdown{padding:11px 13px;background:var(--amber-soft);border-top:1px solid #ead49e;font-size:12px;color:#634b18}.diagram-wrap{padding:12px 14px 6px}.diagram-wrap svg{display:block;width:100%;max-height:290px}.construction{fill:#f1f3f5;stroke:#65798b;stroke-width:4}.opening{fill:#d9edf8;stroke:#0875b6;stroke-width:5}.damper{fill:#fff;stroke:#273b4d;stroke-width:5}.diagram-title{font-size:19px;font-weight:800;fill:#142234}.diagram-value{font-size:17px;fill:#405263}.diagram-label{font-size:14px;font-weight:800;fill:#0875b6}.dimension{stroke:#142234;stroke-width:3;fill:none}.diagram-dimension{font-size:18px;font-weight:800;fill:#142234}.diagram-note{margin:0;padding:0 14px 12px;text-align:center;font-size:10px;color:var(--muted)}.requirements{display:grid;grid-template-columns:1fr 1fr}.req{padding:13px 15px}.req+ .req{border-left:1px solid var(--line)}.req h3{font-size:14px;margin:0 0 8px;color:var(--blue-dark)}ul{margin:0;padding-left:20px}li{margin:0 0 7px;font-size:12px}.warning{margin-top:14px;border:1px solid #dfbd62;background:var(--amber-soft);border-radius:10px;padding:12px 14px;font-size:12px}.warning strong{color:#714b00}.signoff{display:grid;grid-template-columns:2fr 1fr 1fr;gap:10px;margin-top:14px}.sign{border-bottom:1px solid #70808f;min-height:44px;padding-top:24px;font-size:10px;color:var(--muted)}footer{display:flex;justify-content:space-between;gap:16px;margin-top:15px;padding-top:10px;border-top:1px solid var(--line);font-size:9px;color:var(--muted)}
@media screen and (max-width:760px){html{background:#fff}.toolbar{width:100%;max-width:100vw}.sheet{max-width:none!important}.diagram-wrap,.section,.identity,.hero{max-width:100%}.toolbar{justify-content:stretch}.toolbar button{flex:1;min-width:0}.sheet{width:100%!important;min-height:0;margin:0;box-shadow:none;padding:18px 14px 28px}.report-header{grid-template-columns:1fr}.doc-meta{text-align:left}.identity{grid-template-columns:1fr 1fr}.hero .value{font-size:26px}.setting-grid,.engineering-grid{grid-template-columns:1fr 1fr}.cell,.cell:nth-child(5n),.engineering-grid .cell:nth-child(3n){border-right:1px solid var(--line)}.cell:nth-child(2n){border-right:0}.requirements{grid-template-columns:1fr}.req+ .req{border-left:0;border-top:1px solid var(--line)}.signoff{grid-template-columns:1fr}footer{display:block}footer span{display:block;margin-top:4px}}
@media(max-width:430px){.identity{grid-template-columns:1fr}.setting-grid,.engineering-grid{grid-template-columns:1fr}.cell,.cell:nth-child(2n){border-right:0}.brand{align-items:flex-start}.mark{width:45px;height:45px}h1{font-size:23px}}
@page{size:A4;margin:8mm}@media print{html,body{background:#fff}.toolbar{display:none!important}.sheet{width:auto;min-height:auto;margin:0;padding:0;box-shadow:none}.report-header{padding-bottom:6px}.report-header h1{font-size:22px;margin:2px 0}.doc-meta{font-size:9px}.identity,.hero,.section,.warning,.signoff{break-inside:avoid}.identity{gap:6px;margin-top:7px}.hero{padding:8px;margin-top:7px}.hero .value{font-size:21px}.section{margin-top:7px}.section h2{font-size:13px;margin-bottom:5px}.cell{min-height:42px;padding:5px 7px}.cell span{font-size:8.5px}.cell strong{font-size:12px;margin-top:3px}.diagram-wrap{padding:6px}.diagram-wrap svg{max-height:185px}.req{padding:7px 9px}li{margin-bottom:2px;font-size:9.5px;line-height:1.25}.warning{margin-top:7px;padding:6px 8px;font-size:9.5px}.signoff{margin-top:7px}.signoff .cell{min-height:35px}footer{margin-top:7px;font-size:8.5px}}
.verification-stamp{margin:12px 0;padding:12px 14px;border:2px solid #27845a;border-radius:12px;background:#eefaf3;display:flex;justify-content:space-between;gap:10px}.verification-stamp.partial{border-color:#c99312;background:#fff8df}.verification-stamp.draft{border-color:#bd3535;background:#fff0f0}</style></head><body>
<div class="toolbar"><button class="primary" onclick="window.print()">Print / Save PDF</button><button class="secondary" onclick="shareSheet()">Share</button><button class="secondary" onclick="window.close()">Close</button></div>
<main class="sheet">
<header class="report-header"><div class="brand"><div class="mark">VT</div><div><div class="eyebrow">VentTools engineering output</div><h1>Site Instruction Sheet</h1></div></div><div class="doc-meta"><span class="eyebrow">Generated</span><strong>${esc(generated)}</strong><span>V1.3.0 · Independent site aid</span></div></header>
<section class="verification-stamp ${verification.status}"><strong>${verification.icon} ${esc(verification.label.toUpperCase())}</strong><span>${esc(verification.issueLabel)}</span></section>
<section class="identity"><div class="field"><span class="label">Drawing reference / tag</span><strong>${esc(ref)}</strong></div><div class="field"><span class="label">Location</span><strong>${esc(loc)}</strong></div><div class="field"><span class="label">Manufacturer / product</span><strong>${esc(man.label)} ${esc(r.product)}</strong></div><div class="field"><span class="label">Tested method / reference</span><strong>${esc(r.reference)}</strong></div></section>
<section class="hero"><span class="label">Structural opening / required aperture</span><span class="value">${esc(r.opening)}</span><p>${esc(r.finishedStage||"Finished opening required for the selected verified installation method.")}</p></section>
<section class="section"><div class="section-head"><h2>Setting-out levels</h2><span class="verified">Manufacturer-mapped method</span></div><div class="grid setting-grid"><div class="cell"><span class="label">Nominal duct bottom</span><strong>${esc(ductBottom)}</strong></div><div class="cell"><span class="label">Nominal duct top</span><strong>${esc(ductTop)}</strong></div><div class="cell"><span class="label">Structural opening bottom</span><strong>${esc(openingBottom)}</strong></div><div class="cell"><span class="label">Structural opening top</span><strong>${esc(openingTop)}</strong></div><div class="cell"><span class="label">Bottom cut-line offset</span><strong>${esc(bottomOffset)}</strong></div></div><div class="instruction"><strong>Site instruction:</strong> ${esc(settingAnswer)}</div><div class="breakdown"><strong>Verified dimension chain:</strong> ${esc(settingWarning)}</div></section>
<section class="section"><div class="section-head"><h2>Engineering data</h2><span class="verified">Keep duct, casing and opening separate</span></div><div class="grid engineering-grid"><div class="cell"><span class="label">Nominal duct / damper</span><strong>${esc(r.damper)}</strong></div><div class="cell"><span class="label">Finished opening</span><strong>${esc(r.finishedStage||r.opening)}</strong></div><div class="cell"><span class="label">Structural hole to cut</span><strong>${esc(r.cutStage||r.opening)}</strong></div><div class="cell"><span class="label">Casing projection below / above duct</span><strong>${esc(casingBottom)} / ${esc(casingTop)}</strong></div><div class="cell"><span class="label">Manufacturer clearance below / above casing</span><strong>${esc(clearanceBottom)} / ${esc(clearanceTop)}</strong></div><div class="cell"><span class="label">Aperture lining included</span><strong>${board?`${esc(fmt(board))} mm`:(r.includesLining?"Included by selected method":"No separate lining entered")}</strong></div></div></section>
<section class="section"><div class="section-head"><h2>Finished opening setup</h2><span class="label">Schematic · not to scale</span></div><div class="diagram-wrap">${diagram}</div><p class="diagram-note">VentTools-generated schematic based on the selected verified calculation. It is not a copied manufacturer drawing.</p></section>
<section class="section"><div class="section-head"><h2>Trade requirements</h2><span class="label">Read before installation</span></div><div class="requirements"><div class="req"><h3>Builder / dryliner</h3><ul>${list(builderItems)}</ul></div><div class="req"><h3>HVAC installer</h3><ul>${list(hvacItems)}</ul></div>${otherItems.length?`<div class="req" style="grid-column:1/-1;border-top:1px solid var(--line)"><h3>Additional critical requirements</h3><ul>${list(otherItems)}</ul></div>`:""}</div></section>
<section class="section"><div class="section-head"><h2>Engineering traceability</h2><span class="verified">${verification.icon} ${esc(verification.label)}</span></div><div class="grid engineering-grid"><div class="cell"><span class="label">Manufacturer</span><strong>${esc(verification.traceability.manufacturer)}</strong></div><div class="cell"><span class="label">Product</span><strong>${esc(verification.traceability.product)}</strong></div><div class="cell"><span class="label">Installation method</span><strong>${esc(verification.traceability.installationMethod)}</strong></div><div class="cell"><span class="label">Source document</span><strong>${esc(verification.traceability.sourceDocument)}</strong></div><div class="cell"><span class="label">Source revision</span><strong>${esc(verification.traceability.sourceRevision)}</strong></div><div class="cell"><span class="label">VentTools database</span><strong>${esc(verification.traceability.databaseVersion)}</strong></div></div></section>
<div class="warning"><strong>Important:</strong> This sheet is an independent site aid. The current ${esc(man.label)} manual, tested installation drawing, project fire strategy and approved supporting construction take precedence. Do not substitute unverified dimensions or installation methods.</div>
<div class="signoff"><div class="sign">Issued / explained by</div><div class="sign">Date</div><div class="sign">Accepted by</div></div>
<footer><span>Source: ${esc(p.guide)} — ${esc(p.revision)}</span><span>Generated by VentTools V1.3.0</span></footer>
</main><script>async function shareSheet(){const safeName='VentTools-${esc(ref)}-Site-Instruction.html'.replace(/[^a-z0-9._-]+/gi,'-');const file=new File(['<!doctype html>'+document.documentElement.outerHTML],[safeName],{type:'text/html'});try{if(navigator.share&&navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({title:document.title,text:'VentTools Site Instruction Sheet — ${esc(ref)}',files:[file]});return}}catch(e){if(e&&e.name==='AbortError')return}const a=document.createElement('a');a.href=URL.createObjectURL(file);a.download=safeName;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1500)}</script></body></html>`;

  try{
    const key="venttoolsProjectPackV1";
    const existing=JSON.parse(localStorage.getItem(key)||"[]");
    const entry={
      id:"fd-"+Date.now()+"-"+Math.random().toString(36).slice(2,8),
      createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),
      ref,loc,manufacturer:man.label,product:r.product,reference:r.reference,
      damper:r.damper,opening:r.opening,finishedOpening:r.finishedStage||r.opening,
      structuralOpening:r.cutStage||r.opening,openingBottom,openingTop,ductBottom,ductTop,bottomOffset,
      settingAnswer,settingWarning,source:`${p.guide} — ${p.revision}`,
      verificationStatus:verification.status,verificationLabel:verification.label,issueLabel:verification.issueLabel,
      canIssue:verification.canIssue,verificationChecks:verification.checks,traceability:verification.traceability,engineering:verification.engineering
    };
    // Save the lightweight schedule row FIRST. This is the source of truth for the dashboard.
    const withoutDuplicate=Array.isArray(existing)?existing.filter(x=>x.id!==entry.id):[];
    withoutDuplicate.push(entry);
    localStorage.setItem(key,JSON.stringify(withoutDuplicate));

    // Read it back before showing success. Navigation is never used as the save trigger.
    const verifiedList=JSON.parse(localStorage.getItem(key)||"[]");
    const verifiedEntry=Array.isArray(verifiedList)?verifiedList.find(x=>x.id===entry.id):null;
    if(!verifiedEntry) throw new Error("Project Pack row did not verify");

    // Save the full report separately. Failure here must never remove the dashboard row.
    try{localStorage.setItem("venttoolsSiteSheetHtml:"+entry.id,html)}catch(reportStorageError){}
    try{await vtSaveSheetDocument(entry,html)}catch(databaseError){}

    setSaveStatus(`✓ ${entry.ref} saved to Project Pack`,"is-saved");
    showPackSaveSuccess(entry);
  }catch(e){
    console.error("VentTools Save to Pack failed",e);
    setSaveStatus("Save failed — please try again","is-error");
    fdMsg("warn","Save failed before verification. Please check that browser storage is enabled and try again.");
  }
}
async function copyFD(){const r=calcFD(),{man,p}=currentFD();const t=`Vent Tools — Fire Damper Opening\n\nManufacturer: ${man.label}\nProduct: ${r.product}\nMethod/reference: ${r.reference}\nDamper size: ${r.damper}\nFinished opening: ${r.finishedStage||r.opening}\nStructural hole to cut: ${r.cutStage||r.opening}\nRule: ${r.rule}\nGuide: ${p.guide} — ${p.revision}\n\nIndependent calculator. Verify against the current official manufacturer installation manual.`;try{await navigator.clipboard.writeText(t);fdMsg("ok","✅ Fire damper result copied.")}catch(e){fdMsg("warn","Could not copy automatically.")}}
function resetFD(){$("fdDatumLevel")&&( $("fdDatumLevel").value=2400);$("fdManufacturer").value="BSB";$("fdWidth").value=500;$("fdHeight").value=300;$("fdDiameter").value=250;$("fdBoardThickness").value=12.5;$("fdDwfxBoard").value=12.5;$("fdDwfxVariant").value="SMOKE";$("fdApertureShape").value="square";fillFDProducts()}

const FD_OFFICIAL_RESOURCES={
  "BSB::FSD-TD":{url:"https://www.bsb-dampers.co.uk/wp-content/uploads/2024/07/fsd_td_iom.pdf",title:"BSB FSD-TD Installation, Operation and Maintenance Instructions",revision:"V62904"},
  "BSB::FSD-TD-C":{url:"https://www.bsb-dampers.co.uk/wp-content/uploads/2024/07/fsd_td_iom.pdf",title:"BSB FSD-TD-C dimensions and FSD-TD Installation, Operation and Maintenance Instructions",revision:"FSD-TD Series V12607 • IOM V62904"},
  "BSB::FD-C-AF":{url:BSB_FD_SERIES_URL,title:"BSB FD Series dimensions and verified FD-AF installation method drawings",revision:"V12607",buttonLabel:"Open Official BSB FD Series Method Drawings"},
  "BSB::FD-C":{url:"https://www.bsb-dampers.co.uk/wp-content/uploads/2024/07/fd_c_series_iom.pdf",title:"BSB FD-C Installation, Operation and Maintenance Instructions",revision:"V62904"},
  "BSB::FSD-C":{url:"https://www.bsb-dampers.co.uk/wp-content/uploads/2024/07/fsd_c_iom_11zon.pdf",title:"BSB FSD-C Installation, Operation and Maintenance Instructions",revision:"V62904"},
  "BSB::MFD-IC":{url:"https://www.bsb-dampers.co.uk/wp-content/uploads/2026/06/MFD-IC-IOM.pdf",title:"BSB MFD-IC Installation, Operation and Maintenance Instructions",revision:"V012606"},
  "BSB::AT-FSD":{url:"https://www.bsb-dampers.co.uk/wp-content/uploads/2024/07/at_fsd_iom_compressed.pdf",title:"BSB AT-FSD Installation, Operation and Maintenance Instructions",revision:"V12204"},
  // Advanced Air retains Rev1.0 in the URL, while the PDF served at that URL
  // identifies itself internally as 0160_IOM_Rev1.1_Apr26.
  "ADVANCED_AIR::0160":{url:"https://www.advancedair.co.uk/app/uploads/0160_IOM_Rev1.0.pdf",title:"0160 Installation Manual",revision:"Rev 1.1 • April 2026"},
  "ADVANCED_AIR::2530":{url:"https://www.advancedair.co.uk/app/uploads/2530_IOM_Rev1.1.pdf",title:"2530 Installation Manual",revision:"Rev 1.1"},
  "ADVANCED_AIR::26SCD":{url:"https://www.advancedair.co.uk/app/uploads/26SCD_IOM_Rev1.0.pdf",title:"26SCD Installation Manual",revision:"Rev 1.0"},
  "ADVANCED_AIR::0400MAN":{url:"https://www.advancedair.co.uk/app/uploads/0400-0500_IOM_Rev1.1.pdf",title:"0400/0500 Installation Manual",revision:"Rev 1.1"},
  "ADVANCED_AIR::0400FME":{url:"https://www.advancedair.co.uk/app/uploads/0400-0500_IOM_Rev1.1.pdf",title:"0400/0500 Installation Manual",revision:"Rev 1.1"},
  "ADVANCED_AIR::0500MAN":{url:"https://www.advancedair.co.uk/app/uploads/0400-0500_IOM_Rev1.1.pdf",title:"0400/0500 Installation Manual",revision:"Rev 1.1"},
  "ADVANCED_AIR::0500FME":{url:"https://www.advancedair.co.uk/app/uploads/0400-0500_IOM_Rev1.1.pdf",title:"0400/0500 Installation Manual",revision:"Rev 1.1"}
};

function canonicalFDProductKey(manufacturerKey,select){
  const raw=String(select?.value||"").trim();
  const manufacturer=FD_MANUFACTURERS?.[manufacturerKey];
  // The actual select value is always authoritative when it is a registered
  // product key. This is essential for numeric-looking Advanced Air codes.
  if(raw && manufacturer?.products?.[raw]) return raw;
  const label=String(select?.options?.[select.selectedIndex]?.textContent||"").trim();
  // Product display labels always begin with the stable model code. Using the
  // label as a second source prevents numeric-looking IDs such as 0160 and 2530
  // from ever retaining a previous product resource.
  const labelCode=(label.split(/\s+[—-]\s+/)[0]||"").trim();
  let key=raw || labelCode;
  if(/^0?160$/i.test(raw)||/^0?160$/i.test(labelCode)) key="0160";
  else if(/^(2530|2630)$/i.test(raw)||/^(2530|2630)$/i.test(labelCode)) key="2530";
  else if(labelCode) key=labelCode;
  return key;
}

function resolveFDOfficialResource(){
  const manufacturerSelect=$("fdManufacturer");
  const productSelect=$("fdSeries");
  if(!manufacturerSelect||!productSelect)return null;
  const manufacturerKey=String(manufacturerSelect.value||"").trim();
  const productKey=canonicalFDProductKey(manufacturerKey,productSelect);
  const man=FD_MANUFACTURERS[manufacturerKey];
  const product=man?.products?.[productKey]||man?.products?.[String(productSelect.value||"").trim()];
  const resourceKey=`${manufacturerKey}::${productKey}`;
  const registry=FD_OFFICIAL_RESOURCES[resourceKey];
  if(registry)return {manufacturerKey,productKey,man,product,...registry,onlineUrl:registry.url,url:registry.url,offline:false};
  if(product?.manual)return {
    manufacturerKey,productKey,man,product,
    url:product.manual,
    title:product.manualTitle||product.guide||`${productKey} Installation Manual`,
    revision:product.revision||"Current revision"
  };
  return {manufacturerKey,productKey,man,product,url:"",title:"",revision:""};
}

function updateFDManualButtonLabel(){
  const link=$("fdManualLink");
  const titleEl=$("fdManualTitle");
  const brochureLink=$("fdBrochureLink");
  if(!link||!titleEl)return;

  // Clear first. A failed lookup can never leave the previous damper visible.
  link.removeAttribute("href");
  link.removeAttribute("target");
  link.setAttribute("aria-disabled","true");
  link.innerHTML='<span aria-hidden="true">📄</span> Official manual not mapped';
  titleEl.textContent="Official documentation not yet mapped for this product.";
  if(brochureLink){brochureLink.hidden=true;brochureLink.removeAttribute("href");}

  const resource=resolveFDOfficialResource();
  if(!resource?.man||!resource.url)return;
  const productLabel=(resource.product?.label||resource.productKey).split(/\s+[—-]\s+/)[0];
  link.href=resource.url;
  link.target="_blank";
  link.rel="noopener noreferrer";
  link.removeAttribute("aria-disabled");
  link.innerHTML=`<span aria-hidden="true">📄</span> ${resource.buttonLabel||`Open ${resource.offline?"Offline ":"Official "}${resource.man.label} ${productLabel} IOM`}`;
  link.setAttribute("aria-label",resource.buttonLabel||`Open official ${resource.man.label} ${productLabel} installation manual`);
  titleEl.textContent=`${resource.man.label} • ${resource.title} • ${resource.revision}${resource.offline?" • bundled offline copy":""}`;
  link.dataset.resourceKey=`${resource.manufacturerKey}::${resource.productKey}`;
  if(brochureLink&&resource.product?.brochure){brochureLink.href=resource.product.brochure;brochureLink.hidden=false;brochureLink.setAttribute("aria-label",`Open official ${resource.man.label} ${productLabel} product dimensions`);}
}

function refreshFDManualResource(){
  updateFDManualButtonLabel();
  // Repeat after the current select/calculation event has completed. This guards
  // against any later result renderer writing an older product resource.
  requestAnimationFrame(updateFDManualButtonLabel);
  setTimeout(updateFDManualButtonLabel,0);
}

// Initialise the fire-damper UI only after the official resource registry is ready.
if($("fdSeries")){
  const fdSelectSnapshot={manufacturer:"",product:"",method:""};
  const rememberFDSelects=()=>{
    fdSelectSnapshot.manufacturer=String($("fdManufacturer")?.value||"");
    fdSelectSnapshot.product=String($("fdSeries")?.value||"");
    fdSelectSnapshot.method=String($("fdMethod")?.value||"");
  };
  const genuineChange=(key,value)=>{
    value=String(value||"");
    if(fdSelectSnapshot[key]===value)return false;
    fdSelectSnapshot[key]=value;
    return true;
  };
  $("fdManufacturer").addEventListener("change",()=>{
    if(!genuineChange("manufacturer",$("fdManufacturer").value))return;
    clearFDSelectionDependentUI("Selection changed — recalculating…",true);
    fillFDProducts();rememberFDSelects();refreshFDManualResource();
  });
  $("fdSeries").addEventListener("change",()=>{
    if(!genuineChange("product",$("fdSeries").value))return;
    clearFDSelectionDependentUI("Selection changed — recalculating…",true);
    fillFDMethods();rememberFDSelects();refreshFDManualResource();
  });
  $("fdManufacturer").addEventListener("change",refreshFDManualResource,true);
  $("fdSeries").addEventListener("change",refreshFDManualResource,true);
  $("fdWk25Config")?.addEventListener("change",updateFDInputs);
  $("fdWk25Axis")?.addEventListener("change",calcFD);
  $("fdMethod").addEventListener("change",()=>{
    if(!genuineChange("method",$("fdMethod").value))return;
    clearFDSelectionDependentUI("Selection changed — recalculating…",true);
    updateFDInputs();rememberFDSelects();
  });
  $("fdApertureShape").addEventListener("change",updateFDInputs);
  ["fdWallBuild","fdAllowance","fdDwfxWAllowance","fdDwfxHAllowance","fdHevacGap"].forEach(id=>$(id).addEventListener("change",calcFD));
  $("fdDwfxVariant").addEventListener("change",()=>{configureDwfx(currentFD().m);updateFDInputs()});
  $("fdDwfxInputBasis")?.addEventListener("change",updateFDInputs);
  ["fdDatumLevel"].forEach(id=>{const el=$(id);if(!el)return;
    const liveSetting=()=>{
      const r=window.__lastFDResult;
      if(r && r.selectionToken===fdSelectionToken()) updateFDSettingOut(r);
      else calcFD();
    };
    el.addEventListener("input",liveSetting);
    el.addEventListener("change",liveSetting);
    el.addEventListener("blur",liveSetting);
  });
  $("fdHevacVariant").addEventListener("change",calcFD);
  $("fdSpanVariant").addEventListener("change",()=>{updateSpanInputs();calcFD()});
  ["fdWidth","fdHeight","fdDiameter","fdBoardThickness","fdDwfxBoard","fdSpanWidth","fdSpanHeight","fdSpanDiameter"].forEach(id=>$(id).addEventListener("input",calcFD));
  $("fdCopyBtn").addEventListener("click",copyFD);
  document.querySelectorAll("[data-save-pack]").forEach(btn=>btn.addEventListener("click",buildFDSiteSheet));
  $("fdResetBtn").addEventListener("click",resetFD);
  const initialiseFD=()=>{fillFDProducts();rememberFDSelects();refreshFDManualResource();calcFD();rememberFDSelects()};
  const resumeFD=()=>{
    const live=currentFD();
    if(!live.man||!live.p||!live.m){initialiseFD();return;}
    refreshFDManualResource();
    calcFD();
    rememberFDSelects();
  };
  initialiseFD();
  window.addEventListener("pageshow",event=>{event.persisted?resumeFD():refreshFDManualResource()});
  document.addEventListener("visibilitychange",()=>{if(!document.hidden)resumeFD()});
}



// VentTools install-to-home-screen support.
let deferredInstallPrompt=null;
const installBtn=document.getElementById('installVentToolsBtn');
const installModal=document.getElementById('installHelpModal');
const installHelpText=document.getElementById('installHelpText');

function isIOSDevice(){
  return /iphone|ipad|ipod/i.test(navigator.userAgent);
}
function isStandaloneMode(){
  return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone===true;
}
function closeInstallModal(){
  if(installModal) installModal.hidden=true;
}

window.addEventListener('beforeinstallprompt',(event)=>{
  event.preventDefault();
  deferredInstallPrompt=event;
  if(installBtn && !isStandaloneMode()) installBtn.hidden=false;
});

window.addEventListener('appinstalled',()=>{
  deferredInstallPrompt=null;
  if(installBtn) installBtn.hidden=true;
});

if(installBtn){
  if(!isStandaloneMode()) installBtn.hidden=false;
  installBtn.addEventListener('click',async()=>{
    if(deferredInstallPrompt){
      deferredInstallPrompt.prompt();
      await deferredInstallPrompt.userChoice;
      deferredInstallPrompt=null;
      installBtn.hidden=true;
      return;
    }
    if(isIOSDevice()){
      installHelpText.textContent='In Safari, tap the Share button, then choose “Add to Home Screen”.';
    }else{
      installHelpText.textContent='Open your browser menu and choose “Install app” or “Add to Home screen”.';
    }
    installModal.hidden=false;
  });
}
document.getElementById('closeInstallHelp')?.addEventListener('click',closeInstallModal);
document.getElementById('installHelpOkay')?.addEventListener('click',closeInstallModal);
installModal?.addEventListener('click',(event)=>{if(event.target===installModal)closeInstallModal()});

if('serviceWorker' in navigator){
  window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
}


const VT_GA_ID=window.VENTTOOLS_GA_ID||"G-KWBWNN0WCB";
let vtAnalyticsLoaded=false;

function loadVentToolsAnalytics(){
  if(vtAnalyticsLoaded || !VT_GA_ID) return;
  vtAnalyticsLoaded=true;
  window.dataLayer=window.dataLayer||[];
  window.gtag=window.gtag||function(){window.dataLayer.push(arguments);};
  window.gtag("consent","default",{
    analytics_storage:"granted",
    ad_storage:"denied",
    ad_user_data:"denied",
    ad_personalization:"denied"
  });
  window.gtag("js",new Date());
  window.gtag("config",VT_GA_ID,{
    anonymize_ip:true,
    send_page_view:false
  });
  const tag=document.createElement("script");
  tag.async=true;
  tag.src=`https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(VT_GA_ID)}`;
  document.head.appendChild(tag);
  sendVentToolsPageView();
}

function sendVentToolsPageView(){
 if(!vtAnalyticsLoaded || typeof window.gtag!=="function") return;
 window.gtag("event","page_view",{
    page_title:document.title,
    page_location:location.href,
    page_path:`${location.pathname}${location.search}`
  });
}

function disableVentToolsAnalytics(){
  if(typeof window.gtag==="function"){
    window.gtag("consent","update",{analytics_storage:"denied"});
  }
}

const VT_CONSENT_KEY="venttools-consent-v1";
function getCookieConsent(){
  try{return JSON.parse(localStorage.getItem(VT_CONSENT_KEY)||"null")}catch(e){return null}
}
function applyCookieConsent(consent){
  window.venttoolsConsent={essential:true,analytics:!!(consent&&consent.analytics)};
  if(window.venttoolsConsent.analytics){
    loadVentToolsAnalytics();
    if(typeof window.gtag==="function"){
      window.gtag("consent","update",{analytics_storage:"granted"});
    }
  }else{
    disableVentToolsAnalytics();
  }
  document.dispatchEvent(new CustomEvent("venttools:consent",{detail:window.venttoolsConsent}));
}
function saveCookieConsent(analytics){
  const consent={essential:true,analytics:!!analytics,updated:new Date().toISOString()};
  localStorage.setItem(VT_CONSENT_KEY,JSON.stringify(consent));
  applyCookieConsent(consent);
  const banner=$("cookieBanner");if(banner)banner.hidden=true;
  closeCookiePreferences();
}
function openCookiePreferences(){
  const consent=getCookieConsent();
  const toggle=$("analyticsConsentToggle");
  if(toggle)toggle.checked=!!(consent&&consent.analytics);
  const modal=$("cookieModal");if(modal)modal.hidden=false;
}
function closeCookiePreferences(){
  const modal=$("cookieModal");if(modal)modal.hidden=true;
}
function saveCookiePreferences(){
  const toggle=$("analyticsConsentToggle");
  saveCookieConsent(!!(toggle&&toggle.checked));
}
function initialiseVentToolsSite(){
  const consent=getCookieConsent();
  applyCookieConsent(consent||{analytics:false});
  const banner=$("cookieBanner");
  if(banner)banner.hidden=!!consent;
  if(document.body?.dataset?.page){
    document.querySelector(".page")?.classList.add("active");
    return;
  }
  const requested=(location.hash||"#home").slice(1);
  const allowed=["home","offset","ductulator","ductwrap","fireDamper","contact","about","privacy","cookies","terms","disclaimer"];
  showPage(allowed.includes(requested)?requested:"home");
}
window.addEventListener("DOMContentLoaded",initialiseVentToolsSite);


document.addEventListener("DOMContentLoaded",initVTEngineeringMode);
